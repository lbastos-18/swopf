/**
 * API Client SWPCF
 * Gerencia todas as requisições ao backend
 */

const API = {
    // Configurações base
    BASE_URL: '../api',
    TIMEOUT: 10000,

    /**
     * Faz uma requisição HTTP
     */
    async request(endpoint, options = {}) {
        const url = `${this.BASE_URL}${endpoint}`;
        const token = localStorage.getItem('swpcf_token');

        const config = {
            ...options,
            headers: {
                'Content-Type': 'application/json',
                ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
                ...options.headers
            }
        };

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), this.TIMEOUT);

            const response = await fetch(url, {
                ...config,
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    /**
     * Requisição GET
     */
    async get(endpoint, params = {}) {
        const queryString = new URLSearchParams(params).toString();
        const url = queryString ? `${endpoint}?${queryString}` : endpoint;
        return this.request(url, { method: 'GET' });
    },

    /**
     * Requisição POST
     */
    async post(endpoint, data = {}) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },

    /**
     * Requisição PUT
     */
    async put(endpoint, data = {}) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    /**
     * Requisição DELETE
     */
    async delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    },

    /**
     * Métodos de Autenticação
     */
    auth: {
        async login(email, password, rememberMe = false) {
            return API.post('/auth/login.php', { email, password, rememberMe });
        },

        async register(userData) {
            return API.post('/auth/register.php', userData);
        },

        async logout() {
            return API.post('/auth/logout.php');
        },

        async refreshToken() {
            return API.post('/auth/refresh.php');
        },

        async forgotPassword(email) {
            return API.post('/auth/forgot-password.php', { email });
        },

        async resetPassword(token, newPassword) {
            return API.post('/auth/reset-password.php', { token, newPassword });
        }
    },

    /**
     * Métodos de Usuários
     */
    users: {
        async getProfile() {
            return API.get('/users/profile.php');
        },

        async updateProfile(data) {
            return API.put('/users/profile.php', data);
        },

        async changePassword(currentPassword, newPassword) {
            return API.post('/users/change-password.php', { 
                currentPassword, 
                newPassword 
            });
        },

        async uploadPhoto(file) {
            const formData = new FormData();
            formData.append('photo', file);
            return API.request('/users/photo.php', {
                method: 'POST',
                body: formData,
                headers: {} // Deixa o navegador definir o Content-Type para multipart/form-data
            });
        }
    },

    /**
     * Métodos de Vagas
     */
    vagas: {
        async getAll(params = {}) {
            return API.get('/vagas/list.php', params);
        },

        async getById(id) {
            return API.get(`/vagas/${id}.php`);
        },

        async create(data) {
            return API.post('/vagas/create.php', data);
        },

        async update(id, data) {
            return API.put(`/vagas/${id}.php`, data);
        },

        async delete(id) {
            return API.delete(`/vagas/${id}.php`);
        },

        async aplicar(vagaId, candidatoId) {
            return API.post('/vagas/aplicar.php', { vagaId, candidatoId });
        }
    },

    /**
     * Métodos de Candidatos
     */
    candidatos: {
        async getAll(params = {}) {
            return API.get('/candidatos/list.php', params);
        },

        async getById(id) {
            return API.get(`/candidatos/${id}.php`);
        },

        async update(id, data) {
            return API.put(`/candidatos/${id}.php`, data);
        },

        async delete(id) {
            return API.delete(`/candidatos/${id}.php`);
        },

        async getCandidaturas(id) {
            return API.get(`/candidatos/${id}/candidaturas.php`);
        }
    },

    /**
     * Métodos de Cursos
     */
    cursos: {
        async getAll(params = {}) {
            return API.get('/cursos/list.php', params);
        },

        async getById(id) {
            return API.get(`/cursos/${id}.php`);
        },

        async create(data) {
            return API.post('/cursos/create.php', data);
        },

        async update(id, data) {
            return API.put(`/cursos/${id}.php`, data);
        },

        async delete(id) {
            return API.delete(`/cursos/${id}.php`);
        },

        async inscrever(cursoId) {
            return API.post('/cursos/inscrever.php', { cursoId });
        }
    },

    /**
     * Métodos de Notificações
     */
    notificacoes: {
        async getAll(params = {}) {
            return API.get('/notificacoes/list.php', params);
        },

        async marcarComoLida(id) {
            return API.put(`/notificacoes/${id}/ler.php`);
        },

        async marcarTodasComoLidas() {
            return API.put('/notificacoes/ler-todas.php');
        },

        async delete(id) {
            return API.delete(`/notificacoes/${id}.php`);
        }
    },

    /**
     * Métodos de Relatórios e Estatísticas
     */
    relatorios: {
        async getEstatisticas() {
            return API.get('/relatorios/estatisticas.php');
        },

        async getGraficoCandidaturas() {
            return API.get('/relatorios/grafico-candidaturas.php');
        },

        async getGraficoVagas() {
            return API.get('/relatorios/grafico-vagas.php');
        },

        async exportarCandidaturas(formato = 'pdf') {
            return API.get(`/relatorios/exportar-candidaturas.php?formato=${formato}`);
        },

        async exportarVagas(formato = 'pdf') {
            return API.get(`/relatorios/exportar-vagas.php?formato=${formato}`);
        }
    },

    /**
     * Métodos de Documentos
     */
    documentos: {
        async upload(file, tipo) {
            const formData = new FormData();
            formData.append('documento', file);
            formData.append('tipo', tipo);
            return API.request('/documentos/upload.php', {
                method: 'POST',
                body: formData,
                headers: {}
            });
        },

        async validar(id, status, observacoes) {
            return API.put(`/documentos/${id}/validar.php`, { status, observacoes });
        },

        async delete(id) {
            return API.delete(`/documentos/${id}.php`);
        }
    }
};

// Tornar disponível globalmente
window.API = API;
window.api = API;
