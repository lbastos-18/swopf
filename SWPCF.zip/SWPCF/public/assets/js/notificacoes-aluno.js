// Variáveis
let notificacoesCacheadas = [];
let filtroActual = 'todas';

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    carregarNotificacoes();
});

// Carregar notificações
async function carregarNotificacoes() {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/notificacoes', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (data.success) {
            notificacoesCacheadas = data.notificacoes || [];
            renderizarNotificacoes();
        }
    } catch (error) {
        console.error('Erro ao carregar notificações:', error);
    }
}

// Renderizar notificações
function renderizarNotificacoes() {
    const container = document.getElementById('notificacoesContainer');
    let notificacoesFiltradas = notificacoesCacheadas;

    // Aplicar filtro
    if (filtroActual === 'nao_lidas') {
        notificacoesFiltradas = notificacoesCacheadas.filter(n => n.lida === 0);
    } else if (filtroActual !== 'todas') {
        notificacoesFiltradas = notificacoesCacheadas.filter(n => {
            if (filtroActual === 'cursos') return n.tipo === 'curso_disponivel';
            if (filtroActual === 'estagios') return n.tipo === 'vaga_disponivel';
            if (filtroActual === 'documentos') return n.tipo === 'documento_validado';
            return true;
        });
    }

    if (notificacoesFiltradas.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i class="fas fa-bell-slash"></i>
                </div>
                <div class="empty-state-text">
                    Nenhuma notificação para mostrar
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = notificacoesFiltradas.map(notif => `
        <div class="notification-item ${notif.lida === 0 ? 'nao-lida' : ''}">
            <div class="notification-header">
                <h5 class="notification-titulo">${notif.titulo}</h5>
                <span class="notification-badge ${notif.lida === 1 ? 'lida' : ''}">
                    ${notif.lida === 0 ? 'Não lida' : 'Lida'}
                </span>
            </div>
            <p class="notification-mensagem">${notif.mensagem}</p>
            <div class="notification-data">
                <i class="fas fa-calendar me-2"></i>${formatarData(notif.criada_em)}
            </div>
            <div class="notification-actions">
                ${notif.lida === 0 ? `
                    <button class="btn btn-sm btn-primary" onclick="marcarComoLida(${notif.id})">
                        <i class="fas fa-check me-1"></i>Marcar como lida
                    </button>
                ` : ''}
                <button class="btn btn-sm btn-outline-danger" onclick="apagarNotificacao(${notif.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

// Filtrar notificações
function filtrarNotificacoes(filtro) {
    filtroActual = filtro;
    
    // Atualizar botões activos
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    renderizarNotificacoes();
}

// Marcar notificação como lida
async function marcarComoLida(notificacaoId) {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/notificacao-lida', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ notificacao_id: notificacaoId })
        });

        const data = await response.json();

        if (data.success) {
            carregarNotificacoes();
        }
    } catch (error) {
        console.error('Erro:', error);
    }
}

// Marcar todas como lidas
async function marcarTodasComoLidas() {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/notificacoes-lidas', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });

        const data = await response.json();

        if (data.success) {
            carregarNotificacoes();
        }
    } catch (error) {
        console.error('Erro:', error);
    }
}

// Apagar notificação (função placeholder - implementar endpoint)
function apagarNotificacao(notificacaoId) {
    if (confirm('Tem certeza que deseja apagar esta notificação?')) {
        notificacoesCacheadas = notificacoesCacheadas.filter(n => n.id !== notificacaoId);
        renderizarNotificacoes();
    }
}

// Formatar data
function formatarData(dataISO) {
    const data = new Date(dataISO);
    const agora = new Date();
    const diferenca = Math.floor((agora - data) / 1000);

    if (diferenca < 60) {
        return 'Agora mesmo';
    } else if (diferenca < 3600) {
        const minutos = Math.floor(diferenca / 60);
        return minutos + (minutos === 1 ? ' minuto atrás' : ' minutos atrás');
    } else if (diferenca < 86400) {
        const horas = Math.floor(diferenca / 3600);
        return horas + (horas === 1 ? ' hora atrás' : ' horas atrás');
    } else if (diferenca < 604800) {
        const dias = Math.floor(diferenca / 86400);
        return dias + (dias === 1 ? ' dia atrás' : ' dias atrás');
    } else {
        return data.toLocaleDateString('pt-PT', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
}
