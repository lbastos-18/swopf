/**
 * Registo de Candidatos - Página Pública
 */

// Provincias de Angola
const provinciasAngola = [
    'Bengo', 'Benguela', 'Bié', 'Cabinda', 'Cuando Cubango',
    'Cuanza Norte', 'Cuanza Sul', 'Cunene', 'Huambo', 'Huíla',
    'Luanda', 'Lunda Norte', 'Lunda Sul', 'Malanje', 'Moxico', 'Namibe'
];

document.addEventListener('DOMContentLoaded', function() {
    try {
        preencherProvincias();
        document.getElementById('formRegisto').addEventListener('submit', validarERegistar);
    } catch (erro) {
        console.error('Erro ao inicializar:', erro);
    }
});

/**
 * Preencher selectores de província
 */
function preencherProvincias() {
    const select = document.getElementById('provinciaSelect');
    provinciasAngola.forEach(provincia => {
        const option = document.createElement('option');
        option.value = provincia;
        option.textContent = provincia;
        select.appendChild(option);
    });
}

/**
 * Validar e registar candidato
 */
async function validarERegistar(e) {
    e.preventDefault();
    
    const form = document.getElementById('formRegisto');
    const btnSubmit = form.querySelector('button[type="submit"]');
    
    try {
        // Limpar alertas
        const alertaErro = document.getElementById('alertaErro');
        const alertaSucesso = document.getElementById('alertaSucesso');
        alertaErro.classList.add('d-none');
        alertaSucesso.classList.add('d-none');

        // Validações básicas client-side
        const { senha, confirmar_senha, data_nascimento, numero_documento, telefone } = form.elements;

        // Validar senhas
        if (senha.value !== confirmar_senha.value) {
            mostrarErro('As senhas não combinam');
            return;
        }

        if (senha.value.length < 6) {
            mostrarErro('Senha deve ter pelo menos 6 caracteres');
            return;
        }

        // Validar BI (7-10 dígitos)
        if (!/^\d{7,10}$/.test(numero_documento.value)) {
            mostrarErro('BI deve conter 7-10 dígitos (sem espaços)');
            return;
        }

        // Validar telefone angolano (básico)
        if (!/^\+244\s*9\d{8}$|^9\d{8}$|^244\s*9\d{8}$/.test(telefone.value.replace(/\s+/g, ' '))) {
            mostrarErro('Telefone deve estar no formato angolano (+244 9XXXXXXXXX)');
            return;
        }

        // Validar data de nascimento (18+)
        if (data_nascimento.value) {
            const dataNasc = new Date(data_nascimento.value);
            const hoje = new Date();
            let idade = hoje.getFullYear() - dataNasc.getFullYear();
            const mes = hoje.getMonth() - dataNasc.getMonth();
            if (mes < 0 || (mes === 0 && hoje.getDate() < dataNasc.getDate())) {
                idade--;
            }
            
            if (idade < 18) {
                mostrarErro('Deve ter no mínimo 18 anos para se registar');
                return;
            }
        }

        // Desabilitar botão de envio
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Registando...';

        // Preparar dados
        const dados = {
            nome: form.nome.value,
            email: form.email.value,
            senha: form.senha.value,
            numero_documento: form.numero_documento.value,
            telefone: form.telefone.value,
            data_nascimento: form.data_nascimento.value || null,
            genero: form.genero.value,
            endereco: form.endereco.value || null,
            provincia: form.provincia.value || null
        };

        // Enviar registo
        const response = await fetch('/api/index.php?endpoint=auth/register-candidato', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (!resultado.success) {
            throw new Error(resultado.message || 'Erro ao registar');
        }

        // Mostrar sucesso
        mostrarSucesso('Conta criada com sucesso! Redirecionando para o login...');
        
        // Limpar formulário
        form.reset();

        // Redirecionar após 2 segundos
        setTimeout(() => {
            window.location.href = 'index.html#login';
        }, 2000);

    } catch (erro) {
        console.error('Erro:', erro);
        mostrarErro(erro.message || 'Erro ao registar conta');
    } finally {
        // Re-habilitar botão
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = '<i class="fas fa-paper-plane me-2"></i> Criar Conta';
    }
}

/**
 * Mostrar erro
 */
function mostrarErro(mensagem) {
    const alerta = document.getElementById('alertaErro');
    const mensagemEl = document.getElementById('mensagemErro');
    
    mensagemEl.textContent = mensagem;
    alerta.classList.remove('d-none');
    
    // Auto-dismiss após 5 segundos
    setTimeout(() => {
        alerta.classList.add('d-none');
    }, 5000);
    
    // Scroll para erro
    alerta.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

/**
 * Mostrar sucesso
 */
function mostrarSucesso(mensagem) {
    const alerta = document.getElementById('alertaSucesso');
    const mensagemEl = document.getElementById('mensagemSucesso');
    
    mensagemEl.textContent = mensagem;
    alerta.classList.remove('d-none');
    
    // Scroll para sucesso
    alerta.scrollIntoView({ behavior: 'smooth', block: 'center' });
}
