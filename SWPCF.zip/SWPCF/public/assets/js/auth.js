/**
 * Sistema de Autenticação SWPCF
 * Gerencia login, logout e sessões de usuários
 */

const Auth = {
    // Chaves do localStorage
    STORAGE_KEYS: {
        USER: 'swpcf_user',
        TOKEN: 'swpcf_token',
        REMEMBER_ME: 'swpcf_rememberMe'
    },

    /**
     * Verifica se o usuário está autenticado
     */
    isAuthenticated() {
        const token = localStorage.getItem(this.STORAGE_KEYS.TOKEN);
        const user = localStorage.getItem(this.STORAGE_KEYS.USER);
        return !!(token && user);
    },

    /**
     * Obtém os dados do usuário atual
     */
    getUser() {
        try {
            const userStr = localStorage.getItem(this.STORAGE_KEYS.USER);
            return userStr ? JSON.parse(userStr) : null;
        } catch (error) {
            console.error('Erro ao obter usuário:', error);
            return null;
        }
    },

    /**
     * Obtém o token de autenticação
     */
    getToken() {
        return localStorage.getItem(this.STORAGE_KEYS.TOKEN);
    },

    /**
     * Verifica se o usuário é admin
     */
    isAdmin() {
        const user = this.getUser();
        return user && (user.tipo_utilizador === 'admin' || user.tipo_utilizador === 'gestor' || user.role === 'admin' || user.role === 'super_admin');
    },

    /**
     * Realiza o login do usuário
     */
    async login(email, password, rememberMe = false) {
        try {
            // Simulação de chamada à API
            const response = await fetch('../api/login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password, rememberMe })
            });

            if (!response.ok) {
                throw new Error('Erro ao fazer login');
            }

            const data = await response.json();

            if (data.success) {
                // Armazenar dados do usuário
                localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(data.user));
                localStorage.setItem(this.STORAGE_KEYS.TOKEN, data.token);

                if (rememberMe) {
                    localStorage.setItem(this.STORAGE_KEYS.REMEMBER_ME, 'true');
                } else {
                    localStorage.removeItem(this.STORAGE_KEYS.REMEMBER_ME);
                }

                // Disparar evento de autenticação
                window.dispatchEvent(new Event('auth-changed'));

                return { success: true, user: data.user };
            } else {
                return { success: false, message: data.message || 'Credenciais inválidas' };
            }
        } catch (error) {
            console.error('Erro no login:', error);
            // Fallback para desenvolvimento
            return this.fallbackLogin(email, password, rememberMe);
        }
    },

    /**
     * Login de fallback para desenvolvimento
     */
    fallbackLogin(email, password, rememberMe = false) {
        const users = {
            'admin@swpcf.pt': { tipo_utilizador: 'admin', role: 'super_admin', password: 'admin123' },
            'test@admin.swpcf.pt': { tipo_utilizador: 'admin', role: 'admin' },
            'candidato@example.com': { tipo_utilizador: 'candidato', role: 'candidato' }
        };

        const user = users[email];
        let isValidUser = false;

        if (user) {
            if (email === 'admin@swpcf.pt') {
                isValidUser = password === user.password;
            } else {
                isValidUser = true;
            }
        } else if (email.includes('@')) {
            isValidUser = true;
        }

        if (isValidUser) {
            const userData = {
                id: Math.random().toString(36).substr(2, 9),
                email: email,
                nome: email.split('@')[0],
                tipo_utilizador: user?.tipo_utilizador || 'candidato',
                role: user?.role || 'candidato',
                loginTime: new Date().toISOString()
            };

            localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(userData));
            localStorage.setItem(this.STORAGE_KEYS.TOKEN, 'token_' + Math.random().toString(36).substr(2, 9));

            if (rememberMe) {
                localStorage.setItem(this.STORAGE_KEYS.REMEMBER_ME, 'true');
            }

            window.dispatchEvent(new Event('auth-changed'));

            return { success: true, user: userData };
        } else {
            return { success: false, message: 'Email ou senha incorretos' };
        }
    },

    /**
     * Realiza o registro de um novo usuário
     */
    async register(userData) {
        try {
            const response = await fetch('../api/register.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            if (!response.ok) {
                throw new Error('Erro ao registrar usuário');
            }

            const data = await response.json();

            if (data.success) {
                localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(data.user));
                localStorage.setItem(this.STORAGE_KEYS.TOKEN, data.token);
                window.dispatchEvent(new Event('auth-changed'));
                return { success: true, user: data.user };
            } else {
                return { success: false, message: data.message || 'Erro ao registrar' };
            }
        } catch (error) {
            console.error('Erro no registro:', error);
            // Fallback para desenvolvimento
            const fallbackUser = {
                id: Math.random().toString(36).substr(2, 9),
                ...userData,
                tipo_utilizador: 'candidato',
                role: 'candidato',
                criadoEm: new Date().toISOString()
            };

            localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(fallbackUser));
            localStorage.setItem(this.STORAGE_KEYS.TOKEN, 'token_' + Math.random().toString(36).substr(2, 9));
            window.dispatchEvent(new Event('auth-changed'));

            return { success: true, user: fallbackUser };
        }
    },

    /**
     * Realiza o logout do usuário
     */
    logout() {
        localStorage.removeItem(this.STORAGE_KEYS.USER);
        localStorage.removeItem(this.STORAGE_KEYS.TOKEN);
        localStorage.removeItem(this.STORAGE_KEYS.REMEMBER_ME);
        window.dispatchEvent(new Event('auth-changed'));
        window.location.href = '../public/login.html';
    },

    /**
     * Verifica se o usuário deve ser lembrado
     */
    shouldRemember() {
        return localStorage.getItem(this.STORAGE_KEYS.REMEMBER_ME) === 'true';
    },

    /**
     * Atualiza os dados do usuário
     */
    updateUser(userData) {
        const currentUser = this.getUser();
        if (currentUser) {
            const updatedUser = { ...currentUser, ...userData };
            localStorage.setItem(this.STORAGE_KEYS.USER, JSON.stringify(updatedUser));
            window.dispatchEvent(new Event('auth-changed'));
        }
    }
};

// Tornar disponível globalmente
window.Auth = Auth;
window.auth = Auth;
