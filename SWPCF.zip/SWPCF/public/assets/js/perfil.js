// Variáveis globais
let alunoAtual = {};
let provinciaAngola = {
    'Luanda': 'Luanda',
    'Bengo': 'Bengo',
    'Cabinda': 'Cabinda',
    'Huambo': 'Huambo',
    'Huíla': 'Huíla',
    'Quando Cubango': 'Quando Cubango',
    'Kwanza Norte': 'Kwanza Norte',
    'Kwanza Sul': 'Kwanza Sul',
    'Lunda Norte': 'Lunda Norte',
    'Lunda Sul': 'Lunda Sul',
    'Malanje': 'Malanje',
    'Moxico': 'Moxico',
    'Namibe': 'Namibe',
    'Uíge': 'Uíge',
    'Zaire': 'Zaire',
    'Cuanza': 'Cuanza'
};

// Inicializar página
document.addEventListener('DOMContentLoaded', () => {
    carregarPerfil();
    carregarProvincias();
});

// Carregar perfil do aluno
async function carregarPerfil() {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/perfil', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (data.success) {
            alunoAtual = data.utilizador;
            atualizarInterfacePerfil();
            carregarCursos();
            carregarNotificacoes();
            carregarCursosEmEspera();
        }
    } catch (error) {
        console.error('Erro ao carregar perfil:', error);
        alert('Erro ao carregar perfil');
    }
}

// Atualizar interface com dados do perfil
function atualizarInterfacePerfil() {
    document.getElementById('nomeAluno').textContent = alunoAtual.nome || 'Utilizador';
    document.getElementById('emailAluno').textContent = alunoAtual.email || '';
    
    if (alunoAtual.numero_documento) {
        document.getElementById('documentoAluno').textContent = `BI: ${alunoAtual.numero_documento}`;
    }

    // Preencher form de edição
    document.getElementById('editarNome').value = alunoAtual.nome || '';
    document.getElementById('editarEmail').value = alunoAtual.email || '';
    document.getElementById('editarTelefone').value = alunoAtual.telefone || '';
    document.getElementById('editarBI').value = alunoAtual.numero_documento || '';
    document.getElementById('editarDataNascimento').value = alunoAtual.data_nascimento || '';
    document.getElementById('editarGenero').value = alunoAtual.genero || '';
    document.getElementById('editarEndereco').value = alunoAtual.endereco || '';
    document.getElementById('editarProvincia').value = alunoAtual.provincia || '';
}

// Carregar cursos
async function carregarCursos() {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/meus-cursos', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (data.success) {
            const cursos = data.cursos || [];
            
            // Contar por status
            const completados = cursos.filter(c => c.status === 'completado').length;
            const emProgresso = cursos.filter(c => c.status === 'em_progresso').length;
            const guardados = cursos.filter(c => c.status === 'guardado').length;

            document.getElementById('cursosCompletados').textContent = completados;
            document.getElementById('cursosEmProgresso').textContent = emProgresso;
            document.getElementById('cursosGuardados').textContent = guardados;

            // Renderizar listas
            renderizarCursosPorStatus(cursos, 'em_progresso', 'cursosEmProgressoList');
            renderizarCursosPorStatus(cursos, 'completado', 'cursosCompletadosList');
            renderizarCursosPorStatus(cursos, 'guardado', 'cursosGuardadosList');
        }
    } catch (error) {
        console.error('Erro ao carregar cursos:', error);
    }
}

// Renderizar cursos por status
function renderizarCursosPorStatus(cursos, status, containerId) {
    const container = document.getElementById(containerId);
    const cursosFiltrados = cursos.filter(c => c.status === status);

    if (cursosFiltrados.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i class="fas fa-inbox"></i>
                </div>
                <div class="empty-state-text">
                    Nenhum curso nesta categoria
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = cursosFiltrados.map(curso => `
        <div class="course-item">
            <div class="course-info">
                <div class="course-title">${curso.titulo}</div>
                <div class="course-duration">
                    <i class="fas fa-clock me-2"></i>${curso.duracao || 'N/A'} horas
                </div>
            </div>
            <span class="course-status status-${curso.status}">
                ${getStatusLabel(curso.status)}
            </span>
            <div class="ms-2">
                <button class="btn btn-sm btn-outline-danger" onclick="removerCurso(${curso.curso_id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

// Carregar cursos em lista de espera
async function carregarCursosEmEspera() {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/cursos-em-espera', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (data.success) {
            const cursos = data.cursos || [];
            const container = document.getElementById('cursosEmEsperaList');

            if (cursos.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="empty-state-text">
                            Não está à espera de nenhum curso
                        </div>
                    </div>
                `;
                return;
            }

            container.innerHTML = cursos.map(curso => `
                <div class="course-item">
                    <div class="course-info">
                        <div class="course-title">${curso.titulo}</div>
                        <div class="course-duration">
                            <i class="fas fa-hourglass-half me-2"></i>Posição: ${curso.posicao}
                        </div>
                    </div>
                    <span class="badge bg-primary text-white">À Espera</span>
                    <div class="ms-2">
                        <button class="btn btn-sm btn-outline-danger" onclick="removerDaListaEspera(${curso.curso_id})">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            `).join('');

            // Mostrar aviso de listas pendentes
            if (cursos.length > 0) {
                const pendingContainer = document.getElementById('pendingWaitList');
                const pendingItems = document.getElementById('pendingListItems');
                
                pendingItems.innerHTML = cursos.map(curso => `
                    <div class="pending-item">
                        <i class="fas fa-circle-notch"></i>Posição ${curso.posicao} na fila para "${curso.titulo}"
                    </div>
                `).join('');
                
                pendingContainer.style.display = 'block';
            }
        }
    } catch (error) {
        console.error('Erro ao carregar listas de espera:', error);
    }
}

// Carregar notificações
async function carregarNotificacoes() {
    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/notificacoes?apenas_nao_lidas=true', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });

        const data = await response.json();

        if (data.success && data.estatisticas) {
            const naoLidas = data.estatisticas.nao_lidas || 0;
            document.getElementById('notificacoesNaoLidas').textContent = naoLidas;
            
            if (naoLidas > 0) {
                document.getElementById('notificacoesBadge').textContent = naoLidas;
                document.getElementById('notificacoesBadge').style.display = 'flex';
            }
        }
    } catch (error) {
        console.error('Erro ao carregar notificações:', error);
    }
}

// Remover curso
async function removerCurso(cursoId) {
    if (!confirm('Tem certeza que deseja remover este curso?')) {
        return;
    }

    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/remover-curso', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ curso_id: cursoId })
        });

        const data = await response.json();

        if (data.success) {
            alert('Curso removido com sucesso');
            carregarCursos();
        } else {
            alert('Erro ao remover curso: ' + data.message);
        }
    } catch (error) {
        console.error('Erro:', error);
    }
}

// Remover da lista de espera
async function removerDaListaEspera(cursoId) {
    if (!confirm('Tem certeza que deseja sair da lista de espera?')) {
        return;
    }

    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/remover-lista-espera', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ curso_id: cursoId })
        });

        const data = await response.json();

        if (data.success) {
            alert('Removido da lista de espera');
            carregarCursosEmEspera();
        } else {
            alert('Erro: ' + data.message);
        }
    } catch (error) {
        console.error('Erro:', error);
    }
}

// Guardar perfil
async function guardarPerfil() {
    const perfil = {
        nome: document.getElementById('editarNome').value,
        email: document.getElementById('editarEmail').value,
        telefone: document.getElementById('editarTelefone').value,
        numero_documento: document.getElementById('editarBI').value,
        data_nascimento: document.getElementById('editarDataNascimento').value,
        genero: document.getElementById('editarGenero').value,
        endereco: document.getElementById('editarEndereco').value,
        provincia: document.getElementById('editarProvincia').value
    };

    try {
        const response = await fetch('/SWPCF/api/index.php?action=aluno/perfil', {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(perfil)
        });

        const data = await response.json();

        if (data.success) {
            alert('Perfil actualizado com sucesso!');
            bootstrap.Modal.getInstance(document.getElementById('editarPerfilModal')).hide();
            carregarPerfil();
        } else {
            alert('Erro: ' + data.message);
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao actualizar perfil');
    }
}

// Carregar províncias
function carregarProvincias() {
    const select = document.getElementById('editarProvincia');
    
    Object.entries(provinciaAngola).forEach(([key, value]) => {
        const option = document.createElement('option');
        option.value = key;
        option.textContent = value;
        select.appendChild(option);
    });
}

// Obter label de status
function getStatusLabel(status) {
    const labels = {
        'completado': 'Completado',
        'em_progresso': 'Em Progresso',
        'guardado': 'Guardado'
    };
    return labels[status] || status;
}
