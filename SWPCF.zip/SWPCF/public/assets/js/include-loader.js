// include-loader.js
// Centraliza carregamento de includes públicos (nav/footer) e garante index.css carregado
document.addEventListener('DOMContentLoaded', function() {
  // ensure public override CSS is loaded once
  if (!document.querySelector('link[href$="index.css"]')) {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    // most public pages expect assets under "assets/" (public/assets)
    link.href = 'assets/css/index.css';
    document.head.appendChild(link);
  }

  function loadIfEmpty(containerId, url) {
    const container = document.getElementById(containerId);
    if (!container) return;
    if (container.children.length === 0) {
      fetch(url)
        .then(r => r.text())
        .then(html => {
          container.innerHTML = html;
          // execute inline scripts inside the include
          const scripts = container.querySelectorAll('script');
          scripts.forEach(s => {
            try {
              eval(s.textContent);
            } catch (e) {
              console.error('Error executing include script', e);
            }
          });
          // mark active nav links
          const links = container.querySelectorAll('.nav-link');
          const current = window.location.pathname.split('/').pop() || 'index.html';
          links.forEach(link => {
            const href = link.getAttribute('href');
            if (href === current) link.classList.add('active');
          });
        })
        .catch(err => console.error('Include load error:', err));
    }
  }

  // load navbar and footer relative to public pages
  loadIfEmpty('navbar-container', 'includes/navbar.html');
  loadIfEmpty('footer-container', 'includes/footer.html');
});
