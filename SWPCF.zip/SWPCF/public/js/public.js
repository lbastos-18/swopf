/**
 * PUBLIC SCRIPT - SWPCF v2.0
 * Script Global para Seção Pública
 * Gestão de UI, navegação e interações
 */

document.addEventListener('DOMContentLoaded', function() {
    initializePublic();
});

/**
 * Inicializar componentes públicos
 */
function initializePublic() {
    setupNavbar();
    setupAnimations();
    setupFormValidation();
    setupSearchFunctionality();
    setupNotifications();
}

/**
 * Setup da navbar
 */
function setupNavbar() {
    // Fechar dropdown ao clicar em link
    document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
        link.addEventListener('click', function() {
            const navbarToggle = document.querySelector('.navbar-toggler');
            const navbarCollapse = document.querySelector('.navbar-collapse');
            
            if (navbarCollapse.classList.contains('show') && window.innerWidth < 992) {
                navbarToggle.click();
            }
        });
    });

    // Destaca o link ativo baseado na página atual
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'index.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

/**
 * Setup de animações ao scroll
 */
function setupAnimations() {
    // Fade-in ao scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.card, .section-title').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
}

/**
 * Validação de formulários
 */
function setupFormValidation() {
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });

        // Remover validação visual ao focar
        form.querySelectorAll('input, textarea, select').forEach(field => {
            field.addEventListener('focus', function() {
                this.classList.remove('is-invalid');
            });
        });
    });
}

/**
 * Funcionalidade de busca
 */
function setupSearchFunctionality() {
    const searchInputs = document.querySelectorAll('[data-search]');
    
    searchInputs.forEach(input => {
        input.addEventListener('keyup', function(e) {
            const query = this.value.toLowerCase();
            const targetSelector = this.getAttribute('data-search');
            const items = document.querySelectorAll(targetSelector);

            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(query)) {
                    item.style.display = '';
                    item.style.opacity = '1';
                } else {
                    item.style.display = 'none';
                    item.style.opacity = '0';
                }
            });
        });
    });
}

/**
 * Sistema de notificações
 */
function setupNotifications() {
    window.showNotification = function(message, type = 'info', duration = 4000) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 350px;
            max-width: 500px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            animation: slideInRight 0.3s ease;
        `;
        alert.setAttribute('role', 'alert');
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;

        document.body.appendChild(alert);

        if (duration > 0) {
            setTimeout(() => {
                alert.remove();
            }, duration);
        }

        return alert;
    };

    // Estilos de animação
    if (!document.querySelector('style[data-notification-animations]')) {
        const style = document.createElement('style');
        style.setAttribute('data-notification-animations', 'true');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(400px);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);
    }
}

/**
 * Ferramentas úteis globais
 */
window.PublicUtils = {
    /**
     * Formatar data para PT-PT
     */
    formatDate(date) {
        return new Date(date).toLocaleDateString('pt-PT', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    },

    /**
     * Formatar moeda em AOA
     */
    formatCurrency(value) {
        return new Intl.NumberFormat('pt-PT', {
            style: 'currency',
            currency: 'AOA'
        }).format(value);
    },

    /**
     * Truncar texto
     */
    truncateText(text, length = 100) {
        if (!text) return '';
        return text.length > length ? text.substring(0, length) + '...' : text;
    },

    /**
     * Copiar para clipboard
     */
    copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copiado para clipboard!', 'success', 2000);
        }).catch(() => {
            showNotification('Erro ao copiar', 'danger');
        });
    },

    /**
     * Scroll suave para elemento
     */
    smoothScroll(selector) {
        const element = document.querySelector(selector);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    },

    /**
     * Verificar se utilizador está autenticado
     */
    isAuthenticated() {
        return !!localStorage.getItem('token');
    },

    /**
     * Obter dados do utilizador
     */
    getCurrentUser() {
        const user = localStorage.getItem('user');
        return user ? JSON.parse(user) : null;
    },

    /**
     * Fazer logout
     */
    logout() {
        if (confirm('Tem certeza que deseja sair?')) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = 'index.html';
        }
    }
};

/**
 * Fazer requisição à API com notificações
 */
window.apiCall = async function(endpoint, options = {}) {
    const defaultOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    };

    // Adicionar token se autenticado
    const token = localStorage.getItem('token');
    if (token) {
        defaultOptions.headers['Authorization'] = `Bearer ${token}`;
    }

    const finalOptions = { ...defaultOptions, ...options };

    try {
        const response = await fetch(endpoint, finalOptions);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || 'Erro na requisição');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        showNotification('Erro: ' + error.message, 'danger');
        throw error;
    }
};

/**
 * Renderizar lista de estágios/vagas dinamicamente
 */
window.renderItems = function(items, container, template) {
    const element = document.querySelector(container);
    if (!element) return;

    if (items.length === 0) {
        element.innerHTML = '<p class="text-center text-muted py-5">Nenhum resultado encontrado</p>';
        return;
    }

    element.innerHTML = items.map(item => template(item)).join('');
};

/**
 * Setup de paginação
 */
window.setupPagination = function(totalItems, itemsPerPage, callback) {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const paginationContainer = document.querySelector('[data-pagination]');
    
    if (!paginationContainer) return;

    let html = '<nav><ul class="pagination">';
    
    for (let i = 1; i <= totalPages; i++) {
        html += `<li class="page-item ${i === 1 ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${i}">${i}</a>
                </li>`;
    }
    
    html += '</ul></nav>';
    paginationContainer.innerHTML = html;

    paginationContainer.querySelectorAll('.page-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            callback(page);
        });
    });
};

/**
 * Carregador de navbar/footer (substituído por fetch)
 */
window.loadComponents = async function() {
    // Navbar
    const navbarContainer = document.getElementById('navbar-container');
    if (navbarContainer) {
        try {
            const response = await fetch('includes/navbar.html');
            const html = await response.text();
            navbarContainer.innerHTML = html;
            const scripts = navbarContainer.querySelectorAll('script');
            scripts.forEach(script => eval(script.textContent));
        } catch (error) {
            console.error('Erro ao carregar navbar:', error);
        }
    }

    // Footer
    try {
        const response = await fetch('includes/footer.html');
        const html = await response.text();
        const container = document.createElement('div');
        container.innerHTML = html;
        document.body.appendChild(container);
    } catch (error) {
        console.error('Erro ao carregar footer:', error);
    }
};

// Executar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadComponents);
} else {
    loadComponents();
}
