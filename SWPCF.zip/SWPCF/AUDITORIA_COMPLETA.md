# 🔍 AUDITORIA COMPLETA - SWPCF PROJETO PÚBLICO

**Data**: 4 de março de 2026  
**Status**: ⚠️ PROBLEMAS CRÍTICOS ENCONTRADOS  
**Prioridade**: ALTA

---

## 📊 RESUMO EXECUTIVO

| Categoria | Status | Quantidade |
|-----------|--------|-----------|
| **Footers Duplicados** | ❌ CRÍTICO | 2 páginas |
| **Ficheiros Faltantes** | ❌ CRÍTICO | 5 páginas |
| **Problemas de Cor** | ⚠️ IMPORTANTE | Múltiplos |
| **Páginas Mal Estruturadas** | ⚠️ IMPORTANTE | Sim |
| **Scripts Faltantes** | ⚠️ IMPORTANTE | Parcial |

---

## 🔴 PROBLEMAS CRÍTICOS ENCONTRADOS

### 1. **FOOTERS DUPLICADOS** (2 páginas)
```
❌ formacoes.html - LINHA 120-124
   <footer class="bg-dark text-white py-4 mt-5">
       <div class="container-xl text-center text-muted small">
           <p>&copy; 2026 SWPCF. Todos os direitos reservados.</p>
       </div>
   </footer>
   
   + Carregador footer dinâmico TAMBÉM PRESENTE (linhas 175-183)
   = DUPLICAÇÃO: Footer carregado 2x

❌ sobre.html - FOOTER INLINE PRESENTE
```

**Impacto**: 
- Footer aparece duplicado na página
- Performance afetada
- Comportamento imprevisível

**Causa**: Remoção incompleta de footers ao implementar carregamento dinâmico

---

### 2. **PÁGINAS ESSENCIAIS FALTANTES** (5 ficheiros)

```
❌ perfil.html              - FALTANTE (Crítico)
❌ candidaturas.html        - FALTANTE (Crítico)
❌ registo.html             - FALTANTE (Crítico)
❌ dashboard.html           - FALTANTE (Secundário)
❌ editar-perfil.html       - FALTANTE (Secundário)
```

**Impacto**:
- Navbar tem links para páginas que não existem
- Utilizadores não conseguem:
  - Ver seu perfil
  - Ver minhas candidaturas
  - Registar conta nova
  
**Referências quebradas**:
- navbar.html linha X: `href="perfil.html"` → 404
- navbar.html linha Y: `href="candidaturas.html"` → 404

---

### 3. **PROBLEMAS DE CORES E CONTRAST** ⚠️

#### Problema A: Badges com Contrast Insuficiente
```css
.badge-primary {
    background: var(--primary-light);     /* #e6f0ff - Azul muito claro */
    color: var(--primary);                /* #0066ff - Azul escuro */
}
```
**Problema**: Cor de fundo clara (#e6f0ff) com cor de texto azul (#0066ff)  
**Resultado**: Texto quase invisível - INACESSÍVEL!

**Solução necessária**:
```css
.badge-primary {
    background: var(--primary);           /* Fundo azul escuro */
    color: #ffffff;                        /* Texto branco */
}
```

#### Problema B: Outros Badges Afetados
- `.badge-success`: Verde claro + verde escuro = Ruim
- `.badge-danger`: Vermelho claro + vermelho escuro = Ruim
- `.badge-warning`: Amarelo claro + amarelo escuro = Ruim

---

## ⚠️ PROBLEMAS DE ESTRUTURA

- ### Problema 1: Páginas com Footers Inline (Não Dinâmicos)
- `formacoes.html` (linha 120-124) - Footer estático hardcoded
- `sobre.html` - Footer estático hardcoded
- Conflita com carregamento dinâmico via `fetch()`

### Problema 2: Carregamento Dinâmico Incompleto
```html
<!-- Carregador no fim do arquivo -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        fetch('includes/footer.html')  ← Footer carregado dinamicamente
            .then(...)
    });
</script>

<!-- MAS TAMBÉM TEM FOOTER ESTÁTICO -->
<footer class="bg-dark text-white py-4 mt-5">  ← Footer hardcoded
    ...
</footer>
```

**Resultado**: 2 footers aparecem na página!

### Problema 3: Rutas de CSS Inconsistentes
- Algumas páginas: `href="css/public-style.css"`
- Algumas páginas: `href="../assets/css/main.css"`
- Paths mistos = Possível falha de carregamento

---

## 📋 FICHEIROS FALTANTES - DETALHES

### 1. **perfil.html** (CRÍTICO)
- Deve mostrar dados do utilizador autenticado
- Editável
- Foto de perfil
- Informações pessoais

### 2. **candidaturas.html** (CRÍTICO)
- Listar candidaturas do utilizador
- Status de cada candidatura
- Data de inscrição
- Ações (retirar candidatura, etc)

### 3. **registo.html** (CRÍTICO)
- Formulário de registo completo
- Validação
- Integração com API

### 4. **dashboard.html** (SECUNDÁRIO)
- Dashboard do utilizador
- Resumo de atividades
- Estatísticas pessoais

### 5. **editar-perfil.html** (SECUNDÁRIO)
- Formulário para editar perfil
- Upload de foto
- Alteração de password

---

## 🎨 PROBLEMAS DE DESIGN/UX

### 1. Inconsistência de Espaçamento
- Padding inconsistente entre cards
- Margins não alinhadas

### 2. Falta de Feedback Visual
- Sem indicadores de carregamento em alguns lugares
- Sem animações suaves em transições

### 3. Responsividade Parcial
- Alguns cards não ajustam bem em mobile
- Filtros podem ficar fora de alinhamento

---

## 🔧 ISSUES COM SCRIPTS/JAVASCRIPT

### 1. Carregador de Navbar/Footer com Eval()
```javascript
const scripts = container.querySelectorAll('script');
scripts.forEach(script => {
    eval(script.textContent);  ← SEGURANÇA: eval() é perigoso!
});
```
**Problema**: Usar `eval()` é inseguro  
**Solução**: Usar método mais seguro (custom events, etc)

### 2. Public.js nem sempre carregado
- Algumas páginas faltam `<script src="js/public.js"></script>`
- Funcionalidades podem não inicializar

---

## 📊 CHECKLIST DE PROBLEMAS

### Críticos (Bloqueia uso)
- [ ] Footers duplicados nas páginas
- [ ] Página de perfil faltante
- [ ] Página de candidaturas faltante
- [ ] Página de registo faltante
- [ ] Problemas de cor em badges (inacessível)

### Importantes (Afeta UX)
- [ ] Paths de CSS inconsistentes
- [ ] Script public.js não carregado em todas as páginas
- [ ] Navbar aponta para páginas inexistentes
- [ ] Contraste de cor não passa em WCAG

### Secundários (Melhorias)
- [ ] Dashboard não criado
- [ ] Editar perfil não criado
- [ ] Algumas páginas precisam melhor estrutura
- [ ] JavaScript com eval() é inseguro

---

## 🎯 PLANO DE AÇÃO RECOMENDADO

### Fase 1: REPARAR CRÍTICOS (Imediato)
1. Remover footers inline (formacoes.html, sobre.html)
2. Manter APENAS carregamento dinâmico
3. Criar páginas faltantes (perfil, candidaturas, registo)
4. Corrigir cores dos badges
5. Atualizar navbar com links corretos

### Fase 2: OTIMIZAR (Curto prazo)
1. Padronizar paths de CSS
2. Garantir public.js carregado em todas as páginas
3. Melhorar responsividade
4. Remover eval() e usar abordagem mais segura

### Fase 3: MELHORIAS (Médio prazo)
1. Criar dashboard e editar-perfil
2. Adicionar mais feedback visual
3. Otimizar performance
4. Testes de acessibilidade (WCAG)

---

## 📈 RECOMENDAÇÕES ANTES DE COMEÇAR CORREÇÕES

### Para o Utilizador:
1. ✅ Revisar este relatório
2. ✅ Confirmar prioridades
3. ✅ Autorizar criação de novas páginas
4. ➡️ **DEPOIS: Iniciar correções**

### Ordem de Correção Sugerida:
1. Remover duplicações de footer
2. Criar estrutura HTML das páginas faltantes
3. Corrigir problemas de cor
4. Atualizar navbar
5. Testes finais

---

## 📝 CONCLUSÃO

O projeto tem **problemas críticos que precisam ser corrigidos antes de usar em produção**:

- ❌ Footers duplicados
- ❌ Páginas essenciais faltantes (perfil, candidaturas, registo)
- ❌ Cores inacessíveis
- ⚠️ Links quebrados na navbar

**Recomendação**: Fazer todas as correções identificadas neste relatório antes de continuar com qualquer funcionalidade nova.

---

**Gerado em**: 4 de março de 2026
