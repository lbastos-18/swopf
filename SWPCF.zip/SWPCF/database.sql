-- ============================================================================
-- SWPCF - Database Schema
-- ============================================================================

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS swpcf CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE swpcf;

-- ============================================================================
-- Tabela: Utilizadores (Admins)
-- ============================================================================
CREATE TABLE IF NOT EXISTS utilizador (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  tipo ENUM('admin', 'usuario') DEFAULT 'usuario',
  ativo TINYINT(1) DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Tabela: Cursos
-- ============================================================================
CREATE TABLE IF NOT EXISTS curso (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  descricao TEXT,
  duracao_meses INT,
  ativo TINYINT(1) DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Tabela: Estágios
-- ============================================================================
CREATE TABLE IF NOT EXISTS estagio (
  id INT AUTO_INCREMENT PRIMARY KEY,
  curso_id INT NOT NULL,
  titulo VARCHAR(150) NOT NULL,
  descricao TEXT,
  data_inicio DATE,
  data_fim DATE,
  ativo TINYINT(1) DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (curso_id) REFERENCES curso(id) ON DELETE CASCADE,
  INDEX (curso_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Tabela: Vagas
-- ============================================================================
CREATE TABLE IF NOT EXISTS vaga (
  id INT AUTO_INCREMENT PRIMARY KEY,
  estagio_id INT NOT NULL,
  titulo VARCHAR(150) NOT NULL,
  descricao TEXT,
  quantidade INT DEFAULT 1,
  preenchidas INT DEFAULT 0,
  ativa TINYINT(1) DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (estagio_id) REFERENCES estagio(id) ON DELETE CASCADE,
  INDEX (estagio_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Tabela: Candidatos
-- ============================================================================
CREATE TABLE IF NOT EXISTS candidato (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  telefone VARCHAR(20),
  data_nascimento DATE,
  genero ENUM('M', 'F', 'Outro'),
  ativo TINYINT(1) DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Tabela: Candidaturas
-- ============================================================================
CREATE TABLE IF NOT EXISTS candidatura (
  id INT AUTO_INCREMENT PRIMARY KEY,
  candidato_id INT NOT NULL,
  vaga_id INT NOT NULL,
  status ENUM('pendente', 'aceite', 'rejeitado', 'cancelado') DEFAULT 'pendente',
  data_candidatura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  data_resposta DATETIME,
  notas TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (candidato_id) REFERENCES candidato(id) ON DELETE CASCADE,
  FOREIGN KEY (vaga_id) REFERENCES vaga(id) ON DELETE CASCADE,
  INDEX (candidato_id),
  INDEX (vaga_id),
  INDEX (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Dados de Teste
-- ============================================================================

-- Admin padrão (senha: admin123)
INSERT INTO utilizador (nome, email, password, tipo) VALUES 
('Admin', 'admin@swpcf.local', '$2y$10$92IXUNpkm0rsSvsgQvs.n.m/JKZfMx4k7R7K8JK8zJ8N1F7Q7K4eK', 'admin');

-- Cursos de exemplo
INSERT INTO curso (nome, descricao, duracao_meses) VALUES 
('Informática', 'Curso de Informática e Programação', 6),
('Gestão', 'Curso de Gestão de Empresas', 6),
('Marketing', 'Curso de Marketing Digital', 3);

-- Estágios de exemplo
INSERT INTO estagio (curso_id, titulo, descricao, data_inicio, data_fim) VALUES 
(1, 'Estágio em Programação', 'Aprender desenvolvimento web', '2026-03-15', '2026-06-15'),
(2, 'Estágio em Gestão', 'Experiência em gestão de projetos', '2026-04-01', '2026-07-01');

-- Vagas de exemplo
INSERT INTO vaga (estagio_id, titulo, descricao, quantidade) VALUES 
(1, 'Programador Web', 'Procura-se programador para projeto web', 3),
(1, 'Suporte Técnico', 'Suporte técnico ao cliente', 2),
(2, 'Gestor de Projetos', 'Gestão de projetos internos', 1);
