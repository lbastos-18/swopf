<?php
/**
 * Configuração do Sistema
 * SWPCF v2.0
 */

// Ambiente
define('ENVIRONMENT', 'development'); // development | production

// URLs Base
define('BASE_URL', 'http://localhost/SWPCF/');
define('ADMIN_URL', BASE_URL . 'admin/');
define('PUBLIC_URL', BASE_URL . 'public/');

// Database (XAMPP Padrão)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'swpcf');

// Timezone
date_default_timezone_set('Europe/Lisbon');

// Locale
setlocale(LC_TIME, 'pt_PT.UTF-8', 'pt_PT', 'pt');
setlocale(LC_MONETARY, 'pt_PT.UTF-8', 'pt_PT', 'pt');
setlocale(LC_NUMERIC, 'pt_PT.UTF-8', 'pt_PT', 'pt');

// Erros
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Headers padrão
header('Content-Type: text/html; charset=utf-8');
header('X-UA-Compatible: ie=edge');

/**
 * Funções Auxiliares
 */

/**
 * Escrever HTML com escape
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Verificar se está logado
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Obter dados do utilizador logado
 */
function getCurrentUser() {
    return $_SESSION['user'] ?? null;
}

/**
 * Redirect
 */
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

/**
 * Converter timestamp para tempo relativo
 */
function timeAgo($date) {
    $now = new DateTime();
    $date = new DateTime($date);
    $interval = $now->diff($date);
    
    if ($interval->days > 0) {
        return 'Há ' . $interval->days . ' dia' . ($interval->days > 1 ? 's' : '');
    } elseif ($interval->h > 0) {
        return 'Há ' . $interval->h . ' hora' . ($interval->h > 1 ? 's' : '');
    } elseif ($interval->i > 0) {
        return 'Há ' . $interval->i . ' minuto' . ($interval->i > 1 ? 's' : '');
    } else {
        return 'Agora mesmo';
    }
}

/**
 * Formatar data
 */
function formatDate($date, $format = 'd/m/Y H:i') {
    $date = new DateTime($date);
    return $date->format($format);
}

/**
 * Log de debug
 */
function debug($data) {
    if (ENVIRONMENT === 'development') {
        echo '<pre style="background: #f0f0f0; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 5px;">';
        var_dump($data);
        echo '</pre>';
    }
}

// EOF
