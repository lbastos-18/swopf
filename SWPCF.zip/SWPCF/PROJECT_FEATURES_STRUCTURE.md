# SWPCF — Funcionalidades e Estrutura do Projeto

Última atualização: 4 de março de 2026

## 1. Visão Geral
SWPCF é uma plataforma pública e administrativa para gerir formações, estágios e vagas relacionados com tecnologia. O sistema inclui área pública para utilizadores (estudantes, candidatos) e painel administrativo para gerir conteúdos e usuários.

## 2. Funcionalidades Principais
- Autenticação: login/logout para utilizadores e administração.
- Gestão de Cursos/Formações: criar, editar, listar, remover cursos; inscrição de alunos; envio de comprovativos (documentos, comprovativos de pagamento).
- Gestão de Estágios: CRUD de estágios, filtros e listagem pública.
- Gestão de Vagas (opcional): CRUD de vagas de emprego/estágio (pode ser reusado como formações).
- Perfil de Utilizador: visualizar dados pessoais, cursos inscritos/concluídos, histórico de candidaturas/inscrições.
- Candidaturas/Inscrições: submissão de candidaturas a estágios e inscrições em cursos; gestão de status.
- Admin Dashboard: gestão de utilizadores, relatórios, logs de ações.
- API REST: endpoints para consumo de dados por clientes (front-end, mobile).
- Carregamento dinâmico de componentes: navbar e footer reutilizáveis carregados via includes.
- Formatos e Localização: suporte para formatação de moeda (Kz) e datas em pt-PT.

## 3. Estrutura de Pastas (Resumo relevante)
- `config.php` — configuração global
- `database.sql` — esquema e dados de exemplo
- `index.php` — router / ponto de entrada
- `admin/` — interface administrativa (HTML/PHP)
- `api/` — API REST (controllers, models, helpers)
  - `api/helpers/functions.php` — funções utilitárias (ex.: `formatCurrency`)
- `public/` — interface pública
  - `public/index.html` — homepage
  - `public/formacoes.html` — listagem e inscrição em formações (substitui vagas)
  - `public/estagios.html` — listagem de estágios
  - `public/perfil.html` — perfil do utilizador
  - `public/includes/navbar.html` — navbar reutilizável
  - `public/includes/footer.html` — footer reutilizável
- `assets/` — CSS, JS, imagens
  - `assets/css/` — estilos principais (`main.css`, `components.css`, etc.)
  - `assets/js/` — scripts (ex.: `estagios.js`, `index.js`, `api.js`)

## 4. Endpoints e Integração (exemplos)
- `GET /api/estagios` — listar estágios
- `GET /api/estagios/{id}` — detalhe do estágio
- `POST /api/auth/login` — autenticar utilizador
- `POST /api/inscricoes` — submeter inscrição (área para implementar backend de uploads)

> Observação: a API existente em `api/` contém controllers e helpers; confirmar concretização dos endpoints no repo.

## 5. Fluxos de Utilizador (resumido)
- Utilizador visita `index.html` → navega para `formacoes.html` ou `estagios.html` → abre modal de inscrição/candidatura → preenche dados e envia (dados guardados em localStorage em implementação frontend atual) → depois pode ver inscrições em `perfil.html`.
- Admin faz login em `admin/index.html` → acede a CRUDs para cursos, estágios, vagas e utilizadores.

## 6. Observações Técnicas e Recomendadas
- Moeda: padronizado para `Kz` (helpers e templates atualizados).
- Footer: carregado dinamicamente em `#footer-container` para evitar duplicações; evitar footers inline.
- Evitar `eval()` ao reexecutar scripts de includes — preferir inserção segura de `script` com `src` ou execução controlada.
- Padronizar paths de CSS/JS (usar caminhos relativos uniformes) e garantir `public.js` carregado em todas as páginas.
- Implementar backend para receber uploads de documentos e comprovativos (endpoint seguro, validação de tipo/size, armazenar referência no DB).

## 7. Próximos Passos Prioritários
1. Implementar endpoint para inscrições com upload (PHP + validação).  
2. Criar páginas faltantes ou garantir que `navbar.html` só aponta para páginas existentes (já ajustado para `formacoes.html`).  
3. Fazer QA local: testar navegação, login/logout, inscrição e visualização em `perfil.html`.
4. Implantar testes de acessibilidade e corrigir contrastes (badges) no CSS.

---

Se quiser, eu posso:
- Gerar uma versão mais detalhada (documentação por endpoint e modelos de dados),
- Adicionar diagramas (fluxo de dados) e instruções de deployment, ou
- Implementar o endpoint backend para inscrições (criar controller + rota + validação e persistência).

Diga qual destes próximos passos prefere que eu faça a seguir.