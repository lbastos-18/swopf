/**
 * UI Interactions - Modern Interface Enhancements
 * Smooth animations, accessibility-first interactions
 */

class UIManager {
    constructor() {
        this.init();
    }

    init() {
        this.setupNavigation();
        this.setupSearch();
        this.setupTheme();
        this.setupAccessibility();
        this.setupAnimations();
    }

    // ===== Navigation =====
    setupNavigation() {
        // sidebar links may not have a special class, use generic selector
        const navItems = document.querySelectorAll('.sidebar .nav-link');
        const currentPath = window.location.pathname;

        navItems.forEach(item => {
            const href = item.getAttribute('href');
            if (href && currentPath.includes(href)) {
                item.classList.add('active');
            }

            item.addEventListener('click', (e) => {
                // Remove active from all items
                navItems.forEach(nav => nav.classList.remove('active'));
                // Add active to clicked item
                item.classList.add('active');
            });
        });

        // Sidebar toggle
        const toggleBtn = document.getElementById('btnToggleSidebar');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }
    }

    toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', 
                sidebar.classList.contains('collapsed'));
        }
    }

    // ===== Search Functionality =====
    setupSearch() {
        const searchInput = document.querySelector('.topbar-search input');
        if (!searchInput) return;

        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const query = e.target.value.trim();

            searchTimeout = setTimeout(() => {
                if (query.length >= 2) {
                    this.performSearch(query);
                }
            }, 300); // Debounce
        });

        // Clear on ESC
        searchInput.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                searchInput.value = '';
                this.closeSearchResults();
            }
        });
    }

    performSearch(query) {
        console.log('Searching for:', query);
        // Implement actual search logic
    }

    closeSearchResults() {
        const results = document.querySelector('.search-results');
        if (results) {
            results.classList.add('hidden');
        }
    }

    // ===== Theme Management =====
    setupTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.setTheme(savedTheme);

        // Listen for system theme changes
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener(
                'change',
                (e) => {
                    if (!localStorage.getItem('theme')) {
                        this.setTheme(e.matches ? 'dark' : 'light');
                    }
                }
            );
        }
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
    }

    // ===== Accessibility =====
    setupAccessibility() {
        // Focus visible class for keyboard navigation
        document.addEventListener('keydown', () => {
            document.body.classList.add('keyboard-nav');
        });

        document.addEventListener('mousedown', () => {
            document.body.classList.remove('keyboard-nav');
        });

        // Skip to main content link
        const skipLink = document.querySelector('.skip-to-main');
        if (skipLink) {
            skipLink.addEventListener('click', (e) => {
                e.preventDefault();
                const mainContent = document.querySelector('main');
                if (mainContent) {
                    mainContent.focus();
                    mainContent.scrollIntoView();
                }
            });
        }
    }

    // ===== Animations =====
    setupAnimations() {
        // Animate on scroll
        this.observeElements();

        // Button ripple effect
        this.setupRippleEffect();
    }

    observeElements() {
        if (!window.IntersectionObserver) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        });

        document.querySelectorAll('[data-animate]').forEach(el => {
            observer.observe(el);
        });
    }

    setupRippleEffect() {
        document.addEventListener('click', (e) => {
            if (!e.target.matches('button, .btn, [role="button"]')) return;

            const btn = e.target.closest('button, .btn, [role="button"]');
            if (!btn) return;

            const ripple = document.createElement('span');
            const rect = btn.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;

            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');

            btn.appendChild(ripple);

            setTimeout(() => ripple.remove(), 600);
        });
    }
}

// ===== Notification System =====
class NotificationManager {
    static show(message, type = 'info', duration = 4000) {
        const container = document.getElementById('notification-container') || 
                         this.createContainer();

        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.setAttribute('role', 'status');
        notification.setAttribute('aria-live', 'polite');

        const icon = this.getIconForType(type);
        notification.innerHTML = `
            <div class="notification-content">
                ${icon}
                <span>${message}</span>
            </div>
            <button class="notification-close" aria-label="Close">
                <i class="icon-close"></i>
            </button>
        `;

        container.appendChild(notification);

        // Close button
        notification.querySelector('.notification-close').addEventListener('click', () => {
            this.remove(notification);
        });

        // Auto remove
        if (duration > 0) {
            setTimeout(() => this.remove(notification), duration);
        }

        return notification;
    }

    static remove(notification) {
        notification.classList.add('notification-exit');
        setTimeout(() => notification.remove(), 300);
    }

    static createContainer() {
        const container = document.createElement('div');
        container.id = 'notification-container';
        container.className = 'notification-container';
        document.body.appendChild(container);
        return container;
    }

    static getIconForType(type) {
        const icons = {
            'success': '<i class="icon-check-circle"></i>',
            'error': '<i class="icon-alert-circle"></i>',
            'warning': '<i class="icon-alert-triangle"></i>',
            'info': '<i class="icon-info-circle"></i>'
        };
        return icons[type] || icons['info'];
    }

    static success(message) { return this.show(message, 'success'); }
    static error(message) { return this.show(message, 'error'); }
    static warning(message) { return this.show(message, 'warning'); }
    static info(message) { return this.show(message, 'info'); }
}

// ===== Modal Dialog =====
class Modal {
    constructor(title, content, options = {}) {
        this.title = title;
        this.content = content;
        this.options = {
            size: 'md',
            showClose: true,
            ...options
        };
        this.create();
    }

    create() {
        // Create backdrop
        this.backdrop = document.createElement('div');
        this.backdrop.className = 'modal-backdrop';
        this.backdrop.addEventListener('click', () => this.close());

        // Create modal
        this.modal = document.createElement('div');
        this.modal.className = `modal modal-${this.options.size}`;

        const closeBtn = this.options.showClose ? 
            `<button class="modal-close" aria-label="Close">
                <i class="icon-x"></i>
            </button>` : '';

        this.modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">${this.title}</h2>
                    ${closeBtn}
                </div>
                <div class="modal-body">
                    ${this.content}
                </div>
                ${this.options.footer || ''}
            </div>
        `;

        // Setup close button
        if (this.options.showClose) {
            this.modal.querySelector('.modal-close')
                .addEventListener('click', () => this.close());
        }

        // ESC to close
        this.handleEscape = (e) => {
            if (e.key === 'Escape') this.close();
        };
    }

    open() {
        document.body.appendChild(this.backdrop);
        document.body.appendChild(this.modal);
        document.addEventListener('keydown', this.handleEscape);
        this.backdrop.classList.add('visible');
        this.modal.classList.add('visible');
    }

    close() {
        this.backdrop.classList.remove('visible');
        this.modal.classList.remove('visible');
        document.removeEventListener('keydown', this.handleEscape);

        setTimeout(() => {
            this.backdrop.remove();
            this.modal.remove();
        }, 300);
    }
}

// ===== Form Validation =====
class FormValidator {
    constructor(formSelector) {
        this.form = document.querySelector(formSelector);
        if (!this.form) return;
        this.setup();
    }

    setup() {
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            if (this.validate()) {
                this.form.submit();
            }
        });

        // Real-time validation
        this.form.querySelectorAll('input, textarea, select').forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
        });
    }

    validate() {
        let isValid = true;
        this.form.querySelectorAll('input, textarea, select').forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateField(input) {
        const value = input.value.trim();
        const required = input.hasAttribute('required');
        let isValid = true;

        // Clear previous error
        this.clearError(input);

        // Required validation
        if (required && !value) {
            this.showError(input, 'Este campo é obrigatório');
            isValid = false;
        }

        // Email validation
        if (input.type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                this.showError(input, 'Email inválido');
                isValid = false;
            }
        }

        // Min length
        if (input.hasAttribute('minlength')) {
            const minLength = parseInt(input.getAttribute('minlength'));
            if (value.length < minLength) {
                this.showError(input, 
                    `Mínimo de ${minLength} caracteres`);
                isValid = false;
            }
        }

        return isValid;
    }

    showError(input, message) {
        input.classList.add('error');
        let errorEl = input.nextElementSibling;
        if (!errorEl || !errorEl.classList.contains('error-message')) {
            errorEl = document.createElement('span');
            errorEl.className = 'error-message';
            input.parentNode.insertBefore(errorEl, input.nextSibling);
        }
        errorEl.textContent = message;
    }

    clearError(input) {
        input.classList.remove('error');
        const errorEl = input.nextElementSibling;
        if (errorEl && errorEl.classList.contains('error-message')) {
            errorEl.remove();
        }
    }
}

// ===== Initialize on Load =====
document.addEventListener('DOMContentLoaded', () => {
    new UIManager();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { UIManager, NotificationManager, Modal, FormValidator };
}
