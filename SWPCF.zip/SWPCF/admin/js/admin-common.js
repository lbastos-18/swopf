/**
 * ADMIN-COMMON.JS - JavaScript comum para todas as páginas admin
 * Gerencia sidebar, topbar, formulários e funcionalidades básicas
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar componentes
    loadSidebar();
    loadTopbar();
    setupFormValidation();
    setupDeleteConfirmation();
    highlightActiveMenu();
});

/**
 * Carrega o sidebar dinamicamente
 */
function loadSidebar() {
    const sidebarContainer = document.getElementById('sidebar-container');
    if (!sidebarContainer) return;
    
    const sidebarHTML = `
        <nav class="sidebar bg-dark text-white" role="navigation">
            <div class="sidebar-header p-4">
                <h5 class="fw-bold mb-0">
                    <i class="fas fa-graduation-cap me-2"></i>SWPCF Admin
                </h5>
                <small class="text-muted">v2.0</small>
            </div>

            <div class="px-3">
                <ul class="nav flex-column gap-2">
                    <li class="nav-item">
                        <a class="nav-link" href="index.html">
                            <i class="fas fa-chart-line"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="vagas-lista.html">
                            <i class="fas fa-briefcase"></i>Vagas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="vagas-adicionar.html">
                            <i class="fas fa-plus"></i>Adicionar Vaga
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="candidatos-lista.html">
                            <i class="fas fa-users"></i>Candidatos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="candidatos-gerenciar.html">
                            <i class="fas fa-user-cog"></i>Gerir Candidatos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="candidaturas.html">
                            <i class="fas fa-file-alt"></i>Candidaturas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cursos-lista.html">
                            <i class="fas fa-book"></i>Cursos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="cursos-adicionar.html">
                            <i class="fas fa-plus"></i>Adicionar Curso
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="estagios-lista.html">
                            <i class="fas fa-clipboard-list"></i>Estágios
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="relatorios.html">
                            <i class="fas fa-chart-bar"></i>Relatórios
                        </a>
                    </li>
                </ul>
            </div>

            <hr class="my-4 mx-3" style="border-color: rgba(255,255,255,0.2);">

            <div class="user-section px-3 pb-4">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center" 
                         style="width: 40px; height: 40px;">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="flex-grow-1">
                        <p class="mb-0 small fw-bold">Admin</p>
                        <small class="text-muted">admin@swpcf.ao</small>
                    </div>
                </div>
                <a href="../index.php?logout=true" class="btn btn-sm btn-outline-light w-100">
                    <i class="fas fa-sign-out-alt me-2"></i>Sair
                </a>
            </div>
        </nav>
    `;
    
    sidebarContainer.innerHTML = sidebarHTML;
    highlightActiveMenu();
}

/**
 * Carrega o topbar dinamicamente
 */
function loadTopbar() {
    const topbarContainer = document.getElementById('topbar-container');
    if (!topbarContainer) return;
    
    const topbarHTML = `
        <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm" style="position: sticky; top: 0; z-index: 999;">
            <div class="container-fluid px-4">
                <button class="btn btn-sm btn-light d-lg-none me-2" id="btnToggleSidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <span class="navbar-text fw-bold" id="page-title">Página</span>
                <div class="ms-auto">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-bell me-2"></i>
                            <span class="badge bg-danger">0</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#">Sem notificações</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    `;
    
    topbarContainer.innerHTML = topbarHTML;
    setupMobileToggle();
}

/**
 * Destaca o menu ativo
 */
function highlightActiveMenu() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.sidebar .nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

/**
 * Configurar toggle do sidebar em mobile
 */
function setupMobileToggle() {
    const toggleBtn = document.getElementById('btnToggleSidebar');
    const sidebar = document.querySelector('.sidebar');
    
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('show');
        });
        
        // Fechar ao clicar num link
        document.querySelectorAll('.sidebar .nav-link').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth < 769) {
                    sidebar.classList.remove('show');
                }
            });
        });
    }
}

/**
 * Validação de formulários
 */
function setupFormValidation() {
    const forms = document.querySelectorAll('form[data-validate]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
                e.stopPropagation();
            }
            this.classList.add('was-validated');
        });
    });
}

/**
 * Validar formulário
 */
function validateForm(form) {
    let isValid = true;
    const fields = form.querySelectorAll('[required]');
    
    fields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    
    return isValid;
}

/**
 * Confirmar antes de deletar
 */
function setupDeleteConfirmation() {
    document.addEventListener('click', function(e) {
        if (e.target.closest('[data-delete]')) {
            if (!confirm('Tem certeza que deseja deletar? Esta ação não pode ser desfeita.')) {
                e.preventDefault();
            }
        }
    });
}

/**
 * Mostrar notificação
 */
function showNotification(message, type = 'success', duration = 3000) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('main') || document.body;
    container.insertBefore(alertDiv, container.firstChild);
    
    if (duration > 0) {
        setTimeout(() => alertDiv.remove(), duration);
    }
}

/**
 * Fazer requisição API com tratamento de erro
 */
async function apiRequest(endpoint, options = {}) {
    const defaultOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    };
    
    const finalOptions = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(endpoint, finalOptions);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Erro na requisição');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        showNotification('Erro: ' + error.message, 'danger');
        throw error;
    }
}

/**
 * Formatar data para PT-PT
 */
function formatDate(date) {
    return new Date(date).toLocaleDateString('pt-PT', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });
}

/**
 * Formatar moeda
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-PT', {
        style: 'currency',
        currency: 'AOA'
    }).format(value);
}

// Exportar funções para uso global
window.Admin = {
    showNotification,
    apiRequest,
    validateForm,
    formatDate,
    formatCurrency
};
            e.stopPropagation();
            sidebar.classList.toggle('show');
            const isShown = sidebar.classList.contains('show');
            btnToggle.setAttribute('aria-expanded', isShown ? 'true' : 'false');
            sidebar.setAttribute('aria-hidden', isShown ? 'false' : 'true');
        });
        
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !btnToggle.contains(e.target)) {
                sidebar.classList.remove('show');
                btnToggle.setAttribute('aria-expanded', 'false');
                sidebar.setAttribute('aria-hidden', 'true');
            }
        });
        
        const navLinks = sidebar.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth < 768) {
                    sidebar.classList.remove('show');
                }
            });
        });
    }
}

function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'login.html';
    }
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('pt-PT', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatCurrency(value) {
    return new Intl.NumberFormat('pt-PT', {
        style: 'currency',
        currency: 'EUR'
    }).format(value);
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
    `;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 5000);
}

function createStatCard(titulo, valor, icone, cor) {
    return `
        <div class="col-md-6 col-lg-3">
            <div class="card stat-card shadow-sm">
                <div class="card-body">
                    <div class="stat-icon" style="background-color: ${cor}20; color: ${cor};">
                        <i class="bi ${icone}"></i>
                    </div>
                    <div class="stat-value" style="color: ${cor};">${valor}</div>
                    <p class="stat-label mb-0">${titulo}</p>
                </div>
            </div>
        </div>
    `;
}

function createTable(headers, rows) {
    let html = '<table class="table admin-table mb-0"><thead><tr>';
    headers.forEach(header => html += `<th>${header}</th>`);
    html += '</tr></thead><tbody>';
    rows.forEach(row => {
        html += '<tr>';
        row.forEach(cell => html += `<td>${cell}</td>`);
        html += '</tr>';
    });
    html += '</tbody></table>';
    return html;
}

function confirmAction(message) {
    return confirm(message);
}

function truncateText(text, length = 50) {
    if (!text) return '';
    return text.length > length ? text.substring(0, length) + '...' : text;
}

function formatStatusCandidatura(status) {
    const statuses = {
        'pendente': 'Pendente',
        'aguardando_entrevista': 'Aguardando Entrevista',
        'entrevistado': 'Entrevistado',
        'aprovado': 'Aprovado',
        'rejeitado': 'Rejeitado',
        'cancelado': 'Cancelado'
    };
    return statuses[status] || status;
}

function formatTipoContrato(tipo) {
    const tipos = {
        'permanente': 'Permanente',
        'termo_certo': 'Termo Certo',
        'estagio': 'Estágio',
        'freelance': 'Freelance'
    };
    return tipos[tipo] || tipo;
}
