const api = new APIClient();
let allEstagios = [];
let currentPage = 1;
const itemsPerPage = 10;
let currentEstagioId = null;

async function carregarEstagios() {
    try {
        const response = await api.get('/api/estagios');
        allEstagios = response.estagios || [];
        exibirEstagios(allEstagios.slice(0, itemsPerPage));
        gerarPaginacao(allEstagios.length);
        carregarEscolas();
    } catch (error) {
        console.error('Erro ao carregar estágios:', error);
        alert('Erro ao carregar estágios');
    }
}

function exibirEstagios(estagios) {
    const table = document.getElementById('estagiosTable');

    if (estagios.length === 0) {
        table.innerHTML = '<tr><td colspan="9" class="text-center py-4">Nenhum estágio encontrado</td></tr>';
        return;
    }

    table.innerHTML = estagios.map(estagio => `
        <tr>
            <td><strong>${estagio.titulo}</strong></td>
            <td>
                <span class="badge ${estagio.tipo === 'remunerado' ? 'bg-success' : 'bg-secondary'}">
                    ${estagio.tipo === 'remunerado' ? 'Remunerado' : 'Não Remunerado'}
                </span>
            </td>
            <td>${estagio.area}</td>
            <td>${estagio.duracao} semanas</td>
            <td>${estagio.numero_vagas}</td>
            <td>${new Date(estagio.data_limite).toLocaleDateString('pt-PT')}</td>
            <td>
                <span class="badge ${estagio.status === 'ativo' ? 'bg-success' : 'bg-danger'}">
                    ${estagio.status === 'ativo' ? 'Ativo' : 'Encerrado'}
                </span>
            </td>
            <td><span class="badge bg-info">0</span></td>
            <td>
                <div class="btn-group btn-group-sm" role="group">
                    <button class="btn btn-outline-primary" onclick="editarEstagio(${estagio.id})" title="Editar">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-outline-danger" onclick="encerrarEstagio(${estagio.id})" title="Encerrar">
                        <i class="fas fa-lock"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

function gerarPaginacao(total) {
    const paginas = Math.ceil(total / itemsPerPage);
    const paginationEl = document.getElementById('pagination');

    let html = '';
    for (let i = 1; i <= paginas; i++) {
        html += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="irParaPagina(${i})">${i}</a>
            </li>
        `;
    }

    paginationEl.innerHTML = html;
}

function irParaPagina(pagina) {
    currentPage = pagina;
    const inicio = (pagina - 1) * itemsPerPage;
    const fim = inicio + itemsPerPage;
    exibirEstagios(allEstagios.slice(inicio, fim));
    gerarPaginacao(allEstagios.length);
}

async function carregarEscolas() {
    try {
        const response = await api.get('/api/escolas/ativas');
        const select = document.getElementById('escola_restrita');
        
        response.escolas.forEach(escola => {
            const option = document.createElement('option');
            option.value = escola.id;
            option.textContent = escola.nome;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Erro ao carregar escolas:', error);
    }
}

async function salvarEstagio() {
    const form = document.getElementById('estagioForm');
    
    if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }

    const dados = {
        titulo: document.getElementById('titulo').value,
        descricao: document.getElementById('descricao').value,
        tipo: document.getElementById('tipo').value,
        bolsa_remuneracao: document.getElementById('tipo').value === 'remunerado' 
            ? parseFloat(document.getElementById('bolsa').value) 
            : null,
        area: document.getElementById('area').value,
        duracao: parseInt(document.getElementById('duracao').value),
        numero_vagas: parseInt(document.getElementById('numero_vagas').value),
        data_limite: document.getElementById('data_limite').value,
        escola_restrita_id: document.getElementById('escola_restrita').value || null
    };

    try {
        if (currentEstagioId) {
            await api.put(`/api/estagios/${currentEstagioId}`, dados);
            alert('Estágio atualizado com sucesso!');
        } else {
            await api.post('/api/estagios', dados);
            alert('Estágio criado com sucesso!');
        }

        form.classList.remove('was-validated');
        form.reset();
        currentEstagioId = null;
        document.getElementById('estagioModalTitle').textContent = 'Novo Estágio';
        
        const modal = bootstrap.Modal.getInstance(document.getElementById('estagioModal'));
        modal.hide();
        
        carregarEstagios();
    } catch (error) {
        console.error('Erro ao salvar estágio:', error);
        alert('Erro ao salvar estágio');
    }
}

async function editarEstagio(id) {
    try {
        const estagio = await api.get(`/api/estagios/${id}`);
        
        document.getElementById('titulo').value = estagio.titulo;
        document.getElementById('descricao').value = estagio.descricao;
        document.getElementById('tipo').value = estagio.tipo;
        document.getElementById('bolsa').value = estagio.bolsa_remuneracao || '';
        document.getElementById('area').value = estagio.area;
        document.getElementById('duracao').value = estagio.duracao;
        document.getElementById('numero_vagas').value = estagio.numero_vagas;
        document.getElementById('data_limite').value = estagio.data_limite;
        document.getElementById('escola_restrita').value = estagio.escola_restrita_id || '';

        currentEstagioId = id;
        document.getElementById('estagioModalTitle').textContent = 'Editar Estágio';
        
        const modal = new bootstrap.Modal(document.getElementById('estagioModal'));
        modal.show();
    } catch (error) {
        console.error('Erro ao carregar estágio:', error);
        alert('Erro ao carregar estágio');
    }
}

async function encerrarEstagio(id) {
    if (!confirm('Tem a certeza que deseja encerrar este estágio?')) {
        return;
    }

    try {
        await api.put(`/api/estagios/${id}/close`);
        alert('Estágio encerrado com sucesso!');
        carregarEstagios();
    } catch (error) {
        console.error('Erro ao encerrar estágio:', error);
        alert('Erro ao encerrar estágio');
    }
}

function aplicarFiltros() {
    const tipo = document.getElementById('filterTipo').value;
    const area = document.getElementById('filterArea').value.toLowerCase();
    const status = document.getElementById('filterStatus').value;

    let filtrados = allEstagios;

    if (tipo) {
        filtrados = filtrados.filter(e => e.tipo === tipo);
    }
    if (area) {
        filtrados = filtrados.filter(e => e.area.toLowerCase().includes(area));
    }
    if (status) {
        filtrados = filtrados.filter(e => e.status === status);
    }

    currentPage = 1;
    exibirEstagios(filtrados.slice(0, itemsPerPage));
    gerarPaginacao(filtrados.length);
}

// Alternar entre campos de bolsa conforme o tipo
document.addEventListener('DOMContentLoaded', function() {
    const tipoSelect = document.getElementById('tipo');
    const bolsaInput = document.getElementById('bolsa');

    tipoSelect.addEventListener('change', function() {
        bolsaInput.disabled = this.value !== 'remunerado';
        if (this.value !== 'remunerado') {
            bolsaInput.value = '';
        }
    });

    // Limpar form ao abrir modal
    const modal = document.getElementById('estagioModal');
    modal.addEventListener('show.bs.modal', function() {
        if (!currentEstagioId) {
            document.getElementById('estagioForm').reset();
            document.getElementById('estagioForm').classList.remove('was-validated');
        }
    });

    // Carregar dados iniciais
    carregarEstagios();
});
