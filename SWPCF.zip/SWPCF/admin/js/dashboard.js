/**
 * Dashboard Admin
 */

let statsData = {};

document.addEventListener('DOMContentLoaded', async () => {
    await loadStats();
    await loadCharts();
});

/**
 * Criar card de estatística
 */
function createStatCard(title, value, icon, color) {
    return `
        <div class="col-md-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <p class="text-muted small mb-1">${title}</p>
                            <h3 class="mb-0">${value}</h3>
                        </div>
                        <i class="bi ${icon} fs-1 opacity-25"></i>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Carregar estatísticas com fallback
 */
async function loadStats() {
    try {
        // Dados mock para fallback
        const mockStats = {
            totalVagas: 45,
            totalCandidatos: 128,
            totalCandidaturas: 256,
            totalCursos: 8
        };

        // Tentar carregar da API com timeout
        let stats = {
            totalVagas: mockStats.totalVagas,
            totalCandidatos: mockStats.totalCandidatos,
            totalCandidaturas: mockStats.totalCandidaturas,
            totalCursos: mockStats.totalCursos
        };

        try {
            // Simular tentativa de API com timeout de 3 segundos
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 3000);

            const res = await fetch('../api/index.php', {
                signal: controller.signal,
                headers: {
                    'Accept': 'application/json'
                }
            }).then(r => r.json()).catch(e => null);

            clearTimeout(timeoutId);

            if (res?.data) {
                stats = {
                    totalVagas: res.data.vagas || mockStats.totalVagas,
                    totalCandidatos: res.data.candidatos || mockStats.totalCandidatos,
                    totalCandidaturas: res.data.candidaturas || mockStats.totalCandidaturas,
                    totalCursos: res.data.cursos || mockStats.totalCursos
                };
            }
        } catch (apiError) {
            console.log('API não disponível, usando dados mock');
        }

        // Renderizar cards
        const container = document.getElementById('statsContainer');
        if (container) {
            container.innerHTML = `
                ${createStatCard('Total de Vagas', stats.totalVagas, 'bi-briefcase', '#667eea')}
                ${createStatCard('Candidatos', stats.totalCandidatos, 'bi-people', '#10b981')}
                ${createStatCard('Candidaturas', stats.totalCandidaturas, 'bi-file-earmark', '#f59e0b')}
                ${createStatCard('Cursos Ativos', stats.totalCursos, 'bi-journal-text', '#ef4444')}
            `;
        }

        statsData = stats;

    } catch (error) {
        console.error('Erro ao carregar estatísticas:', error);
        // Mostrar dados mock como fallback
        const container = document.getElementById('statsContainer');
        if (container) {
            container.innerHTML = `
                ${createStatCard('Total de Vagas', 45, 'bi-briefcase', '#667eea')}
                ${createStatCard('Candidatos', 128, 'bi-people', '#10b981')}
                ${createStatCard('Candidaturas', 256, 'bi-file-earmark', '#f59e0b')}
                ${createStatCard('Cursos Ativos', 8, 'bi-journal-text', '#ef4444')}
            `;
        }
    }
}

/**
 * Carregar gráficos
 */
async function loadCharts() {
    try {
        // Gráfico de Candidaturas por Status
        const ctxCandidaturas = document.getElementById('chartCandidaturas');
        if (ctxCandidaturas) {
            new Chart(ctxCandidaturas, {
                type: 'doughnut',
                data: {
                    labels: ['Pendentes', 'Aceites', 'Rejeitadas'],
                    datasets: [{
                        data: [45, 30, 25],
                        backgroundColor: [
                            '#f59e0b',
                            '#10b981',
                            '#ef4444'
                        ],
                        borderColor: '#fff',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        }
                    }
                }
            });
        }

        // Gráfico de Vagas Ativas
        const ctxVagas = document.getElementById('chartVagas');
        if (ctxVagas) {
            new Chart(ctxVagas, {
                type: 'bar',
                data: {
                    labels: ['Desenvolvimento', 'Marketing', 'Design', 'RH', 'Outros'],
                    datasets: [{
                        label: 'Vagas Ativas',
                        data: [12, 8, 6, 5, 14],
                        backgroundColor: '#667eea',
                        borderColor: '#667eea',
                        borderWidth: 1
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

    } catch (error) {
        console.error('Erro ao carregar gráficos:', error);
    }
}

/**
 * Logout
 */
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

