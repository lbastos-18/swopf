/**
 * Gerenciamento de Candidatos - Admin
 */

// Variáveis globais
let paginaAtual = 1;
let filtroAtual = '';
let statusAtual = '';

// Provincias de Angola
const provinciasAngola = [
    'Bengo', 'Benguela', 'Bié', 'Cabinda', 'Cuando Cubango',
    'Cuanza Norte', 'Cuanza Sul', 'Cunene', 'Huambo', 'Huíla',
    'Luanda', 'Lunda Norte', 'Lunda Sul', 'Malanje', 'Moxico', 'Namibe'
];

/**
 * Inicializar página
 */
document.addEventListener('DOMContentLoaded', async function() {
    try {
        // Preencher selectores de província
        preencherProvincias();
        
        // Carregar candidatos
        await carregarCandidatos(1);
        
        // Carregar estatísticas
        await carregarEstatisticas();
        
        // Event listeners
        document.getElementById('btnPesquisar').addEventListener('click', pesquisarCandidatos);
        document.getElementById('filtroSearch').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') pesquisarCandidatos();
        });
        document.getElementById('filtroStatus').addEventListener('change', pesquisarCandidatos);
        document.getElementById('btnLimpar').addEventListener('click', limparFiltros);
        document.getElementById('btnExportar').addEventListener('click', exportarCSV);
        
        // Modais
        document.getElementById('btnSalvarNovo').addEventListener('click', criarCandidato);
        document.getElementById('btnSalvarEdicao').addEventListener('click', salvarEdicao);
        document.getElementById('selectAll').addEventListener('change', seleccionarTodos);
        
    } catch (erro) {
        console.error('Erro ao inicializar:', erro);
        mostrarNotificacao('Erro ao carregar página', 'danger');
    }
});

/**
 * Preencher selectores de província
 */
function preencherProvincias() {
    const selects = ['provinciaSelect', 'provinciaSelectEdit'];
    
    selects.forEach(id => {
        const select = document.getElementById(id);
        if (select) {
            provinciasAngola.forEach(provincia => {
                const option = document.createElement('option');
                option.value = provincia;
                option.textContent = provincia;
                select.appendChild(option);
            });
        }
    });
}

/**
 * Carregar lista de candidatos
 */
async function carregarCandidatos(pagina = 1) {
    try {
        const bodyTabela = document.getElementById('bodyTabela');
        bodyTabela.innerHTML = '<tr><td colspan="10" class="text-center"><i class="fas fa-spinner fa-spin"></i> Carregando...</td></tr>';
        
        // Usar MockAPI para desenvolvimento frontend
        const params = {
            pagina: pagina,
            filtro: filtroAtual,
            status: statusAtual
        };
        
        const resultado = await window.mockAPI.getCandidatos(params);
        
        if (!resultado.success) {
            throw new Error(resultado.message || 'Erro ao carregar candidatos');
        }
        
        // Renderizar tabela
        if (resultado.candidatos.length === 0) {
            bodyTabela.innerHTML = '<tr><td colspan="10" class="text-center text-muted py-4">Nenhum candidato encontrado</td></tr>';
        } else {
            bodyTabela.innerHTML = resultado.candidatos.map(candidato => `
                <tr>
                    <td><input type="checkbox" class="candidato-check" value="${candidato.id}"></td>
                    <td><strong>${candidato.nome}</strong></td>
                    <td>${candidato.email}</td>
                    <td>${candidato.telefone}</td>
                    <td>${candidato.numero_documento}</td>
                    <td>${candidato.provincia || '-'}</td>
                    <td>
                        ${candidato.telefone_validado ? 
                            '<span class="badge bg-success">Validado</span>' : 
                            '<span class="badge bg-warning">Pendente</span>'}
                    </td>
                    <td>${candidato.total_cursos || 0}</td>
                    <td>${formatarData(candidato.data_registo)}</td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="verDetalhes(${candidato.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="abrirEditarModal(${candidato.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="apagarCandidato(${candidato.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }
        
        // Renderizar paginação
        renderizarPaginacao(resultado.pagina, resultado.total_paginas);
        
        // Atualizar paginação global
        paginaAtual = pagina;
        
    } catch (erro) {
        console.error('Erro:', erro);
        document.getElementById('bodyTabela').innerHTML = `
            <tr><td colspan="10" class="text-center text-danger py-4">
                <i class="fas fa-exclamation-circle"></i> ${erro.message}
            </td></tr>
        `;
        mostrarNotificacao(erro.message, 'danger');
    }
}

/**
 * Carregar estatísticas
 */
async function carregarEstatisticas() {
    try {
        // Usar MockAPI para desenvolvimento frontend
        const resultado = await window.mockAPI.getStats();
        
        if (resultado.success && resultado.stats) {
            const stats = resultado.stats;
            document.getElementById('stat-total').textContent = stats.total_candidatos || 0;
            document.getElementById('stat-validado').textContent = stats.telefone_validado || 0;
            document.getElementById('stat-mes').textContent = stats.registados_mes || 0;
            document.getElementById('stat-cursos').textContent = stats.total_inscricoes_cursos || 0;
        }
    } catch (erro) {
        console.error('Erro ao carregar estatísticas:', erro);
    }
}

/**
 * Pesquisar candidatos
 */
async function pesquisarCandidatos() {
    filtroAtual = document.getElementById('filtroSearch').value;
    statusAtual = document.getElementById('filtroStatus').value;
    await carregarCandidatos(1);
}

/**
 * Limpar filtros
 */
async function limparFiltros() {
    document.getElementById('filtroSearch').value = '';
    document.getElementById('filtroStatus').value = '';
    filtroAtual = '';
    statusAtual = '';
    await carregarCandidatos(1);
}

/**
 * Abrir modal para editar candidato
 */
async function abrirEditarModal(id) {
    try {
        // Usar MockAPI para desenvolvimento frontend
        const resultado = await window.mockAPI.getCandidato(id);
        
        if (!resultado.success) {
            throw new Error('Erro ao carregar dados do candidato');
        }
        
        const candidato = resultado.candidato;
        const form = document.getElementById('formEditarCandidato');
        
        document.getElementById('candidatoEditId').value = candidato.id;
        form.nome.value = candidato.nome;
        form.email.value = candidato.email;
        form.numero_documento.value = candidato.numero_documento;
        form.telefone.value = candidato.telefone;
        form.data_nascimento.value = candidato.data_nascimento || '';
        form.genero.value = candidato.genero || 'Outro';
        form.endereco.value = candidato.endereco || '';
        form.provincia.value = candidato.provincia || '';
        
        // Abrir modal
        const modal = new bootstrap.Modal(document.getElementById('editarModal'));
        modal.show();
        
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarNotificacao(erro.message, 'danger');
    }
}

/**
 * Ver detalhes do candidato
 */
async function verDetalhes(id) {
    try {
        // Usar MockAPI para desenvolvimento frontend
        const resultado = await window.mockAPI.getCandidato(id);
        
        if (!resultado.success) {
            throw new Error('Erro ao carregar detalhes');
        }
        
        const candidato = resultado.candidato;
        const cursos = resultado.cursos || [];
        const candidaturas = resultado.candidaturas || [];
        
        let htmlCursos = '';
        if (cursos.length > 0) {
            htmlCursos = `
                <h6>Cursos (${cursos.length})</h6>
                <div class="list-group list-group-sm mb-3">
                    ${cursos.map(curso => `
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="mb-1">${curso.titulo}</h6>
                                    <span class="badge bg-secondary">${curso.status}</span>
                                </div>
                                <small class="text-muted">${curso.duracao} horas</small>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }
        
        let htmlCandidaturas = '';
        if (candidaturas.length > 0) {
            htmlCandidaturas = `
                <h6>Candidaturas (${candidaturas.length})</h6>
                <div class="list-group list-group-sm mb-3">
                    ${candidaturas.map(cand => `
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="mb-1">${cand.estagio_titulo || 'N/A'}</h6>
                                    <span class="badge bg-info">${cand.status}</span>
                                </div>
                                <small class="text-muted">${formatarData(cand.criado_em)}</small>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }
        
        const html = `
            <div class="row mb-3">
                <div class="col-md-6">
                    <h6 class="text-muted">Nome</h6>
                    <p><strong>${candidato.nome}</strong></p>
                </div>
                <div class="col-md-6">
                    <h6 class="text-muted">Email</h6>
                    <p>${candidato.email}</p>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <h6 class="text-muted">Telefone</h6>
                    <p>${candidato.telefone}</p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">BI</h6>
                    <p>${candidato.numero_documento}</p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Província</h6>
                    <p>${candidato.provincia || '-'}</p>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <h6 class="text-muted">Data Nascimento</h6>
                    <p>${candidato.data_nascimento || '-'}</p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Género</h6>
                    <p>${candidato.genero || '-'}</p>
                </div>
                <div class="col-md-4">
                    <h6 class="text-muted">Registado em</h6>
                    <p>${formatarData(candidato.data_registo)}</p>
                </div>
            </div>
            ${htmlCursos}
            ${htmlCandidaturas}
        `;
        
        document.getElementById('detalhesContent').innerHTML = html;
        const modal = new bootstrap.Modal(document.getElementById('detalhesModal'));
        modal.show();
        
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarNotificacao(erro.message, 'danger');
    }
}

/**
 * Criar novo candidato
 */
async function criarCandidato() {
    try {
        const form = document.getElementById('formNovoCandidato');
        
        // Validar senhas
        if (form.senha.value !== form.confirmar_senha.value) {
            mostrarNotificacao('As senhas não combinam', 'warning');
            return;
        }
        
        const dados = {
            nome: form.nome.value,
            email: form.email.value,
            senha: form.senha.value,
            numero_documento: form.numero_documento.value,
            telefone: form.telefone.value,
            data_nascimento: form.data_nascimento.value || null,
            genero: form.genero.value,
            endereco: form.endereco.value || null,
            provincia: form.provincia.value || null
        };
        
        // Usar MockAPI para desenvolvimento frontend
        const resultado = await window.mockAPI.createCandidato(dados);
        
        if (!resultado.success) {
            throw new Error(resultado.message || 'Erro ao criar candidato');
        }
        
        mostrarNotificacao('Candidato criado com sucesso', 'success');
        
        // Fechar modal e recarregar
        bootstrap.Modal.getInstance(document.getElementById('novoModal')).hide();
        form.reset();
        await carregarCandidatos(1);
        await carregarEstatisticas();
        
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarNotificacao(erro.message, 'danger');
    }
}

/**
 * Salvar edição de candidato
 */
async function salvarEdicao() {
    try {
        const id = document.getElementById('candidatoEditId').value;
        const form = document.getElementById('formEditarCandidato');
        
        const dados = {
            nome: form.nome.value,
            email: form.email.value,
            numero_documento: form.numero_documento.value,
            telefone: form.telefone.value,
            data_nascimento: form.data_nascimento.value || null,
            genero: form.genero.value,
            endereco: form.endereco.value || null,
            provincia: form.provincia.value || null
        };
        
        const response = await fetch(`/api/index.php?endpoint=admin/alunos&id=${id}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        
        const resultado = await response.json();
        
        if (!resultado.success) {
            throw new Error(resultado.message || 'Erro ao guardar alterações');
        }
        
        mostrarNotificacao('Candidato actualizado com sucesso', 'success');
        bootstrap.Modal.getInstance(document.getElementById('editarModal')).hide();
        await carregarCandidatos(paginaAtual);
        
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarNotificacao(erro.message, 'danger');
    }
}

/**
 * Apagar candidato
 */
async function apagarCandidato(id) {
    if (!confirm('Tem a certeza que deseja apagar este candidato? Esta acção não pode ser desfeita.')) {
        return;
    }
    
    try {
        // Usar MockAPI para desenvolvimento frontend
        const resultado = await window.mockAPI.deleteCandidato(id);
        
        if (!resultado.success) {
            throw new Error(resultado.message || 'Erro ao apagar candidato');
        }
        
        mostrarNotificacao('Candidato apagado com sucesso', 'success');
        await carregarCandidatos(paginaAtual);
        await carregarEstatisticas();
        
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarNotificacao(erro.message, 'danger');
    }
}

/**
 * Seleccionar todos os candidatos da página
 */
function seleccionarTodos() {
    const checkboxes = document.querySelectorAll('.candidato-check');
    const selecionarTodos = document.getElementById('selectAll').checked;
    checkboxes.forEach(cb => cb.checked = selecionarTodos);
}

/**
 * Exportar para CSV
 */
async function exportarCSV() {
    try {
        // Usar MockAPI para desenvolvimento frontend
        await window.mockAPI.exportCSV();
        mostrarNotificacao('CSV exportado com sucesso', 'success');
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarNotificacao('Erro ao exportar CSV', 'danger');
    }
}

/**
 * Renderizar paginação
 */
function renderizarPaginacao(paginaAtual, totalPaginas) {
    const container = document.getElementById('paginacao');
    container.innerHTML = '';
    
    // Botão anterior
    const btnAnterior = document.createElement('li');
    btnAnterior.className = `page-item ${paginaAtual === 1 ? 'disabled' : ''}`;
    btnAnterior.innerHTML = `<a class="page-link" href="#" onclick="carregarCandidatos(${paginaAtual - 1}); return false;">Anterior</a>`;
    container.appendChild(btnAnterior);
    
    // Números de páginas
    for (let i = 1; i <= totalPaginas; i++) {
        if (i === 1 || i === totalPaginas || (i >= paginaAtual - 1 && i <= paginaAtual + 1)) {
            const li = document.createElement('li');
            li.className = `page-item ${i === paginaAtual ? 'active' : ''}`;
            li.innerHTML = `<a class="page-link" href="#" onclick="carregarCandidatos(${i}); return false;">${i}</a>`;
            container.appendChild(li);
        }
    }
    
    // Botão próximo
    const btnProximo = document.createElement('li');
    btnProximo.className = `page-item ${paginaAtual === totalPaginas ? 'disabled' : ''}`;
    btnProximo.innerHTML = `<a class="page-link" href="#" onclick="carregarCandidatos(${paginaAtual + 1}); return false;">Próximo</a>`;
    container.appendChild(btnProximo);
}

/**
 * Formatar data
 */
function formatarData(dataString) {
    if (!dataString) return '-';
    const data = new Date(dataString);
    return new Intl.DateTimeFormat('pt-PT', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(data);
}

/**
 * Mostrar notificação
 */
function mostrarNotificacao(mensagem, tipo = 'info') {
    const toast = document.getElementById('toastNotificacao');
    const toastMensagem = document.getElementById('toastMensagem');
    
    toastMensagem.textContent = mensagem;
    toast.className = `toast`;
    
    // Aplicar classe de tipo ao body
    if (tipo === 'danger') {
        toast.classList.add('bg-danger');
    } else if (tipo === 'success') {
        toast.classList.add('bg-success');
    } else if (tipo === 'warning') {
        toast.classList.add('bg-warning');
    }
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
}
