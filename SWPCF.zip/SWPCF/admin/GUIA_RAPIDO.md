# 🚀 Guia Rápido - SWPCF Admin v2.0

## ✅ O que foi feito

Seu projeto SWPCF foi **completamente corrigido e modernizado**. Aqui está o resultado:

### Problemas Resolvidos
- ✅ **Menu sobrepondo conteúdo** - Agora usa layout flexbox correto
- ✅ **Páginas incompletas** - Todas as páginas foram criadas e preenchidas
- ✅ **Sem menu para redirecionar** - Sidebar dinâmico em todas as páginas
- ✅ **Erros nos formulários** - Validação automática implementada
- ✅ **Falta de CSS** - CSS unificado sem código repetido
- ✅ **Bugs diversos** - Código refatorado e simplificado

---

## 📁 Ficheiros Principais

### CSS Unificado
```
admin/css/admin-unified.css
```
Este ficheiro contém TODOS os estilos necessários. Substitui os antigos admin.css, responsive.css, etc.

### JavaScript Comum
```
admin/js/admin-common.js
```
Carrega automaticamente o sidebar, topbar, validação e notificações em TODAS as páginas.

### Páginas Admin
Todas as páginas estão em `admin/` e funcionam perfeitamente:
- index.html (Dashboard)
- vagas-lista.html
- vagas-adicionar.html
- candidatos-lista.html
- candidatos-gerenciar.html
- cursos-lista.html
- cursos-adicionar.html
- estagios-lista.html
- candidaturas.html
- relatorios.html

---

## 🎯 Como Usar

### 1. Abrir no Browser
```
Basta abrir qualquer ficheiro HTML da pasta admin/ em um browser.
Ex: http://localhost/SWPCF/admin/index.html
```

### 2. Testar Responsividade
```
- Desktop: Vê o sidebar fixo à esquerda
- Tablet (769px-1024px): Sidebar reduzido
- Mobile (< 768px): Sidebar como drawer (clique no ☰ para abrir)
```

### 3. Adicionar Novo Formulário
```html
<form id="meuForm" data-validate>
    <input type="text" name="nome" required>
    <input type="email" name="email" required>
    <button type="submit">Enviar</button>
</form>

<script>
document.getElementById('meuForm').addEventListener('submit', function(e) {
    e.preventDefault();
    Admin.showNotification('Formulário enviado!', 'success');
});
</script>
```

### 4. Mostrar Notificações
```javascript
// Sucesso (verde)
Admin.showNotification('Operação realizada!', 'success');

// Erro (vermelho)
Admin.showNotification('Erro ao processar!', 'danger');

// Aviso (amarelo)
Admin.showNotification('Atenção!', 'warning');

// Informação (azul)
Admin.showNotification('Informação!', 'info');
```

### 5. Criar Card com Stats
```html
<div class="card stat-card">
    <div class="card-body">
        <p class="text-muted small mb-1">Total de Vagas</p>
        <h3 class="fw-bold">150</h3>
    </div>
</div>

<!-- Com cor diferente -->
<div class="card stat-card" style="border-left-color: #10b981;">
    <!-- conteúdo -->
</div>
```

---

## 🎨 Cores Disponíveis

```
Primário:   #0066ff   (Azul)
Verde:      #10b981   (Verde Escuro)
Amarelo:    #f59e0b   (Aviso)
Vermelho:   #ef4444   (Perigo)
Azul Claro: #3b82f6   (Info)
```

---

## 📱 Layout Responsivo

O layout ajusta automaticamente:

| Resolução | Sidebar | Layout |
|-----------|---------|--------|
| > 1024px  | 250px fixo | Lado a lado |
| 768-1024px | 220px fixo | Lado a lado |
| < 768px   | Drawer | Drawer + Conteúdo |

---

## 🔧 Estrutura Padrão de Página

Todas as novas páginas devem seguir este padrão:

```html
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome da Página - SWPCF Admin</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/admin-unified.css">
</head>
<body>
    <!-- Sidebar dinâmico -->
    <div id="sidebar-container"></div>
    
    <!-- Conteúdo -->
    <div class="main-content">
        <!-- Topbar dinâmico -->
        <div id="topbar-container"></div>
        
        <!-- Sua página aqui -->
        <main>
            <div class="page-header mb-4">
                <h1><i class="fas fa-icon"></i>Título da Página</h1>
                <p class="text-muted">Descrição</p>
            </div>
            
            <!-- Conteúdo específico -->
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/admin-common.js"></script>
</body>
</html>
```

---

## 💡 Exemplos Prontos para Usar

### Tabela Simples
```html
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>João Silva</td>
                    <td>joao@example.com</td>
                    <td>
                        <button class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
```

### Cards com Grid
```html
<div class="row g-4">
    <div class="col-md-4">
        <div class="card stat-card">
            <div class="card-body">
                <p class="text-muted small">Métrica 1</p>
                <h3 class="fw-bold">100</h3>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card stat-card" style="border-left-color: #10b981;">
            <div class="card-body">
                <p class="text-muted small">Métrica 2</p>
                <h3 class="fw-bold">200</h3>
            </div>
        </div>
    </div>
</div>
```

### Formulário Modal
```html
<div class="modal fade" id="meuModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Novo Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="meuForm" data-validate>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nome</label>
                        <input type="text" class="form-control" name="nome" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>
```

---

## 📊 Integração com API

Para conectar com sua API backend:

```javascript
// Exemplo: Carregar candidatos
async function carregarCandidatos() {
    try {
        const dados = await Admin.apiRequest('/api/candidatos');
        console.log(dados);
    } catch (erro) {
        console.error('Erro ao carregar:', erro);
    }
}

// Exemplo: Criar novo candidato
async function criarCandidato(dados) {
    try {
        const resultado = await Admin.apiRequest('/api/candidatos', {
            method: 'POST',
            body: JSON.stringify(dados)
        });
        Admin.showNotification('Candidato criado!', 'success');
    } catch (erro) {
        Admin.showNotification('Erro ao criar', 'danger');
    }
}
```

---

## 🆘 Troubleshooting

### Sidebar não aparece
- ✅ Verifique se `admin/js/admin-common.js` está carregado
- ✅ Verifique se o elemento com id `sidebar-container` existe

### Estilos não carregam
- ✅ Verifique se `admin/css/admin-unified.css` está carregado
- ✅ Limpe o cache do browser (Ctrl+Shift+Del)

### Formulário não valida
- ✅ Adicione `data-validate` ao formulário
- ✅ Use `required` nos campos obrigatórios
- ✅ Verifique o console do browser para erros

---

## 📞 Suporte

Se encontrar problemas:
1. Verifique o console do navegador (F12)
2. Verifique se todos os ficheiros CSS/JS estão carregados (aba Network)
3. Tente limpar cache e recarregar página

---

## 🎉 Resultado Final

Seu projeto SWPCF agora é:
- ✅ **Funcional** - Todas as páginas funcionam
- ✅ **Bonito** - Design moderno e consistente
- ✅ **Responsivo** - Funciona em qualquer dispositivo
- ✅ **Eficiente** - Sem código repetido
- ✅ **Profissional** - Pronto para produção

**Parabéns!** 🎊 Seu projeto está pronto para ser usado e expandido!

---

**Versão**: 2.0  
**Data**: 4 de Março de 2026  
**Status**: ✅ Completo
