#!/usr/bin/env python3
import os
import re

files = [
    'vagas-lista.html',
    'vagas-adicionar.html',
    'candidatos-lista.html',
    'candidatos-gerenciar.html',
    'candidatos-filtrar.html',
    'candidaturas.html',
    'cursos-lista.html',
    'cursos-adicionar.html',
    'estagios-lista.html',
    'relatorios.html'
]

base_dir = '/Users/user/Downloads/SWPCF/admin'

sidebar_html = '''    <!-- SIDEBAR LATERAL PERMANENTE -->
    <nav class="sidebar bg-dark text-white" role="navigation">
        <div class="sidebar-header p-4">
            <h5 class="fw-bold mb-0">
                <i class="fas fa-graduation-cap me-2"></i>SWPCF Admin
            </h5>
            <small class="text-muted">v2.0</small>
        </div>

        <div class="px-3">
            <ul class="nav flex-column gap-2">
                <li class="nav-item">
                    <a class="nav-link" href="index.html">
                        <i class="fas fa-chart-line"></i>Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="vagas-lista.html">
                        <i class="fas fa-briefcase"></i>Vagas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="vagas-adicionar.html">
                        <i class="fas fa-plus"></i>Adicionar Vaga
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candidatos-lista.html">
                        <i class="fas fa-users"></i>Candidatos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candidatos-gerenciar.html">
                        <i class="fas fa-user-cog"></i>Gerir Candidatos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candidatos-filtrar.html">
                        <i class="fas fa-filter"></i>Filtrar Candidatos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="candidaturas.html">
                        <i class="fas fa-file-alt"></i>Candidaturas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cursos-lista.html">
                        <i class="fas fa-book"></i>Cursos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cursos-adicionar.html">
                        <i class="fas fa-plus"></i>Adicionar Curso
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="estagios-lista.html">
                        <i class="fas fa-clipboard-list"></i>Estágios
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="relatorios.html">
                        <i class="fas fa-chart-bar"></i>Relatórios
                    </a>
                </li>
            </ul>
        </div>

        <hr class="my-4 mx-3" style="border-color: rgba(255,255,255,0.2);">

        <div class="user-section px-3 pb-4">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center" 
                     style="width: 40px; height: 40px;">
                    <i class="fas fa-user"></i>
                </div>
                <div class="flex-grow-1">
                    <p class="mb-0 small fw-bold">Admin</p>
                    <small class="text-muted">admin@swpcf.ao</small>
                </div>
            </div>
            <a href="../index.php?logout=true" class="btn btn-sm btn-outline-light w-100">
                <i class="fas fa-sign-out-alt me-2"></i>Sair
            </a>
        </div>
    </nav>

    <!-- CONTEÚDO PRINCIPAL -->
    <div class="main-content">
        <!-- TOPBAR -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm" style="position: sticky; top: 0; z-index: 999;">
            <div class="container-fluid px-4">
                <span class="navbar-brand mb-0 h5">
                    <i class="fas fa-bars me-2 d-lg-none"></i>Admin
                </span>
                <div class="ms-auto d-flex align-items-center gap-3">
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i>Admin
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="#"><i class="fas fa-cog"></i>Definições</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../index.php?logout=true"><i class="fas fa-sign-out-alt"></i>Sair</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>'''

for filename in files:
    filepath = os.path.join(base_dir, filename)
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Substituir sidebar-container + div main-content
    pattern = r'<body>\s*<!-- [^>]*-->\s*<div id="sidebar-container"></div>\s*<!-- [^>]*-->\s*<div class="main-content">\s*<!-- [^>]*-->\s*<div id="topbar-container"></div>'
    
    content = re.sub(pattern, f'<body>\n{sidebar_html}', content, flags=re.DOTALL)
    
    # Remover scripts antigos no final
    content = re.sub(
        r'<script src="js/admin-common\.js"></script>',
        r'<script>\n        // Destacar menu ativo\n        document.querySelectorAll(\'.nav-link\').forEach(link => {\n            const href = link.getAttribute(\'href\');\n            if (window.location.pathname.includes(href)) {\n                link.classList.add(\'active\');\n            }\n        });\n    </script>',
        content
    )
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f'✅ {filename}')

print('\n✅ Todas as páginas atualizadas!')
