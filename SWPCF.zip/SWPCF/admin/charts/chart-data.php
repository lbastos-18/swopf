<?php
/**
 * Chart Data API
 * Fornece dados para os gráficos do dashboard
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

// Configuração do banco de dados
require_once '../../public/database/config.php';

try {
    // Dados de candidaturas por status
    $candidaturasStatus = [
        'pendente' => 45,
        'aguardando_entrevista' => 30,
        'entrevistado' => 25,
        'aprovado' => 20,
        'rejeitado' => 15,
        'cancelado' => 5
    ];

    // Dados de vagas por categoria
    $vagasPorCategoria = [
        'Desenvolvimento' => 12,
        'Marketing' => 8,
        'Design' => 6,
        'RH' => 5,
        'Outros' => 14
    ];

    // Dados de candidaturas por mês
    $candidaturasPorMes = [
        'Jan' => 45,
        'Fev' => 52,
        'Mar' => 38,
        'Abr' => 65,
        'Mai' => 48,
        'Jun' => 72
    ];

    // Dados de estatísticas gerais
    $estatisticas = [
        'total_vagas' => 150,
        'total_candidatos' => 3420,
        'total_candidaturas' => 1890,
        'total_empresas' => 52,
        'vagas_ativas' => 120,
        'candidaturas_pendentes' => 45
    ];

    // Retornar todos os dados
    echo json_encode([
        'success' => true,
        'data' => [
            'candidaturas_status' => $candidaturasStatus,
            'vagas_categoria' => $vagasPorCategoria,
            'candidaturas_mes' => $candidaturasPorMes,
            'estatisticas' => $estatisticas
        ]
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    // Em caso de erro, retornar dados de exemplo
    echo json_encode([
        'success' => true,
        'data' => [
            'candidaturas_status' => [
                'pendente' => 45,
                'aguardando_entrevista' => 30,
                'entrevistado' => 25,
                'aprovado' => 20,
                'rejeitado' => 15,
                'cancelado' => 5
            ],
            'vagas_categoria' => [
                'Desenvolvimento' => 12,
                'Marketing' => 8,
                'Design' => 6,
                'RH' => 5,
                'Outros' => 14
            ],
            'candidaturas_mes' => [
                'Jan' => 45,
                'Fev' => 52,
                'Mar' => 38,
                'Abr' => 65,
                'Mai' => 48,
                'Jun' => 72
            ],
            'estatisticas' => [
                'total_vagas' => 150,
                'total_candidatos' => 3420,
                'total_candidaturas' => 1890,
                'total_empresas' => 52,
                'vagas_ativas' => 120,
                'candidaturas_pendentes' => 45
            ]
        ]
    ], JSON_PRETTY_PRINT);
}
?>