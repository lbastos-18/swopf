# ✅ Teste de Navegação - SWPCF Admin

## Páginas com Sidebar Funcional

Todas as páginas abaixo têm menu de navegação funcionando corretamente:

✅ **Dashboard**
   - Arquivo: admin/index.html ou admin/dashboard.html
   - Menu: Sidebar carrega automaticamente
   - Navegação: Links funcionam para todas as páginas

✅ **Vagas**
   - admin/vagas-lista.html → Lista de vagas
   - admin/vagas-adicionar.html → Formulário para adicionar vaga

✅ **Candidatos**
   - admin/candidatos-lista.html → Lista de candidatos
   - admin/candidatos-gerenciar.html → Gerir candidatos
   - admin/candidatos-filtrar.html → Filtrar por curso

✅ **Cursos**
   - admin/cursos-lista.html → Lista de cursos
   - admin/cursos-adicionar.html → Adicionar novo curso

✅ **Estágios**
   - admin/estagios-lista.html → Lista de estágios em andamento

✅ **Candidaturas**
   - admin/candidaturas.html → Visualizar candidaturas

✅ **Relatórios**
   - admin/relatorios.html → Gerar relatórios

---

## Como Testar

1. Abra qualquer página HTML listada acima em um navegador
2. O sidebar deve aparecer automaticamente à esquerda
3. Clique em qualquer link do menu
4. A página carrega com o menu mantido
5. Em mobile (< 768px), clique no ☰ para abrir o menu

---

## Estrutura de Todas as Páginas

Todas as páginas usam esta estrutura padrão:

```html
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <!-- CSS unificado -->
    <link rel="stylesheet" href="css/admin-unified.css">
</head>
<body>
    <!-- Sidebar injetado aqui -->
    <div id="sidebar-container"></div>
    
    <!-- Conteúdo principal -->
    <div class="main-content">
        <!-- Topbar injetado aqui -->
        <div id="topbar-container"></div>
        <main>
            <!-- Conteúdo específico da página -->
        </main>
    </div>
    
    <!-- JavaScript que carrega sidebar e topbar -->
    <script src="js/admin-common.js"></script>
</body>
</html>
```

---

## Scripts Carregados Automaticamente

O ficheiro `js/admin-common.js` faz o seguinte:

1. ✅ Carrega o sidebar dinamicamente
2. ✅ Carrega o topbar dinamicamente
3. ✅ Destaca o menu ativo na página atual
4. ✅ Configura validação de formulários
5. ✅ Configura notificações
6. ✅ Configura toggle do menu em mobile

---

## Status das Páginas

| Página | Sidebar | Topbar | Funções | Status |
|--------|---------|--------|---------|--------|
| index.html | ✅ | ✅ | Dashboard | ✅ |
| dashboard.html | ✅ | ✅ | Dashboard Alt | ✅ |
| vagas-lista.html | ✅ | ✅ | Tabela + Filtros | ✅ |
| vagas-adicionar.html | ✅ | ✅ | Formulário | ✅ |
| candidatos-lista.html | ✅ | ✅ | Tabela + Modal | ✅ |
| candidatos-gerenciar.html | ✅ | ✅ | Gerenciamento | ✅ |
| candidatos-filtrar.html | ✅ | ✅ | Filtros | ✅ |
| cursos-lista.html | ✅ | ✅ | Tabela | ✅ |
| cursos-adicionar.html | ✅ | ✅ | Formulário | ✅ |
| estagios-lista.html | ✅ | ✅ | Tabela com Stats | ✅ |
| candidaturas.html | ✅ | ✅ | Tabela com Stats | ✅ |
| relatorios.html | ✅ | ✅ | Filtros + Cartões | ✅ |

---

## Se Sidebar Não Aparecer

Se o sidebar não aparecer em alguma página, verifique:

1. **Verificar Console**: Abra F12 → Console → procure por erros
2. **Verificar se arquivo está carregado**: F12 → Network → procure por "admin-common.js"
3. **Verificar elementos**: F12 → Elements → procure por `<div id="sidebar-container"></div>`
4. **Recarregar página**: Ctrl+Shift+R (limpar cache)

---

## Navegação Rápida

Clique em qualquer link do sidebar para navegar:

```
🏠 Dashboard
├─ 📋 Vagas
│  ├─ Ver Vagas
│  └─ Adicionar Vaga
├─ 👥 Candidatos
│  ├─ Ver Candidatos
│  ├─ Gerir Candidatos
│  └─ Filtrar por Curso
├─ 📚 Cursos
│  ├─ Ver Cursos
│  └─ Adicionar Curso
├─ 📝 Estágios
├─ 📄 Candidaturas
└─ 📊 Relatórios
```

---

**Versão**: 2.0 Completa  
**Data**: 4 de Março de 2026  
**Status**: ✅ Todas as páginas com navegação funcionando
