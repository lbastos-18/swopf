<?php
/**
 * Router Principal - SWPCF
 * Redireciona requisições para o ficheiro correto
 */

$requestUri = strtolower($_SERVER['REQUEST_URI'] ?? '/');
$basePath = '/SWPCF';

// Remover base path
$path = str_replace($basePath, '', $requestUri);
$path = '/' . trim($path, '/');

// Remover query string
if (strpos($path, '?') !== false) {
    $path = substr($path, 0, strpos($path, '?'));
}

// Routing
switch (true) {
    // API
    case strpos($path, '/api/') === 0:
        require_once __DIR__ . '/api/index.php';
        break;
    
    // Admin
    case strpos($path, '/admin') === 0:
        require_once __DIR__ . '/admin/index.html';
        break;
    

    
    // Home
    case $path === '/' || $path === '':
        require_once __DIR__ . '/public/index.html';
        break;
    
    // Ficheiros estáticos
    case preg_match('/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)$/', $path):
        $file = __DIR__ . $path;
        if (file_exists($file)) {
            // Enviar headers corretos
            $mimeTypes = [
                'js' => 'application/javascript',
                'css' => 'text/css',
                'png' => 'image/png',
                'jpg' => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'gif' => 'image/gif',
                'svg' => 'image/svg+xml',
                'ico' => 'image/x-icon',
                'woff' => 'font/woff',
                'woff2' => 'font/woff2',
                'ttf' => 'font/ttf',
                'eot' => 'application/vnd.ms-fontobject'
            ];
            
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $mimeType = $mimeTypes[$ext] ?? 'application/octet-stream';
            
            header('Content-Type: ' . $mimeType);
            readfile($file);
            exit;
        }
        break;
    
    // 404
    default:
        http_response_code(404);
        require_once __DIR__ . '/public/index.html';
        break;
}
?>
