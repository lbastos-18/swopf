<?php
/**
 * Arquivo de Integração - Converte HTML em PHP e conecta à BD
 * SWPCF v2.0
 * 
 * Coloque este arquivo na raiz do projeto
 */

require_once __DIR__ . '/api/config/database.php';

/**
 * Classe para integrar HTML com PHP
 */
class HTMLIntegration
{
    private $db;
    
    public function __construct()
    {
        try {
            $this->db = Database::getInstance();
        } catch (Exception $e) {
            error_log("Erro ao conectar BD: " . $e->getMessage());
        }
    }
    
    /**
     * Carregar página HTML e converter em PHP
     * Injeta dados da base de dados
     */
    public function loadPage($htmlFile, $data = [])
    {
        if (!file_exists($htmlFile)) {
            return "<h1>Erro 404: Página não encontrada</h1>";
        }
        
        $html = file_get_contents($htmlFile);
        
        // Substituir placeholders com dados da BD
        foreach ($data as $key => $value) {
            $placeholder = '{{' . $key . '}}';
            if (is_array($value)) {
                $value = json_encode($value);
            }
            $html = str_replace($placeholder, htmlspecialchars($value), $html);
        }
        
        return $html;
    }
    
    /**
     * Obter dados dinâmicos para injetar no HTML
     */
    public function getDynamicData()
    {
        $data = [];
        
        // Obter utilizador logado
        if (isset($_SESSION['user_id'])) {
            $sql = "SELECT id, nome, email, tipo FROM utilizador WHERE id = ?";
            try {
                $data['user'] = $this->db->fetch($sql, [$_SESSION['user_id']]);
            } catch (Exception $e) {
                error_log("Erro ao obter utilizador: " . $e->getMessage());
            }
        }
        
        // Obter estatísticas gerais
        try {
            $stats = [
                'total_cursos' => $this->db->fetch("SELECT COUNT(*) as count FROM curso")['count'] ?? 0,
                'total_estagios' => $this->db->fetch("SELECT COUNT(*) as count FROM estagio")['count'] ?? 0,
                'total_candidatos' => $this->db->fetch("SELECT COUNT(*) as count FROM candidato")['count'] ?? 0,
                'total_candidaturas' => $this->db->fetch("SELECT COUNT(*) as count FROM candidatura")['count'] ?? 0,
            ];
            $data['stats'] = $stats;
        } catch (Exception $e) {
            error_log("Erro ao obter estatísticas: " . $e->getMessage());
        }
        
        return $data;
    }
    
    /**
     * Renderizar template HTML com dados
     */
    public function renderTemplate($templatePath, $data = [])
    {
        ob_start();
        
        // Extrair variáveis para o escopo local
        extract($data);
        
        // Incluir arquivo de template
        include $templatePath;
        
        $content = ob_get_clean();
        return $content;
    }
}

// Exemplo de uso:
// $integration = new HTMLIntegration();
// $html = $integration->loadPage('public/index.html', $integration->getDynamicData());
// echo $html;
?>
