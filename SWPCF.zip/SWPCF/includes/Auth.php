<?php
/**
 * Sistema de Autenticação
 * SWPCF v2.0
 */

require_once __DIR__ . '/../api/config/database.php';

class Auth
{
    private static $db = null;
    
    /**
     * Obter instância da BD
     */
    private static function getDB()
    {
        if (self::$db === null) {
            self::$db = Database::getInstance();
        }
        return self::$db;
    }
    
    /**
     * Verificar se está logado
     */
    public static function isLoggedIn()
    {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
    
    /**
     * Obter utilizador atual
     */
    public static function getCurrentUser()
    {
        if (!self::isLoggedIn()) {
            return null;
        }
        
        try {
            $db = self::getDB();
            $sql = "SELECT id, nome, email, tipo, data_criacao FROM utilizador WHERE id = ?";
            $user = $db->fetch($sql, [$_SESSION['user_id']]);
            return $user;
        } catch (Exception $e) {
            error_log("Erro ao obter utilizador: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Fazer login
     */
    public static function login($email, $password)
    {
        try {
            $db = self::getDB();
            
            // Buscar utilizador por email
            $sql = "SELECT id, nome, email, tipo, password FROM utilizador WHERE email = ?";
            $user = $db->fetch($sql, [$email]);
            
            if (!$user) {
                return ['success' => false, 'error' => 'Utilizador não encontrado'];
            }
            
            // Verificar password
            if (!password_verify($password, $user['password'])) {
                return ['success' => false, 'error' => 'Password incorreta'];
            }
            
            // Criar sessão
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nome'];
            $_SESSION['user_type'] = $user['tipo'];
            $_SESSION['user_email'] = $user['email'];
            
            // Atualizar último login
            $updateSql = "UPDATE utilizador SET ultimo_login = NOW() WHERE id = ?";
            $db->execute($updateSql, [$user['id']]);
            
            return ['success' => true, 'user' => $user];
            
        } catch (Exception $e) {
            error_log("Erro no login: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro ao fazer login'];
        }
    }
    
    /**
     * Fazer logout
     */
    public static function logout()
    {
        $_SESSION = [];
        session_destroy();
        return true;
    }
    
    /**
     * Registar novo utilizador
     */
    public static function register($nome, $email, $password, $tipo = 'aluno')
    {
        try {
            $db = self::getDB();
            
            // Verificar se email já existe
            $checkSql = "SELECT id FROM utilizador WHERE email = ?";
            $exists = $db->fetch($checkSql, [$email]);
            
            if ($exists) {
                return ['success' => false, 'error' => 'Email já registado'];
            }
            
            // Hash da password
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            
            // Inserir novo utilizador
            $sql = "INSERT INTO utilizador (nome, email, password, tipo, data_criacao) 
                    VALUES (?, ?, ?, ?, NOW())";
            
            $result = $db->execute($sql, [$nome, $email, $hashedPassword, $tipo]);
            
            if (!$result) {
                return ['success' => false, 'error' => 'Erro ao registar'];
            }
            
            // Auto-login
            $newUser = $db->fetch("SELECT * FROM utilizador WHERE email = ?", [$email]);
            $_SESSION['user_id'] = $newUser['id'];
            $_SESSION['user_name'] = $newUser['nome'];
            $_SESSION['user_type'] = $newUser['tipo'];
            
            return ['success' => true, 'user' => $newUser];
            
        } catch (Exception $e) {
            error_log("Erro no registo: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro ao registar'];
        }
    }
    
    /**
     * Exigir que esteja logado
     */
    public static function requireLogin()
    {
        if (!self::isLoggedIn()) {
            header('Location: /SWPCF/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
            exit;
        }
    }
    
    /**
     * Exigir que seja admin
     */
    public static function requireAdmin()
    {
        self::requireLogin();
        
        $user = self::getCurrentUser();
        if ($user['tipo'] !== 'admin') {
            http_response_code(403);
            exit('<h1>Acesso Negado</h1><p>Esta página requer permissões de administrador.</p>');
        }
    }
    
    /**
     * Exigir que seja professor
     */
    public static function requireProfessor()
    {
        self::requireLogin();
        
        $user = self::getCurrentUser();
        if ($user['tipo'] !== 'professor' && $user['tipo'] !== 'admin') {
            http_response_code(403);
            exit('<h1>Acesso Negado</h1><p>Esta página requer permissões de professor.</p>');
        }
    }
    
    /**
     * Verificar se é admin
     */
    public static function isAdmin()
    {
        $user = self::getCurrentUser();
        return $user && $user['tipo'] === 'admin';
    }
    
    /**
     * Verificar se é professor
     */
    public static function isProfessor()
    {
        $user = self::getCurrentUser();
        return $user && ($user['tipo'] === 'professor' || $user['tipo'] === 'admin');
    }
    
    /**
     * Obter ID do utilizador atual
     */
    public static function getUserId()
    {
        return $_SESSION['user_id'] ?? null;
    }
    

       public static function updateProfile($data)
    {
        try {
            $db = self::getDB();
            $userId = self::getUserId();
            
            if (!$userId) {
                return ['success' => false, 'error' => 'Não autenticado'];
            }
            
            // Preparar update dinâmico
            $updates = [];
            $params = [];
            
            if (isset($data['nome'])) {
                $updates[] = "nome = ?";
                $params[] = $data['nome'];
            }
            
            if (isset($data['email'])) {
                $updates[] = "email = ?";
                $params[] = $data['email'];
            }
            
            if (isset($data['password']) && !empty($data['password'])) {
                $updates[] = "password = ?";
                $params[] = password_hash($data['password'], PASSWORD_BCRYPT);
            }
            
            if (empty($updates)) {
                return ['success' => false, 'error' => 'Nenhum campo para atualizar'];
            }
            
            $params[] = $userId;
            
            $sql = "UPDATE utilizador SET " . implode(', ', $updates) . " WHERE id = ?";
            $db->execute($sql, $params);
            
            // Atualizar sessão
            if (isset($data['nome'])) {
                $_SESSION['user_name'] = $data['nome'];
            }
            if (isset($data['email'])) {
                $_SESSION['user_email'] = $data['email'];
            }
            
            return ['success' => true, 'message' => 'Perfil atualizado'];
            
        } catch (Exception $e) {
            error_log("Erro ao atualizar perfil: " . $e->getMessage());
            return ['success' => false, 'error' => 'Erro ao atualizar'];
        }
    }
}

// Iniciar sessão se não estiver já iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
