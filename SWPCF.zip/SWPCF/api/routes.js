/**
 * API Routes - SWPCF
 */

const express = require('express');
const router = express.Router();

// Rotas dummy para testes
router.get('/vagas/stats', (req, res) => {
    res.json({
        success: true,
        data: {
            total_vagas: 45,
            vagas_ativas: 32,
            vagas_preenchidas: 13
        }
    });
});

router.get('/candidatos/stats', (req, res) => {
    res.json({
        success: true,
        data: {
            total_candidatos: 128,
            candidatos_ativos: 95,
            novos_candidatos: 33
        }
    });
});

router.get('/candidaturas/stats', (req, res) => {
    res.json({
        success: true,
        data: {
            total_candidaturas: 256,
            pendentes: 45,
            aceites: 30,
            rejeitadas: 25
        }
    });
});

router.get('/cursos/stats', (req, res) => {
    res.json({
        success: true,
        data: {
            total_cursos: 8,
            cursos_ativos: 7,
            cursos_inativos: 1
        }
    });
});

module.exports = router;
