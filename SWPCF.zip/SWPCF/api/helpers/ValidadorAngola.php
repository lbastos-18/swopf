<?php

/**
 * Validadores para dados angolanos
 * - Bilhete de Identidade (BI)
 * - Número de Telefone
 * - Formato de Endereço
 */

class ValidadorAngola
{
    /**
     * Validar número de Bilhete de Identidade (BI) angolano
     * Formato: XXXXXXX OU XXXXXXX-BI OU 00XXXXXXX
     * 
     * @param string $bi Número de BI
     * @return bool
     */
    public static function validarBI($bi)
    {
        // Remover espaços e caracteres especiais
        $bi = preg_replace('/[^0-9A-Z]/i', '', $bi);
        
        // BI deve ter 7-10 dígitos
        if (strlen($bi) < 7 || strlen($bi) > 10) {
            return false;
        }
        
        // Validar se contém apenas números (após limpeza)
        if (!preg_match('/^\d{7,10}$/', $bi)) {
            return false;
        }
        
        return true;
    }

    /**
     * Validar número de telefone angolano
     * Formatos aceites:
     * - +244923456789 (código país + 9 dígitos)
     * - +244 923 456 789
     * - 923456789 (9 dígitos sem código país)
     * - 244923456789 (sem sinal +)
     * 
     * Operadores: 92x, 93x, 94x (Movicel, Unitel, Zap)
     * 
     * @param string $telefone Número de telefone
     * @return bool
     */
    public static function validarTelefonAngola($telefone)
    {
        // Remover espaços e caracteres especiais excepto +
        $telefone = preg_replace('/[^0-9+]/', '', $telefone);
        
        // Remover código de país se presente
        if (strpos($telefone, '+244') === 0) {
            $telefone = substr($telefone, 4);
        } elseif (strpos($telefone, '244') === 0) {
            $telefone = substr($telefone, 3);
        }
        
        // Deve ter exactamente 9 dígitos
        if (strlen($telefone) !== 9) {
            return false;
        }
        
        // Deve começar com 9 (primeira geração é monodigital em países africanos)
        if ($telefone[0] !== '9') {
            return false;
        }
        
        // Segundo dígito deve ser 2, 3 ou 4 (operadores: Unitel, Movicel, Zap)
        if (!in_array($telefone[1], ['2', '3', '4', '5', '6'])) {
            return false;
        }
        
        // Validar que são todos dígitos
        if (!preg_match('/^\d{9}$/', $telefone)) {
            return false;
        }
        
        return true;
    }

    /**
     * Formatar número de telefone angolano para padrão internacional
     * 
     * @param string $telefone Número de telefone
     * @return string Telefone formatado (+244923456789) ou erro
     */
    public static function formatarTelefonAngola($telefone)
    {
        if (!self::validarTelefonAngola($telefone)) {
            return null;
        }
        
        // Remover caracteres especiais
        $telefone = preg_replace('/[^0-9]/', '', $telefone);
        
        // Remover código de país se presente
        if (strlen($telefone) > 9) {
            $telefone = substr($telefone, -9);
        }
        
        return '+244' . $telefone;
    }

    /**
     * Identificar operador de rede angolano
     * 
     * @param string $telefone Número de telefone
     * @return string Operador (Unitel, Movicel, Zap) ou desconhecido
     */
    public static function identificarOperador($telefone)
    {
        if (!self::validarTelefonAngola($telefone)) {
            return 'Desconhecido';
        }
        
        // Remover código de país e espaços
        $telefone = preg_replace('/[^0-9]/', '', $telefone);
        if (strlen($telefone) > 9) {
            $telefone = substr($telefone, -9);
        }
        
        $segundoDigito = $telefone[1];
        
        // Baseado em padrões conhecidos de Angola
        switch ($segundoDigito) {
            case '2': // Unitel
            case '3': // Movicel
                return match($telefone[1]) {
                    '2' => 'Unitel',
                    '3' => 'Movicel',
                    '4' => 'Zap',
                    '5' => 'Angola Telecom',
                    '6' => 'Zap Fixo',
                    default => 'Desconhecido'
                };
            default:
                return 'Desconhecido';
        }
    }

    /**
     * Validar data de nascimento (maior de 18 anos)
     * 
     * @param string $dataNascimento Data no formato YYYY-MM-DD
     * @return bool
     */
    public static function validarMaiorIdade($dataNascimento)
    {
        try {
            $data = new DateTime($dataNascimento);
            $hoje = new DateTime();
            $idade = $hoje->diff($data)->y;
            
            return $idade >= 18;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Validar género
     * 
     * @param string $genero M (Masculino), F (Feminino) ou Outro
     * @return bool
     */
    public static function validarGenero($genero)
    {
        return in_array($genero, ['M', 'F', 'Outro']);
    }

    /**
     * Obter lista de províncias de Angola
     * 
     * @return array
     */
    public static function obterProvinciaAngola()
    {
        return [
            'Luanda' => 'Luanda',
            'Bengo' => 'Bengo',
            'Cabinda' => 'Cabinda',
            'Huambo' => 'Huambo',
            'Huila' => 'Huíla',
            'Quando Cubango' => 'Quando Cubango',
            'Kwanza Norte' => 'Kwanza Norte',
            'Kwanza Sul' => 'Kwanza Sul',
            'Lunda Norte' => 'Lunda Norte',
            'Lunda Sul' => 'Lunda Sul',
            'Malanje' => 'Malanje',
            'Moxico' => 'Moxico',
            'Namibe' => 'Namibe',
            'Uíge' => 'Uíge',
            'Zaire' => 'Zaire',
            'Cuanza' => 'Cuanza'
        ];
    }

    /**
     * Validar endereço angolano (básico)
     * 
     * @param string $endereco
     * @return bool
     */
    public static function validarEndereco($endereco)
    {
        if (empty($endereco) || strlen($endereco) < 5) {
            return false;
        }
        
        return strlen($endereco) <= 255;
    }
}
