<?php
/**
 * Validator Service Class
 * Type-safe input validation with localization support for Angola
 */
class Validator
{
    private array $errors = [];
    private array $messages = [];

    public function __construct(array $messages = [])
    {
        $this->messages = array_merge([
            'required' => '{field} é obrigatório',
            'email' => '{field} deve ser um email válido',
            'min' => '{field} deve ter no mínimo {value} caracteres',
            'max' => '{field} pode ter no máximo {value} caracteres',
            'match' => '{field} não corresponde',
            'unique' => '{field} já está registado',
            'phone_ao' => '{field} deve ser um número de telefone angolano válido',
            'bi_ao' => '{field} deve ser um BI válido (7-10 dígitos)',
            'date' => '{field} deve ser uma data válida',
            'numeric' => '{field} deve ser numérico',
        ], $messages);
    }

    /**
     * Validate required field
     */
    public function required(string $field, $value): self
    {
        if (empty($value) && $value !== '0' && $value !== 0) {
            $this->addError($field, 'required');
        }
        return $this;
    }

    /**
     * Validate email format
     */
    public function email(string $field, ?string $value): self
    {
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, 'email');
        }
        return $this;
    }

    /**
     * Validate minimum length
     */
    public function minLength(string $field, ?string $value, int $min): self
    {
        if (!empty($value) && strlen($value) < $min) {
            $this->addError($field, 'min', ['value' => $min]);
        }
        return $this;
    }

    /**
     * Validate maximum length
     */
    public function maxLength(string $field, ?string $value, int $max): self
    {
        if (!empty($value) && strlen($value) > $max) {
            $this->addError($field, 'max', ['value' => $max]);
        }
        return $this;
    }

    /**
     * Validate Angolan phone number
     */
    public function phoneAngola(string $field, ?string $value): self
    {
        if (!empty($value) && !$this->isValidPhoneAO($value)) {
            $this->addError($field, 'phone_ao');
        }
        return $this;
    }

    /**
     * Validate Angolan ID (BI)
     */
    public function biAngola(string $field, ?string $value): self
    {
        if (!empty($value) && !$this->isValidBIAO($value)) {
            $this->addError($field, 'bi_ao');
        }
        return $this;
    }

    /**
     * Validate numeric value
     */
    public function numeric(string $field, $value): self
    {
        if (!empty($value) && !is_numeric($value)) {
            $this->addError($field, 'numeric');
        }
        return $this;
    }

    /**
     * Check if field is unique in database
     */
    public function unique(string $field, ?string $value, string $table, string $column = null): self
    {
        if (empty($value)) {
            return $this;
        }

        $column = $column ?? $field;
        $db = Database::getInstance();
        $sql = "SELECT COUNT(*) as cnt FROM $table WHERE $column = ? LIMIT 1";
        $result = $db->fetch($sql, [$value]);

        if ($result && $result['cnt'] > 0) {
            $this->addError($field, 'unique');
        }
        return $this;
    }

    /**
     * Check if error exists
     */
    public function hasErrors(): bool
    {
        return !empty($this->errors);
    }

    /**
     * Get all errors
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Get first error
     */
    public function firstError(string $field): ?string
    {
        return $this->errors[$field][0] ?? null;
    }

    /**
     * Throw exception if validation fails
     */
    public function throwIfInvalid(int $status = 400): void
    {
        if ($this->hasErrors()) {
            jsonResponse($this->errors, $status, 'Erro de validação');
        }
    }

    // =========================================================================
    // Private helpers
    // =========================================================================

    private function addError(string $field, string $rule, array $context = []): void
    {
        $message = $this->messages[$rule] ?? 'Erro de validação';
        $message = str_replace('{field}', $field, $message);
        foreach ($context as $key => $value) {
            $message = str_replace('{' . $key . '}', $value, $message);
        }

        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }

    private function isValidPhoneAO(string $phone): bool
    {
        // Angola: starts with +244, +2449XX, 9XX, or 92X
        $phone = preg_replace('/\D/', '', $phone);
        if (strlen($phone) >= 9 && in_array(substr($phone, -9, 2), ['92', '93', '94'])) {
            return true;
        }
        return false;
    }

    private function isValidBIAO(string $bi): bool
    {
        // Angola BI: 7-10 digits
        $bi = preg_replace('/\D/', '', $bi);
        return strlen($bi) >= 7 && strlen($bi) <= 10 && is_numeric($bi);
    }
}
