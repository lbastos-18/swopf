<?php
/**
 * Funções Helper Globais
 */

// Resposta JSON estruturada
function jsonResponse($data = [], $status = 200, $message = '')
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');

    $response = [
        'status' => $status,
        'success' => ($status >= 200 && $status < 300),
        'data' => $data,
    ];

    if ($message) {
        $response['message'] = $message;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Validar email
function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Sanitizar entrada
function sanitize($input)
{
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Gerar token JWT simples (usar biblioteca em produção)
function generateToken($data)
{
    $header = json_encode(['alg' => JWT_ALGORITHM, 'typ' => 'JWT']);
    $payload = json_encode(array_merge($data, ['exp' => time() + TOKEN_EXPIRY]));
    
    $header_encoded = base64_encode($header);
    $payload_encoded = base64_encode($payload);
    
    $signature = hash_hmac('sha256', "$header_encoded.$payload_encoded", JWT_SECRET, true);
    $signature_encoded = base64_encode($signature);
    
    return "$header_encoded.$payload_encoded.$signature_encoded";
}

// Validar token JWT
function verifyToken($token)
{
    $parts = explode('.', $token);
    
    if (count($parts) !== 3) {
        return false;
    }
    
    $header = base64_decode($parts[0]);
    $payload = base64_decode($parts[1]);
    $signature = $parts[2];
    
    $valid_signature = base64_encode(hash_hmac('sha256', "{$parts[0]}.{$parts[1]}", JWT_SECRET, true));
    
    if ($signature !== $valid_signature) {
        return false;
    }
    
    $decode = json_decode($payload, true);
    
    if ($decode['exp'] < time()) {
        return false;
    }
    
    return $decode;
}

// Hash de password com bcrypt
function hashPassword($password)
{
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
}

// Verificar password
function verifyPassword($password, $hash)
{
    return password_verify($password, $hash);
}

// Gerar slug
function generateSlug($str)
{
    $str = strtolower(trim($str));
    $str = preg_replace('/[^a-z0-9]+/', '-', $str);
    return trim($str, '-');
}

// Formatar data para português
function formatDate($date, $format = 'd/m/Y')
{
    if (empty($date)) return '';
    return date($format, strtotime($date));
}

// Formatar moeda
function formatCurrency($value)
{
    return number_format($value, 2, ',', '.') . ' Kz';
}

// Log de ações
function logAction($user_id, $acao, $entidade, $entidade_id, $detalhes_antes = null, $detalhes_depois = null)
{
    $db = Database::getInstance();
    
    $sql = "INSERT INTO logs_sistema 
            (utilizador_id, acao, entidade, entidade_id, detalhes_antes, detalhes_depois, endereco_ip, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    return $db->insert($sql, [
        $user_id,
        $acao,
        $entidade,
        $entidade_id,
        $detalhes_antes ? json_encode($detalhes_antes) : null,
        $detalhes_depois ? json_encode($detalhes_depois) : null,
        $_SERVER['REMOTE_ADDR'] ?? '',
        $_SERVER['HTTP_USER_AGENT'] ?? ''
    ]);
}

// Enviar notificação
function sendNotification($user_id, $titulo, $mensagem, $tipo = 'info', $ref_tipo = null, $ref_id = null)
{
    $db = Database::getInstance();
    
    $sql = "INSERT INTO notificacoes 
            (utilizador_id, titulo, mensagem, tipo, referencia_tipo, referencia_id) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    return $db->insert($sql, [$user_id, $titulo, $mensagem, $tipo, $ref_tipo, $ref_id]);
}

// Validar tamanho de ficheiro
function isValidFileSize($size, $max_mb = 5)
{
    return $size <= ($max_mb * 1024 * 1024);
}

// Validar tipo de ficheiro
function isValidFileType($filename, $allowed_types = ['pdf', 'doc', 'docx'])
{
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, $allowed_types);
}

// Criar pasta de uploads se não existir
function ensureUploadDir($dirname)
{
    $path = UPLOADS_DIR . '/' . $dirname;
    if (!is_dir($path)) {
        mkdir($path, 0755, true);
    }
    return $path;
}
