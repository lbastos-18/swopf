<?php
/**
 * Response Builder Class
 * Standardized API response wrapper with proper HTTP headers and status codes
 */
class Response
{
    private int $statusCode = 200;
    private array $data = [];
    private ?string $message = null;
    private array $errors = [];
    private array $meta = [];

    public function __construct(int $statusCode = 200, $data = null, ?string $message = null)
    {
        $this->statusCode = $statusCode;
        if ($data !== null) {
            $this->data = $data;
        }
        $this->message = $message;
    }

    public function withData($data): self
    {
        $this->data = $data;
        return $this;
    }

    public function withMessage(string $message): self
    {
        $this->message = $message;
        return $this;
    }

    public function withErrors(array $errors): self
    {
        $this->errors = $errors;
        return $this;
    }

    public function withMeta(array $meta): self
    {
        $this->meta = $meta;
        return $this;
    }

    public function addMeta(string $key, $value): self
    {
        $this->meta[$key] = $value;
        return $this;
    }

    public function send(): void
    {
        http_response_code($this->statusCode);
        header('Content-Type: application/json; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');

        $response = [
            'status' => $this->statusCode,
            'success' => ($this->statusCode >= 200 && $this->statusCode < 300),
        ];

        if (!empty($this->data)) {
            $response['data'] = $this->data;
        }

        if ($this->message) {
            $response['message'] = $this->message;
        }

        if (!empty($this->errors)) {
            $response['errors'] = $this->errors;
        }

        if (!empty($this->meta)) {
            $response['meta'] = $this->meta;
        }

        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    public static function success($data = null, string $message = 'Operação realizada com sucesso', array $meta = []): self
    {
        return (new self(200, $data, $message))->withMeta($meta);
    }

    public static function created($data = null, string $message = 'Recurso criado com sucesso'): self
    {
        return new self(201, $data, $message);
    }

    public static function badRequest(array $errors = [], string $message = 'Erro de validação'): self
    {
        return (new self(400))->withErrors($errors)->withMessage($message);
    }

    public static function unauthorized(string $message = 'Não autenticado'): self
    {
        return new self(401, null, $message);
    }

    public static function forbidden(string $message = 'Acesso negado'): self
    {
        return new self(403, null, $message);
    }

    public static function notFound(string $message = 'Recurso não encontrado'): self
    {
        return new self(404, null, $message);
    }

    public static function conflict(string $message = 'Conflito'): self
    {
        return new self(409, null, $message);
    }

    public static function serverError(string $message = 'Erro interno do servidor'): self
    {
        return new self(500, null, $message);
    }
}
