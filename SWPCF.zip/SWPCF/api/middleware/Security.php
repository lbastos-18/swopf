<?php
/**
 * Security Middleware
 * Handles CORS, security headers, and request validation
 */
class SecurityMiddleware
{
    /**
     * Handle CORS and set security headers
     */
    public static function handleCORS(): void
    {
        $allowedOrigins = defined('ALLOWED_ORIGINS') ? ALLOWED_ORIGINS : [];
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        // Validate origin if CORS is enabled
        if (!empty($origin) && in_array($origin, $allowedOrigins)) {
            header("Access-Control-Allow-Origin: $origin");
            header('Access-Control-Allow-Credentials: true');
        }

        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
        header('Access-Control-Max-Age: 3600');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(200);
            exit;
        }
    }

    /**
     * Set security headers to prevent common attacks
     */
    public static function setSecurityHeaders(): void
    {
        // Prevent clickjacking
        header('X-Frame-Options: DENY');

        // Prevent MIME sniffing
        header('X-Content-Type-Options: nosniff');

        // Prevent XSS attacks
        header("X-XSS-Protection: 1; mode=block");

        // Content Security Policy (adjust as needed)
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';");

        // Strict Transport Security (uncomment for HTTPS)
        // header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

        // Referrer Policy
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }

    /**
     * Validate request method
     */
    public static function requireMethod(string $method): void
    {
        $method = strtoupper($method);
        $currentMethod = $_SERVER['REQUEST_METHOD'];

        if ($currentMethod !== $method) {
            Response::badRequest([], "Método HTTP não permitido. Esperado: $method")->send();
        }
    }

    /**
     * Verify Content-Type is JSON
     */
    public static function requireJson(): array
    {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';

        if (strpos($contentType, 'application/json') === false) {
            Response::badRequest([], 'Content-Type deve ser application/json')->send();
        }

        $input = json_decode(file_get_contents('php://input'), true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            Response::badRequest([], 'JSON inválido: ' . json_last_error_msg())->send();
        }

        return $input ?? [];
    }

    /**
     * Get JSON input safely
     */
    public static function getJsonInput(): array
    {
        $input = json_decode(file_get_contents('php://input'), true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return [];
        }

        return $input ?? [];
    }

    /**
     * Sanitize input string
     */
    public static function sanitize(string $input): string
    {
        return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
    }

    /**
     * Sanitize array of inputs
     */
    public static function sanitizeArray(array $inputs): array
    {
        return array_map(function ($value) {
            return is_string($value) ? self::sanitize($value) : $value;
        }, $inputs);
    }
}
