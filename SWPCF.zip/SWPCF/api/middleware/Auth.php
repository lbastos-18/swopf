<?php
/**
 * Middleware de Autenticação
 */

class AuthMiddleware
{
    public static function verifyToken()
    {
        $headers = getallheaders();
        
        if (!isset($headers['Authorization'])) {
            jsonResponse([], 401, 'Token não fornecido');
        }

        // Formato: Bearer <token>
        $auth_header = $headers['Authorization'];
        $parts = explode(' ', $auth_header);
        
        if (count($parts) !== 2 || $parts[0] !== 'Bearer') {
            jsonResponse([], 401, 'Formato de token inválido');
        }

        $token = $parts[1];
        $decoded = verifyToken($token);
        
        if (!$decoded) {
            jsonResponse([], 401, 'Token inválido ou expirado');
        }

        return $decoded;
    }

    public static function verifySession()
    {
        if (!isset($_SESSION['user_id'])) {
            jsonResponse([], 401, 'Sessão não autenticada');
        }
        
        return [
            'id' => $_SESSION['user_id'],
            'tipo_utilizador' => $_SESSION['tipo_utilizador'] ?? null,
            'email' => $_SESSION['email'] ?? null,
        ];
    }

    public static function verifyRole($required_role)
    {
        $user = self::verifySession();
        
        if ($user['tipo_utilizador'] !== $required_role && $user['tipo_utilizador'] !== 'admin') {
            jsonResponse([], 403, 'Acesso negado. Privilégios insuficientes.');
        }
        
        return $user;
    }
}

// Backwards-compatible proxy class: Auth -> AuthMiddleware
class Auth
{
    public static function verifyToken()
    {
        return AuthMiddleware::verifyToken();
    }

    public static function verifySession()
    {
        return AuthMiddleware::verifySession();
    }

    public static function verifyRole($required_role)
    {
        return AuthMiddleware::verifyRole($required_role);
    }

    public static function getUsuarioAtual()
    {
        // Use session based helper if available
        return [
            'id' => $_SESSION['user_id'] ?? null,
            'tipo_utilizador' => $_SESSION['tipo_utilizador'] ?? null,
            'email' => $_SESSION['email'] ?? null,
        ];
    }

    public static function getUserId()
    {
        return $_SESSION['user_id'] ?? null;
    }
}

// CORS Handler
function handleCORS()
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    
    if (in_array($origin, ALLOWED_ORIGINS)) {
        header("Access-Control-Allow-Origin: $origin");
    }
    
    header('Access-Control-Allow-Methods: ' . implode(', ', ALLOWED_METHODS));
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Max-Age: 3600');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

// Verificar método HTTP
function requireMethod($method)
{
    if ($_SERVER['REQUEST_METHOD'] !== strtoupper($method)) {
        jsonResponse([], 405, "Método {$_SERVER['REQUEST_METHOD']} não permitido");
    }
}

// Obter dados JSON do request
function getJsonInput()
{
    $input = file_get_contents('php://input');
    return json_decode($input, true) ?? [];
}
