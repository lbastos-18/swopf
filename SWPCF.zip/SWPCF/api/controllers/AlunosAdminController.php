<?php

/**
 * AlunosAdminController
 * Gerenciamento de candidatos/alunos para administração
 */

class AlunosAdminController
{
    private $database;

    public function __construct()
    {
        $this->database = Database::getInstance();
    }

    /**
     * Listar todos os candidatos (alunos)
     */
    public function index()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin', 'gestor']);

        try {
            $filtro = $_GET['filtro'] ?? '';
            $status = $_GET['status'] ?? '';
            $pagina = (int)($_GET['pagina'] ?? 1);
            $limite = 20;
            $offset = ($pagina - 1) * $limite;

            // Construir query
            $sql = "SELECT u.*, 
                           COUNT(DISTINCT ac.curso_id) as total_cursos,
                           COUNT(DISTINCT c.id) as total_candidaturas
                    FROM utilizadores u
                    LEFT JOIN aluno_curso ac ON u.id = ac.utilizador_id
                    LEFT JOIN candidaturas c ON u.id = c.utilizador_id
                    WHERE u.role = 'candidato'";

            $params = [];

            if (!empty($filtro)) {
                $sql .= " AND (u.nome LIKE ? OR u.email LIKE ? OR u.numero_documento LIKE ?)";
                $termo = "%$filtro%";
                $params = [$termo, $termo, $termo];
            }

            if (!empty($status)) {
                $sql .= " AND u.telefone_validado = ?";
                $params[] = ($status === 'validado') ? 1 : 0;
            }

            // Contar total
            $sqlCount = "SELECT COUNT(DISTINCT u.id) as total FROM (" . $sql . ") as sub";
            $stmtCount = $this->database->prepare(str_replace("SELECT u.*, COUNT(DISTINCT ac.curso_id) as total_cursos, COUNT(DISTINCT c.id) as total_candidaturas FROM utilizadores u LEFT JOIN aluno_curso ac ON u.id = ac.utilizador_id LEFT JOIN candidaturas c ON u.id = c.utilizador_id", "SELECT DISTINCT u.id", $sql));
            
            // Query final com paginação
            $sql .= " GROUP BY u.id ORDER BY u.data_registo DESC LIMIT ? OFFSET ?";
            $params[] = $limite;
            $params[] = $offset;

            $stmt = $this->database->prepare($sql);
            $stmt->execute($params);
            $candidatos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Contar total sem limite
            $sqlTotal = "SELECT COUNT(DISTINCT u.id) as total FROM utilizadores u 
                        LEFT JOIN aluno_curso ac ON u.id = ac.utilizador_id
                        LEFT JOIN candidaturas c ON u.id = c.utilizador_id
                        WHERE u.role = 'candidato'";
            
            if (!empty($filtro)) {
                $sqlTotal .= " AND (u.nome LIKE ? OR u.email LIKE ? OR u.numero_documento LIKE ?)";
            }
            
            $stmtTotal = $this->database->prepare($sqlTotal);
            $paramsTotal = [];
            
            if (!empty($filtro)) {
                $paramsTotal = ["%$filtro%", "%$filtro%", "%$filtro%"];
            }
            
            $stmtTotal->execute($paramsTotal);
            $resultCount = $stmtTotal->fetch(PDO::FETCH_ASSOC);
            $totalCandidatos = $resultCount['total'] ?? 0;
            $totalPaginas = ceil($totalCandidatos / $limite);

            jsonResponse([
                'success' => true,
                'candidatos' => $candidatos,
                'total' => $totalCandidatos,
                'pagina' => $pagina,
                'total_paginas' => $totalPaginas,
                'por_pagina' => $limite
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Obter detalhes de um candidato
     */
    public function show()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin', 'gestor']);

        $id = (int)($_GET['id'] ?? 0);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do candidato é obrigatório');
            return;
        }

        try {
            $sql = "SELECT u.*, 
                           COUNT(DISTINCT ac.curso_id) as total_cursos,
                           COUNT(DISTINCT c.id) as total_candidaturas,
                           SUM(CASE WHEN ac.status = 'completado' THEN 1 ELSE 0 END) as cursos_completados
                    FROM utilizadores u
                    LEFT JOIN aluno_curso ac ON u.id = ac.utilizador_id
                    LEFT JOIN candidaturas c ON u.id = c.utilizador_id
                    WHERE u.id = ? AND u.role = 'candidato'
                    GROUP BY u.id";

            $stmt = $this->database->prepare($sql);
            $stmt->execute([$id]);
            $candidato = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$candidato) {
                jsonResponse([], 404, 'Candidato não encontrado');
                return;
            }

            // Obter cursos do candidato
            $sqlCursos = "SELECT ac.*, c.titulo, c.duracao
                         FROM aluno_curso ac
                         JOIN cursos c ON ac.curso_id = c.id
                         WHERE ac.utilizador_id = ?
                         ORDER BY ac.data_inscricao DESC";

            $stmtCursos = $this->database->prepare($sqlCursos);
            $stmtCursos->execute([$id]);
            $cursos = $stmtCursos->fetchAll(PDO::FETCH_ASSOC);

            // Obter candidaturas
            $sqlCandidaturas = "SELECT c.*, e.titulo as estagio_titulo
                               FROM candidaturas c
                               JOIN estagios e ON c.estagio_id = e.id
                               WHERE c.utilizador_id = ?
                               ORDER BY c.criado_em DESC";

            $stmtCandidaturas = $this->database->prepare($sqlCandidaturas);
            $stmtCandidaturas->execute([$id]);
            $candidaturas = $stmtCandidaturas->fetchAll(PDO::FETCH_ASSOC);

            jsonResponse([
                'success' => true,
                'candidato' => $candidato,
                'cursos' => $cursos,
                'candidaturas' => $candidaturas
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Criar novo candidato (admin)
     */
    public function store()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $input = json_decode(file_get_contents('php://input'), true);

        try {
            // Validaciones obrigatórias
            $campos_obrigatorios = ['nome', 'email', 'senha', 'numero_documento', 'telefone'];
            foreach ($campos_obrigatorios as $campo) {
                if (empty($input[$campo])) {
                    jsonResponse([], 400, "Campo '$campo' é obrigatório");
                    return;
                }
            }

            // Validar dados angolanos
            if (!ValidadorAngola::validarBI($input['numero_documento'])) {
                jsonResponse([], 400, 'Número de BI inválido');
                return;
            }

            if (!ValidadorAngola::validarTelefonAngola($input['telefone'])) {
                jsonResponse([], 400, 'Número de telefone angolano inválido');
                return;
            }

            $telefone_formatado = ValidadorAngola::formatarTelefonAngola($input['telefone']);

            // Validar maioridade se fornecida data de nascimento
            if (!empty($input['data_nascimento'])) {
                if (!ValidadorAngola::validarMaiorIdade($input['data_nascimento'])) {
                    jsonResponse([], 400, 'Candidato deve ter 18+ anos');
                    return;
                }
            }

            // Verificar email único
            $sqlEmail = "SELECT COUNT(*) as total FROM utilizadores WHERE email = ?";
            $stmtEmail = $this->database->prepare($sqlEmail);
            $stmtEmail->execute([$input['email']]);
            $resultEmail = $stmtEmail->fetch(PDO::FETCH_ASSOC);

            if ($resultEmail['total'] > 0) {
                jsonResponse([], 400, 'Email já registado');
                return;
            }

            // Verificar BI único
            $sqlBI = "SELECT COUNT(*) as total FROM utilizadores WHERE numero_documento = ?";
            $stmtBI = $this->database->prepare($sqlBI);
            $stmtBI->execute([$input['numero_documento']]);
            $resultBI = $stmtBI->fetch(PDO::FETCH_ASSOC);

            if ($resultBI['total'] > 0) {
                jsonResponse([], 400, 'BI já registado');
                return;
            }

            // Criar utilizador
            $sql = "INSERT INTO utilizadores (
                        nome, email, password, telefone, numero_documento, 
                        data_nascimento, genero, endereco, provincia, 
                        pais_origem, role, telefone_validado, data_registo, criado_em
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute([
                $input['nome'],
                $input['email'],
                password_hash($input['senha'], PASSWORD_BCRYPT),
                $telefone_formatado,
                $input['numero_documento'],
                $input['data_nascimento'] ?? null,
                $input['genero'] ?? 'Outro',
                $input['endereco'] ?? null,
                $input['provincia'] ?? null,
                'Angola',
                'candidato',
                1  // Telefone validado por admin
            ]);

            if ($sucesso) {
                $novoId = $this->database->lastInsertId();
                
                jsonResponse([
                    'success' => true,
                    'message' => 'Candidato criado com sucesso',
                    'id' => $novoId
                ]);
            } else {
                jsonResponse([], 400, 'Erro ao criar candidato');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Atualizar dados de um candidato
     */
    public function update()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin', 'gestor']);

        $id = (int)($_GET['id'] ?? 0);
        $input = json_decode(file_get_contents('php://input'), true);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do candidato é obrigatório');
            return;
        }

        try {
            // Validar BI se fornecido
            if (isset($input['numero_documento'])) {
                if (!ValidadorAngola::validarBI($input['numero_documento'])) {
                    jsonResponse([], 400, 'Número de BI inválido');
                    return;
                }
            }

            // Validar telefone se fornecido
            if (isset($input['telefone'])) {
                if (!ValidadorAngola::validarTelefonAngola($input['telefone'])) {
                    jsonResponse([], 400, 'Número de telefone angolano inválido');
                    return;
                }
                $input['telefone'] = ValidadorAngola::formatarTelefonAngola($input['telefone']);
            }

            // Validar data de nascimento se fornecida
            if (isset($input['data_nascimento'])) {
                if (!ValidadorAngola::validarMaiorIdade($input['data_nascimento'])) {
                    jsonResponse([], 400, 'Candidato deve ter 18+ anos');
                    return;
                }
            }

            // Campos permitidos para actualizar
            $camposPermitidos = ['nome', 'email', 'telefone', 'numero_documento', 'data_nascimento', 'genero', 'endereco', 'provincia'];
            $update = [];
            $valores = [];

            foreach ($camposPermitidos as $campo) {
                if (isset($input[$campo])) {
                    $update[] = "$campo = ?";
                    $valores[] = $input[$campo];
                }
            }

            if (empty($update)) {
                jsonResponse([], 400, 'Nenhum campo para actualizar fornecido');
                return;
            }

            $valores[] = $id;
            $sql = "UPDATE utilizadores SET " . implode(', ', $update) . " WHERE id = ? AND role = 'candidato'";
            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute($valores);

            if ($sucesso) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Candidato actualizado com sucesso'
                ]);
            } else {
                jsonResponse([], 400, 'Erro ao actualizar candidato');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Apagar um candidato
     */
    public function delete()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $id = (int)($_GET['id'] ?? 0);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do candidato é obrigatório');
            return;
        }

        try {
            // Verificar se candidato existe
            $sqlVerifica = "SELECT id FROM utilizadores WHERE id = ? AND role = 'candidato'";
            $stmtVerifica = $this->database->prepare($sqlVerifica);
            $stmtVerifica->execute([$id]);

            if (!$stmtVerifica->fetch(PDO::FETCH_ASSOC)) {
                jsonResponse([], 404, 'Candidato não encontrado');
                return;
            }

            // Apagar candidato (cascata na BD)
            $sql = "DELETE FROM utilizadores WHERE id = ? AND role = 'candidato'";
            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute([$id]);

            if ($sucesso) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Candidato apagado com sucesso'
                ]);
            } else {
                jsonResponse([], 400, 'Erro ao apagar candidato');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Obter estatísticas dos candidatos
     */
    public function getStats()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin', 'gestor']);

        try {
            $sql = "SELECT 
                        COUNT(DISTINCT u.id) as total_candidatos,
                        SUM(CASE WHEN u.telefone_validado = 1 THEN 1 ELSE 0 END) as telefone_validado,
                        SUM(CASE WHEN u.data_registo >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) as registados_mes,
                        COUNT(DISTINCT ac.id) as total_inscricoes_cursos,
                        COUNT(DISTINCT c.id) as total_candidaturas,
                        SUM(CASE WHEN ac.status = 'completado' THEN 1 ELSE 0 END) as cursos_completados
                    FROM utilizadores u
                    LEFT JOIN aluno_curso ac ON u.id = ac.utilizador_id
                    LEFT JOIN candidaturas c ON u.id = c.utilizador_id
                    WHERE u.role = 'candidato'";

            $stmt = $this->database->query($sql);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);

            jsonResponse([
                'success' => true,
                'stats' => $stats
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Exportar lista de candidatos em CSV
     */
    public function exportCSV()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        try {
            $sql = "SELECT u.id, u.nome, u.email, u.telefone, u.numero_documento, 
                           u.data_nascimento, u.genero, u.provincia, u.data_registo,
                           COUNT(DISTINCT ac.curso_id) as total_cursos,
                           COUNT(DISTINCT c.id) as total_candidaturas
                    FROM utilizadores u
                    LEFT JOIN aluno_curso ac ON u.id = ac.utilizador_id
                    LEFT JOIN candidaturas c ON u.id = c.utilizador_id
                    WHERE u.role = 'candidato'
                    GROUP BY u.id
                    ORDER BY u.data_registo DESC";

            $stmt = $this->database->query($sql);
            $candidatos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Criar CSV
            $filename = 'candidatos_' . date('Y-m-d_H-i-s') . '.csv';
            header('Content-Type: text/csv; charset=utf-8');
            header("Content-Disposition: attachment; filename=$filename");

            $output = fopen('php://output', 'w');
            
            // BOM para Excel interpretar UTF-8
            fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

            // Cabeçalho
            fputcsv($output, [
                'ID', 'Nome', 'Email', 'Telefone', 'BI', 'Data Nascimento',
                'Género', 'Província', 'Data Registo', 'Total Cursos', 'Total Candidaturas'
            ]);

            // Dados
            foreach ($candidatos as $candidato) {
                fputcsv($output, [
                    $candidato['id'],
                    $candidato['nome'],
                    $candidato['email'],
                    $candidato['telefone'],
                    $candidato['numero_documento'],
                    $candidato['data_nascimento'],
                    $candidato['genero'],
                    $candidato['provincia'],
                    $candidato['data_registo'],
                    $candidato['total_cursos'],
                    $candidato['total_candidaturas']
                ]);
            }

            fclose($output);
            exit;
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Validar/activar candidato (verificar telefone)
     */
    public function validarCandidato()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $id = (int)($_GET['id'] ?? 0);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do candidato é obrigatório');
            return;
        }

        try {
            $sql = "UPDATE utilizadores SET telefone_validado = 1 WHERE id = ? AND role = 'candidato'";
            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute([$id]);

            if ($sucesso && $stmt->rowCount() > 0) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Candidato validado com sucesso'
                ]);
            } else {
                jsonResponse([], 404, 'Candidato não encontrado');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }
}
