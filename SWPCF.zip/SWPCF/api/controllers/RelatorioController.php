<?php

class RelatorioController
{
    private $database;

    public function __construct()
    {
        $this->database = Database::getInstance();
    }

    /**
     * Obter estatísticas consolidadas para relatórios
     */
    public function getStats()
    {
        try {
            // Stats de Estágios
            $estagios = $this->getEstagiosStats();
            
            // Stats de Escolas
            $escolas = $this->getEscolasStats();
            
            // Stats de Candidaturas
            $candidaturas = $this->getCandidaturasStats();
            
            // Stats de Documentos
            $documentos = $this->getDocumentosStats();
            
            // Stats de Cursos
            $cursos = $this->getCursosStats();
            
            // Stats de Candidatos
            $candidatos = $this->getCandidatosStats();

            return [
                'success' => true,
                'data' => [
                    'estagios' => $estagios,
                    'escolas' => $escolas,
                    'candidaturas' => $candidaturas,
                    'documentos' => $documentos,
                    'cursos' => $cursos,
                    'candidatos' => $candidatos,
                    'data_geracao' => date('Y-m-d H:i:s'),
                    'periodo' => $_GET['data_inicio'] ?? null,
                    'periodo_fim' => $_GET['data_fim'] ?? null
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Estatísticas de estágios
     */
    private function getEstagiosStats()
    {
        try {
            $sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'ativo' THEN 1 ELSE 0 END) as ativo,
                        SUM(CASE WHEN status = 'encerrado' THEN 1 ELSE 0 END) as encerrado,
                        SUM(CASE WHEN tipo = 'remunerado' THEN 1 ELSE 0 END) as remunerados,
                        SUM(CASE WHEN tipo = 'nao_remunerado' THEN 1 ELSE 0 END) as nao_remunerados
                    FROM estagios";
            
            $stmt = $this->database->query($sql);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Contar candidaturas por estágio
            $sqlAreas = "SELECT DISTINCT area FROM estagios WHERE area IS NOT NULL";
            $stmtAreas = $this->database->query($sqlAreas);
            $areas = $stmtAreas->fetchAll(PDO::FETCH_COLUMN);
            
            $result['areas'] = count($areas);
            
            return $result;
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Estatísticas de escolas
     */
    private function getEscolasStats()
    {
        try {
            $sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'ativa' THEN 1 ELSE 0 END) as total_ativa,
                        SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as total_pendente,
                        SUM(CASE WHEN status = 'suspensa' THEN 1 ELSE 0 END) as total_suspensa
                    FROM escolas";
            
            $stmt = $this->database->query($sql);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Estatísticas de candidaturas
     */
    private function getCandidaturasStats()
    {
        try {
            $sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendente,
                        SUM(CASE WHEN status = 'em_analise_documentos' THEN 1 ELSE 0 END) as em_analise_documentos,
                        SUM(CASE WHEN status = 'documentos_aprovados' THEN 1 ELSE 0 END) as documentos_aprovados,
                        SUM(CASE WHEN status = 'documentos_rejeitados' THEN 1 ELSE 0 END) as documentos_rejeitados,
                        SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END) as aprovado,
                        SUM(CASE WHEN status = 'rejeitado' THEN 1 ELSE 0 END) as rejeitado,
                        SUM(CASE WHEN status = 'cancelado' THEN 1 ELSE 0 END) as cancelado
                    FROM candidaturas";
            
            $stmt = $this->database->query($sql);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Estatísticas de documentos
     */
    private function getDocumentosStats()
    {
        try {
            $sql = "SELECT 
                        COUNT(*) as total,
                        SUM(CASE WHEN status_validacao = 'pendente' THEN 1 ELSE 0 END) as pendentes,
                        SUM(CASE WHEN status_validacao = 'aprovado' THEN 1 ELSE 0 END) as aprovados,
                        SUM(CASE WHEN status_validacao = 'rejeitado' THEN 1 ELSE 0 END) as rejeitados
                    FROM documentos";
            
            $stmt = $this->database->query($sql);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Estatísticas de cursos
     */
    private function getCursosStats()
    {
        try {
            $sql = "SELECT COUNT(*) as total FROM cursos";
            
            $stmt = $this->database->query($sql);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Cursos adicionados este mês
            $sqlMes = "SELECT COUNT(*) as este_mes 
                      FROM cursos 
                      WHERE MONTH(data_criacao) = MONTH(NOW()) 
                      AND YEAR(data_criacao) = YEAR(NOW())";
            
            $stmtMes = $this->database->query($sqlMes);
            $mesMes = $stmtMes->fetch(PDO::FETCH_ASSOC);
            
            $result['este_mes'] = $mesMes['este_mes'] ?? 0;
            
            return $result;
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Estatísticas de candidatos
     */
    private function getCandidatosStats()
    {
        try {
            $sql = "SELECT COUNT(*) as total FROM utilizadores WHERE role = 'candidato'";
            
            $stmt = $this->database->query($sql);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Candidatos registados este mês
            $sqlMes = "SELECT COUNT(*) as este_mes 
                      FROM utilizadores 
                      WHERE role = 'candidato'
                      AND MONTH(data_registo) = MONTH(NOW()) 
                      AND YEAR(data_registo) = YEAR(NOW())";
            
            $stmtMes = $this->database->query($sqlMes);
            $alunos = $stmtMes->fetch(PDO::FETCH_ASSOC);
            
            $result['este_mes'] = $alunos['este_mes'] ?? 0;
            
            return $result;
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Exportar relatório em PDF
     */
    public function exportPDF()
    {
        // Implementação futura com biblioteca PDF
        return [
            'success' => false,
            'message' => 'Funcionalidade ainda não implementada'
        ];
    }

    /**
     * Exportar relatório em Excel
     */
    public function exportExcel()
    {
        // Implementação futura com biblioteca Excel
        return [
            'success' => false,
            'message' => 'Funcionalidade ainda não implementada'
        ];
    }

    /**
     * Obter estatísticas por período
     */
    public function getStatsByPeriod()
    {
        $dataInicio = $_GET['data_inicio'] ?? null;
        $dataFim = $_GET['data_fim'] ?? null;

        if (!$dataInicio || !$dataFim) {
            return [
                'success' => false,
                'message' => 'Datas inválidas'
            ];
        }

        try {
            // Candidaturas no período
            $sqlCandidaturas = "SELECT COUNT(*) as total
                               FROM candidaturas 
                               WHERE criado_em >= ? AND criado_em <= ?";
            
            $stmtCandidaturas = $this->database->prepare($sqlCandidaturas);
            $stmtCandidaturas->execute([$dataInicio, $dataFim]);
            $candidaturasTotal = $stmtCandidaturas->fetchColumn();
            
            // Documentos no período
            $sqlDocumentos = "SELECT COUNT(*) as total
                             FROM documentos 
                             WHERE data_envio >= ? AND data_envio <= ?";
            
            $stmtDocumentos = $this->database->prepare($sqlDocumentos);
            $stmtDocumentos->execute([$dataInicio, $dataFim]);
            $documentosTotal = $stmtDocumentos->fetchColumn();
            
            // Estágios no período
            $sqlEstagios = "SELECT COUNT(*) as total
                           FROM estagios 
                           WHERE criado_em >= ? AND criado_em <= ?";
            
            $stmtEstagios = $this->database->prepare($sqlEstagios);
            $stmtEstagios->execute([$dataInicio, $dataFim]);
            $estagiosTotal = $stmtEstagios->fetchColumn();

            return [
                'success' => true,
                'data' => [
                    'periodo' => $dataInicio,
                    'periodo_fim' => $dataFim,
                    'candidaturas_novas' => $candidaturasTotal,
                    'documentos_enviados' => $documentosTotal,
                    'estagios_adicionados' => $estagiosTotal
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}
