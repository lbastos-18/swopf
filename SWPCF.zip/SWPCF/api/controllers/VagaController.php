<?php
/**
 * Controller: Vaga
 * Gerencia operações CRUD de vagas
 */

class VagaController
{
    private $model;

    public function __construct()
    {
        $this->model = new Vaga();
    }

    /**
     * GET /api/vagas
     * Listar vagas
     */
    public function index()
    {
        requireMethod('GET');
        
        $limit = $_GET['limit'] ?? 20;
        $offset = $_GET['offset'] ?? 0;
        $empresa = $_GET['empresa'] ?? null;
        $localizacao = $_GET['localizacao'] ?? null;
        $tipo = $_GET['tipo'] ?? null;

        $sql = "SELECT * FROM " . $this->model->table . " WHERE ativo = 1 AND (data_encerramento IS NULL OR data_encerramento >= CURDATE())";
        $params = [];

        if ($empresa) {
            $sql .= " AND empresa = ?";
            $params[] = $empresa;
        }

        if ($localizacao) {
            $sql .= " AND localizacao = ?";
            $params[] = $localizacao;
        }

        if ($tipo) {
            $sql .= " AND tipo_contracto = ?";
            $params[] = $tipo;
        }

        $sql .= " ORDER BY data_publicacao DESC";

        $db = Database::getInstance();
        $vagas = $db->query($sql . " LIMIT ? OFFSET ?", array_merge($params, [$limit, $offset]))->fetchAll();
        $total = $this->model->count();

        jsonResponse([
            'vagas' => $vagas,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset
        ]);
    }

    /**
     * GET /api/vagas/:id
     * Obter uma vaga
     */
    public function show($id)
    {
        requireMethod('GET');

        $vaga = $this->model->withCurso($id);

        if (!$vaga) {
            jsonResponse([], 404, 'Vaga não encontrada');
        }

        // Adicionar contagem de candidaturas
        $vaga['total_candidaturas'] = $this->model->countCandidaturas($id);

        jsonResponse($vaga);
    }

    /**
     * POST /api/vagas
     * Criar nova vaga (Admin/Gestor)
     */
    public function store()
    {
        requireMethod('POST');
        $user = AuthMiddleware::verifyRole('gestor');

        $input = getJsonInput();

        // Validações
        if (empty($input['titulo']) || strlen($input['titulo']) < 3) {
            jsonResponse([], 400, 'Título deve ter pelo menos 3 caracteres');
        }

        if (empty($input['empresa'])) {
            jsonResponse([], 400, 'Empresa é obrigatória');
        }

        $data = [
            'titulo' => sanitize($input['titulo']),
            'descricao' => sanitize($input['descricao'] ?? ''),
            'empresa' => sanitize($input['empresa']),
            'localizacao' => sanitize($input['localizacao'] ?? ''),
            'tipo_contracto' => $input['tipo_contracto'] ?? 'permanente',
            'salario_minimo' => (float)$input['salario_minimo'] ?? 0,
            'salario_maximo' => (float)$input['salario_maximo'] ?? 0,
            'numero_vagas' => (int)$input['numero_vagas'] ?? 1,
            'competencias_requeridas' => sanitize($input['competencias_requeridas'] ?? ''),
            'beneficios' => sanitize($input['beneficios'] ?? ''),
            'data_encerramento' => $input['data_encerramento'] ?? null,
            'curso_relacionado_id' => $input['curso_relacionado_id'] ?? null,
            'criado_por' => $user['id'],
            'ativo' => 1
        ];

        try {
            $vaga_id = $this->model->create($data);
            logAction($user['id'], 'criar', 'vaga', $vaga_id, null, $data);
            sendNotification($user['id'], 'Nova Vaga', 'Vaga publicada com sucesso', 'sucesso', 'vaga', $vaga_id);
            
            jsonResponse(['id' => $vaga_id], 201, 'Vaga criada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao criar vaga');
        }
    }

    /**
     * PUT /api/vagas/:id
     * Atualizar vaga
     */
    public function update($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('gestor');

        $vaga = $this->model->find($id);
        if (!$vaga) {
            jsonResponse([], 404, 'Vaga não encontrada');
        }

        $input = getJsonInput();
        $update_data = [];

        if (!empty($input['titulo'])) {
            $update_data['titulo'] = sanitize($input['titulo']);
        }
        if (!empty($input['descricao'])) {
            $update_data['descricao'] = sanitize($input['descricao']);
        }
        if (isset($input['ativo'])) {
            $update_data['ativo'] = (bool)$input['ativo'];
        }

        if (empty($update_data)) {
            jsonResponse([], 400, 'Nenhum dado para atualizar');
        }

        try {
            $this->model->update($id, $update_data);
            logAction($user['id'], 'atualizar', 'vaga', $id, $vaga, $update_data);
            jsonResponse(['id' => $id], 200, 'Vaga atualizada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar vaga');
        }
    }

    /**
     * DELETE /api/vagas/:id
     * Deletar vaga
     */
    public function destroy($id)
    {
        requireMethod('DELETE');
        $user = AuthMiddleware::verifyRole('admin');

        $vaga = $this->model->find($id);
        if (!$vaga) {
            jsonResponse([], 404, 'Vaga não encontrada');
        }

        try {
            $this->model->delete($id);
            logAction($user['id'], 'deletar', 'vaga', $id, $vaga, null);
            jsonResponse([], 200, 'Vaga deletada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao deletar vaga');
        }
    }

    /**
     * GET /api/vagas/stats
     * Obter estatísticas de vagas
     */
    public function stats()
    {
        requireMethod('GET');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
