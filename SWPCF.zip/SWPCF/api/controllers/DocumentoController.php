<?php

class DocumentoController
{
    private $model;
    private $upload_dir = 'uploads/documentos/';
    private $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
    private $max_size = 5242880;

    public function __construct()
    {
        $this->model = new Documento();
        if (!is_dir($this->upload_dir)) {
            mkdir($this->upload_dir, 0755, true);
        }
    }

    public function index()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('admin');

        $status = $_GET['status'] ?? null;
        $candidatura_id = $_GET['candidatura_id'] ?? null;

        if ($status) {
            $documentos = $this->model->getByStatus($status);
        } elseif ($candidatura_id) {
            $documentos = $this->model->getByCandidatura($candidatura_id);
        } else {
            $documentos = $this->model->getPendingDocuments();
        }

        jsonResponse(['documentos' => $documentos]);
    }

    public function show($id)
    {
        requireMethod('GET');

        $documento = $this->model->find($id);
        if (!$documento) {
            jsonResponse([], 404, 'Documento não encontrado');
        }

        jsonResponse($documento);
    }

    public function upload()
    {
        requireMethod('POST');
        $user = AuthMiddleware::verifyRole('candidato');

        if (!isset($_FILES['arquivo']) || $_FILES['arquivo']['error'] !== UPLOAD_ERR_OK) {
            jsonResponse([], 400, 'Erro ao fazer upload do ficheiro');
        }

        $input = getJsonInput();
        $candidatura_id = $input['candidatura_id'] ?? null;
        $tipo = $input['tipo'] ?? null;

        if (!$candidatura_id || !$tipo) {
            jsonResponse([], 400, 'Candidatura e tipo de documento são obrigatórios');
        }

        if (!in_array($tipo, ['bi', 'comprovativo'])) {
            jsonResponse([], 400, 'Tipo de documento inválido');
        }

        $file = $_FILES['arquivo'];

        if ($file['size'] > $this->max_size) {
            jsonResponse([], 400, 'Ficheiro muito grande (máximo 5MB)');
        }

        if (!in_array($file['type'], $this->allowed_types)) {
            jsonResponse([], 400, 'Tipo de ficheiro não permitido (PDF, JPEG ou PNG)');
        }

        try {
            $candidatura = new Candidatura();
            $cand = $candidatura->find($candidatura_id);
            
            if (!$cand || $cand['candidato_id'] != $user['id']) {
                jsonResponse([], 403, 'Acesso negado');
            }

            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '_' . $candidatura_id . '_' . $tipo . '.' . $extension;
            $filepath = $this->upload_dir . $filename;

            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                jsonResponse([], 500, 'Erro ao guardar ficheiro');
            }

            $data = [
                'candidatura_id' => $candidatura_id,
                'tipo' => $tipo,
                'caminho_arquivo' => $filepath,
                'nome_original' => $file['name'],
                'status_validacao' => 'pendente'
            ];

            $documento_id = $this->model->create($data);

            logAction($user['id'], 'upload', 'documento', $documento_id, null, [
                'tipo' => $tipo,
                'candidatura_id' => $candidatura_id
            ]);

            sendNotification(1, 'Novo Documento', 'Novo documento submetido para validação', 'info', 'documento', $documento_id);

            jsonResponse(['id' => $documento_id], 201, 'Documento enviado com sucesso');

        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao fazer upload: ' . $e->getMessage());
        }
    }

    public function validate($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('admin');

        $documento = $this->model->find($id);
        if (!$documento) {
            jsonResponse([], 404, 'Documento não encontrado');
        }

        $input = getJsonInput();

        if (!isset($input['aprovado'])) {
            jsonResponse([], 400, 'Decisão de validação obrigatória');
        }

        $aprovado = (bool)$input['aprovado'];
        $observacao = $input['observacao'] ?? null;

        try {
            $this->model->validate($id, $aprovado, $observacao, $user['id']);

            $status_msg = $aprovado ? 'aprovado' : 'rejeitado';
            logAction($user['id'], 'validar', 'documento', $id, $documento, [
                'status' => $status_msg,
                'observacao' => $observacao
            ]);

            $candidatura = new Candidatura();
            $cand = $candidatura->find($documento['candidatura_id']);

            if ($aprovado) {
                $documento_model = new Documento();
                $docs = $documento_model->getRequiredDocuments($documento['candidatura_id']);
                
                $all_approved = true;
                foreach ($docs as $doc) {
                    if ($doc['status_validacao'] !== 'aprovado' && $doc['id'] != $id) {
                        $all_approved = false;
                        break;
                    }
                }

                if ($all_approved) {
                    $candidatura->update($documento['candidatura_id'], [
                        'status' => 'documentos_aprovados'
                    ]);

                    sendNotification($cand['utilizador_id'], 'Documentos Aprovados', 'Seus documentos foram aprovados', 'sucesso', 'candidatura', $documento['candidatura_id']);
                }
            } else {
                $candidatura->update($documento['candidatura_id'], [
                    'status' => 'documentos_rejeitados'
                ]);

                sendNotification($cand['utilizador_id'], 'Documento Rejeitado', 'Seu documento foi rejeitado. Observação: ' . $observacao, 'alerta', 'candidatura', $documento['candidatura_id']);
            }

            jsonResponse([], 200, 'Validação concluída com sucesso');

        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao validar documento');
        }
    }

    public function download($id)
    {
        requireMethod('GET');
        $user = AuthMiddleware::verifyRole('admin');

        $documento = $this->model->find($id);
        if (!$documento) {
            jsonResponse([], 404, 'Documento não encontrado');
        }

        if (!file_exists($documento['caminho_arquivo'])) {
            jsonResponse([], 404, 'Ficheiro não encontrado');
        }

        header('Content-Type: ' . mime_content_type($documento['caminho_arquivo']));
        header('Content-Disposition: attachment; filename="' . $documento['nome_original'] . '"');
        header('Content-Length: ' . filesize($documento['caminho_arquivo']));

        readfile($documento['caminho_arquivo']);
        exit;
    }

    public function getPendingByCandidate()
    {
        requireMethod('GET');
        $user = AuthMiddleware::verifyRole('candidato');

        $candidato = new Candidato();
        $cand_record = $candidato->find(['utilizador_id' => $user['id']]);

        if (!$cand_record) {
            jsonResponse([], 404, 'Candidato não encontrado');
        }

        $candidatura = new Candidatura();
        $candidaturas = $candidatura->getByCandidate($cand_record['id']);

        $pending_docs = [];

        foreach ($candidaturas as $cand) {
            if ($cand['status'] === 'pendente' || $cand['status'] === 'em_analise_documentos') {
                $docs = $this->model->getByCandidatura($cand['id']);
                $pending_docs[] = [
                    'candidatura_id' => $cand['id'],
                    'estagio_titulo' => $cand['estagio_titulo'],
                    'documentos' => $docs,
                    'documentos_bi' => count(array_filter($docs, fn($d) => $d['tipo'] === 'bi' && $d['status_validacao'] === 'aprovado')),
                    'documentos_comprovativo' => count(array_filter($docs, fn($d) => $d['tipo'] === 'comprovativo' && $d['status_validacao'] === 'aprovado'))
                ];
            }
        }

        jsonResponse(['pending_documents' => $pending_docs]);
    }

    public function getStats()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('admin');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
