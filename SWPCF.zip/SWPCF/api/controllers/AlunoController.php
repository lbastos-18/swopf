<?php

/**
 * AlunoController
 * Gerencia perfil, cursos e listas de espera do aluno
 */

class AlunoController
{
    private $database;
    private $alunosCurso;
    private $listasEspera;
    private $notificacao;

    public function __construct()
    {
        $this->database = Database::getInstance();
        $this->alunosCurso = new AlunosCurso();
        $this->listasEspera = new ListasEspera();
        $this->notificacao = new Notificacao();
    }

    public function getPerfil()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        try {
            // Obter utilizador
            $sql = "SELECT * FROM utilizadores WHERE id = ?";
            $stmt = $this->database->prepare($sql);
            $stmt->execute([$utilizadorId]);
            $utilizador = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$utilizador) {
                jsonResponse([], 404, 'Utilizador não encontrado');
                return;
            }
            
            
            $estatisticas = $this->alunosCurso->getEstatisticas($utilizadorId);
            
          
            $naoLidas = $this->notificacao->contarNaoLidas($utilizadorId);
            
            
            $cursosEmEspera = $this->listasEspera->getCursosEmEspera($utilizadorId);
            
            jsonResponse([
                'success' => true,
                'utilizador' => $utilizador,
                'estatisticas' => $estatisticas,
                'notificacoes_nao_lidas' => $naoLidas,
                'cursos_em_espera' => count($cursosEmEspera)
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Obter cursos do aluno por status
     */
    public function getMeusCursos()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        $status = $_GET['status'] ?? null;
        
        try {
            $cursos = $this->alunosCurso->getByUserAndStatus($utilizadorId, $status);
            
            jsonResponse([
                'success' => true,
                'cursos' => $cursos,
                'total' => count($cursos)
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Guardar um curso para fazer posteriormente
     */
    public function guardarCurso()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['curso_id'])) {
            jsonResponse([], 400, 'ID do curso é obrigatório');
            return;
        }
        
        try {
            $adicionado = $this->alunosCurso->adicionarCurso($utilizadorId, $input['curso_id'], 'guardado');
            
            if (!$adicionado) {
                jsonResponse([], 400, 'Curso já está guardado');
                return;
            }
            
            jsonResponse([
                'success' => true,
                'message' => 'Curso guardado com sucesso!'
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Inscrever-se num curso
     */
    public function inscreverCurso()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['curso_id'])) {
            jsonResponse([], 400, 'ID do curso é obrigatório');
            return;
        }
        
        try {
            $cursoId = $input['curso_id'];
            
            // Verificar se curso existe e tem vagas
            $sqlCurso = "SELECT * FROM cursos WHERE id = ?";
            $stmtCurso = $this->database->prepare($sqlCurso);
            $stmtCurso->execute([$cursoId]);
            $curso = $stmtCurso->fetch(PDO::FETCH_ASSOC);
            
            if (!$curso) {
                jsonResponse([], 404, 'Curso não encontrado');
                return;
            }
            
            // Verificar se aluno já está inscrito
            if ($this->alunosCurso->estaInscrito($utilizadorId, $cursoId)) {
                jsonResponse([], 400, 'Você já está inscrito neste curso');
                return;
            }
            
            // Se há vagas, inscrever
            if ($curso['vagas_disponibilidade'] && $curso['total_inscritos'] < $curso['vagas_disponibilidade']) {
                $inscrito = $this->alunosCurso->adicionarCurso($utilizadorId, $cursoId, 'em_progresso');
                
                if ($inscrito) {
                    // Atualizar inscritos
                    $sqlAtualiza = "UPDATE cursos SET total_inscritos = total_inscritos + 1 WHERE id = ?";
                    $stmtAtualiza = $this->database->prepare($sqlAtualiza);
                    $stmtAtualiza->execute([$cursoId]);
                    
                    jsonResponse([
                        'success' => true,
                        'message' => 'Inscrito com sucesso no curso!',
                        'status' => 'inscrito'
                    ]);
                }
            } else {
                // Adicionar à lista de espera
                $adicionado = $this->listasEspera->adicionarAListaEsperaCurso($utilizadorId, $cursoId);
                
                if ($adicionado) {
                    $posicao = $this->listasEspera->getPosicaoListaEsperaCurso($utilizadorId, $cursoId);
                    
                    jsonResponse([
                        'success' => true,
                        'message' => 'Adicionado à lista de espera',
                        'status' => 'lista_espera',
                        'posicao' => $posicao
                    ]);
                } else {
                    jsonResponse([], 400, 'Você já está na lista de espera deste curso');
                }
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Remover curso ou cancelar inscrição
     */
    public function removerCurso()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['curso_id'])) {
            jsonResponse([], 400, 'ID do curso é obrigatório');
            return;
        }
        
        try {
            $removido = $this->alunosCurso->removerCurso($utilizadorId, $input['curso_id']);
            
            if (!$removido) {
                jsonResponse([], 400, 'Não foi possível remover o curso');
                return;
            }
            
            jsonResponse([
                'success' => true,
                'message' => 'Curso removido com sucesso'
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Obter cursos em lista de espera
     */
    public function getCursosEmEspera()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        try {
            $cursos = $this->listasEspera->getCursosEmEspera($utilizadorId);
            
            jsonResponse([
                'success' => true,
                'cursos' => $cursos,
                'total' => count($cursos)
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Remover da lista de espera
     */
    public function removerDaListaEspera()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['curso_id'])) {
            jsonResponse([], 400, 'ID do curso é obrigatório');
            return;
        }
        
        try {
            $removido = $this->listasEspera->removerDaListaEsperaCurso($utilizadorId, $input['curso_id']);
            
            if (!$removido) {
                jsonResponse([], 400, 'Não foi possível remover da lista de espera');
                return;
            }
            
            jsonResponse([
                'success' => true,
                'message' => 'Removido da lista de espera com sucesso'
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Obter notificações do aluno
     */
    public function getNotificacoes()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        $apenasNaoLidas = isset($_GET['apenas_nao_lidas']) && $_GET['apenas_nao_lidas'] === 'true';
        
        try {
            $notificacoes = $this->notificacao->getByUtilizadorId($utilizadorId, $apenasNaoLidas);
            $estatisticas = $this->notificacao->getEstatisticas($utilizadorId);
            
            jsonResponse([
                'success' => true,
                'notificacoes' => $notificacoes,
                'total' => count($notificacoes),
                'estatisticas' => $estatisticas
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Marcar notificação como lida
     */
    public function marcarNotificacaoComoLida()
    {
        Auth::verifyToken();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['notificacao_id'])) {
            jsonResponse([], 400, 'ID da notificação é obrigatório');
            return;
        }
        
        try {
            $marcado = $this->notificacao->marcarComoLida($input['notificacao_id']);
            
            if (!$marcado) {
                jsonResponse([], 400, 'Não foi possível marcar a notificação');
                return;
            }
            
            jsonResponse([
                'success' => true,
                'message' => 'Notificação marcada como lida'
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Marcar todas as notificações como lidas
     */
    public function marcarTodasAsNotificacoesComoLidas()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        try {
            $marcado = $this->notificacao->marcarTodasComoLidas($utilizadorId);
            
            jsonResponse([
                'success' => true,
                'message' => 'Todas as notificações foram marcadas como lidas'
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Actualizar perfil do aluno (dados angolanos)
     */
    public function actualizarPerfil()
    {
        Auth::verifyToken();
        $utilizadorId = Auth::getUserId();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        try {
            // Validar dados angolanos se fornecidos
            if (isset($input['numero_documento'])) {
                if (!ValidadorAngola::validarBI($input['numero_documento'])) {
                    jsonResponse([], 400, 'Número de BI inválido');
                    return;
                }
            }
            
            if (isset($input['telefone'])) {
                if (!ValidadorAngola::validarTelefonAngola($input['telefone'])) {
                    jsonResponse([], 400, 'Número de telefone angolano inválido');
                    return;
                }
                $input['telefone'] = ValidadorAngola::formatarTelefonAngola($input['telefone']);
            }
            
            if (isset($input['data_nascimento'])) {
                if (!ValidadorAngola::validarMaiorIdade($input['data_nascimento'])) {
                    jsonResponse([], 400, 'Deve ser maior de 18 anos');
                    return;
                }
            }
            
            // Atualizar perfil
            $camposPermitidos = ['nome', 'email', 'telefone', 'numero_documento', 'data_nascimento', 'genero', 'endereco', 'provincia'];
            $update = [];
            $valores = [];
            
            foreach ($camposPermitidos as $campo) {
                if (isset($input[$campo])) {
                    $update[] = "$campo = ?";
                    $valores[] = $input[$campo];
                }
            }
            
            if (empty($update)) {
                jsonResponse([], 400, 'Nenhum campo para actualizar fornecido');
                return;
            }
            
            $valores[] = $utilizadorId;
            
            $sql = "UPDATE utilizadores SET " . implode(', ', $update) . " WHERE id = ?";
            $stmt = $this->database->prepare($sql);
            $stmt->execute($valores);
            
            jsonResponse([
                'success' => true,
                'message' => 'Perfil actualizado com sucesso'
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }
}
