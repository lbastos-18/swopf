<?php
/**
 * Controller: Utilizador
 * Gerencia autenticação e perfil de utilizadores
 */

class UtilizadorController
{
    private $model;

    public function __construct()
    {
        $this->model = new Utilizador();
    }

    /**
     * POST /api/auth/register
     * Registar novo utilizador
     */
    public function register()
    {
        requireMethod('POST');
        
        $input = getJsonInput();
        
        // Validações
        if (empty($input['nome']) || strlen($input['nome']) < 3) {
            jsonResponse([], 400, 'Nome deve ter pelo menos 3 caracteres');
        }
        
        if (!isValidEmail($input['email'])) {
            jsonResponse([], 400, 'Email inválido');
        }
        
        if (empty($input['password']) || strlen($input['password']) < 6) {
            jsonResponse([], 400, 'Password deve ter pelo menos 6 caracteres');
        }

        try {
            $utilizador_id = $this->model->register(
                sanitize($input['nome']),
                sanitize($input['email']),
                $input['password'],
                sanitize($input['telefone'] ?? null)
            );

            // Criar perfil de candidato
            $candidato = new Candidato();
            $candidato->create(['utilizador_id' => $utilizador_id]);

            // Log da ação
            logAction($utilizador_id, 'registro', 'utilizador', $utilizador_id);

            // Enviar notificação
            sendNotification($utilizador_id, 'Bem-vindo!', 'Sua conta foi criada com sucesso.', 'sucesso');

            jsonResponse(['id' => $utilizador_id], 201, 'Utilizador registado com sucesso');

        } catch (Exception $e) {
            jsonResponse([], 400, $e->getMessage());
        }
    }

    /**
     * POST /api/auth/register-candidato
     * Registar novo candidato (página pública)
     */
    public function registerCandidato()
    {
        $input = SecurityMiddleware::getJsonInput();

        // Validate input using the new Validator class
        $validator = new Validator();
        $validator
            ->required('nome', $input['nome'] ?? null)
            ->minLength('nome', $input['nome'] ?? null, 3)
            ->required('email', $input['email'] ?? null)
            ->email('email', $input['email'] ?? null)
            ->required('senha', $input['senha'] ?? null)
            ->minLength('senha', $input['senha'] ?? null, 6)
            ->required('numero_documento', $input['numero_documento'] ?? null)
            ->biAngola('numero_documento', $input['numero_documento'] ?? null)
            ->required('telefone', $input['telefone'] ?? null)
            ->phoneAngola('telefone', $input['telefone'] ?? null)
            ->unique('email', $input['email'] ?? null, 'utilizadores')
            ->unique('numero_documento', $input['numero_documento'] ?? null, 'utilizadores');

        if ($validator->hasErrors()) {
            Response::badRequest($validator->getErrors())->send();
        }

        try {
            // Prepare data for insertion
            $nome = SecurityMiddleware::sanitize($input['nome'] ?? '');
            $email = SecurityMiddleware::sanitize($input['email'] ?? '');
            $telefone = SecurityMiddleware::sanitize($input['telefone'] ?? '');
            $numero_documento = SecurityMiddleware::sanitize($input['numero_documento'] ?? '');

            $db = Database::getInstance();

            $sql = "INSERT INTO utilizadores (
                        nome, email, password, telefone, numero_documento,
                        data_nascimento, genero, endereco, provincia,
                        pais_origem, role, telefone_validado, criado_em, actualizado_em
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";

            $db->insert($sql, [
                $nome,
                $email,
                password_hash($input['senha'], PASSWORD_BCRYPT, ['cost' => 12]),
                $telefone,
                $numero_documento,
                $input['data_nascimento'] ?? null,
                $input['genero'] ?? 'Outro',
                $input['endereco'] ?? null,
                $input['provincia'] ?? null,
                'Angola',
                'candidato',
                0
            ]);

            $novoId = $db->lastInsertId();

            Response::created(
                ['id' => $novoId],
                'Conta criada com sucesso! Pode fazer login agora.'
            )->send();

        } catch (Exception $e) {
            Response::serverError($e->getMessage())->send();
        }
    }

    /**
     * POST /api/auth/login
     * Autenticar utilizador
     */
    public function login()
    {
        requireMethod('POST');
        
        $input = getJsonInput();

        if (empty($input['email']) || empty($input['password'])) {
            jsonResponse([], 400, 'Email e password são obrigatórios');
        }

        try {
            $user = $this->model->authenticate(
                sanitize($input['email']),
                $input['password']
            );

            // Gerar token
            $token = generateToken([
                'id' => $user['id'],
                'email' => $user['email'],
                'tipo_utilizador' => $user['tipo_utilizador']
            ]);

            // Log da ação
            logAction($user['id'], 'login', 'utilizador', $user['id']);

            jsonResponse([
                'token' => $token,
                'user' => $user
            ], 200, 'Login realizado com sucesso');

        } catch (Exception $e) {
            logAction(null, 'login_falho', 'utilizador', 0);
            jsonResponse([], 401, $e->getMessage());
        }
    }

    /**
     * GET /api/users/:id
     * Obter dados de um utilizador
     */
    public function show($id)
    {
        requireMethod('GET');

        $user = $this->model->find($id);

        if (!$user) {
            jsonResponse([], 404, 'Utilizador não encontrado');
        }

        unset($user['password_hash']);
        jsonResponse($user);
    }

    /**
     * PUT /api/users/:id
     * Atualizar dados de utilizador
     */
    public function update($id)
    {
        requireMethod('PUT');
        AuthMiddleware::verifyToken();

        $input = getJsonInput();
        
        $user = $this->model->find($id);
        if (!$user) {
            jsonResponse([], 404, 'Utilizador não encontrado');
        }

        $update_data = [];
        
        if (!empty($input['nome'])) {
            $update_data['nome'] = sanitize($input['nome']);
        }
        
        if (!empty($input['telefone'])) {
            $update_data['telefone'] = sanitize($input['telefone']);
        }

        if (empty($update_data)) {
            jsonResponse([], 400, 'Nenhum dado para atualizar');
        }

        try {
            $this->model->update($id, $update_data);
            logAction($id, 'atualizar', 'utilizador', $id, $user, $update_data);
            jsonResponse(['id' => $id], 200, 'Utilizador atualizado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar utilizador');
        }
    }

    /**
     * GET /api/users
     * Listar todos os utilizadores (Admin)
     */
    public function index()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('admin');

        $users = $this->model->all();
        
        // Remover hashes de password
        foreach ($users as &$user) {
            unset($user['password_hash']);
        }

        jsonResponse($users);
    }

    /**
     * GET /api/users/stats
     * Obter estatísticas de utilizadores
     */
    public function stats()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('admin');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
