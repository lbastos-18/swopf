<?php
/**
 * Controller: Candidato
 * Gerencia dados de candidatos
 */

class CandidatoController
{
    private $model;

    public function __construct()
    {
        $this->model = new Candidato();
    }

    /**
     * GET /api/candidatos
     * Listar candidatos (Admin/Gestor)
     */
    public function index()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('gestor');

        $cidade = $_GET['cidade'] ?? null;
        $disponivel = $_GET['disponivel'] ?? null;
        $limit = $_GET['limit'] ?? 20;
        $offset = $_GET['offset'] ?? 0;

        $sql = "SELECT c.*, u.nome, u.email, u.telefone FROM " . $this->model->table . " c INNER JOIN utilizadores u ON c.utilizador_id = u.id";

        $params = [];

        if ($cidade) {
            $sql .= " WHERE c.cidade = ?";
            $params[] = $cidade;
        }

        if ($disponivel) {
            if ($params) $sql .= " AND";
            else $sql .= " WHERE";
            $sql .= " c.disponivel_imediato = 1";
        }

        $sql .= " ORDER BY c.data_criacao DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        $db = Database::getInstance();
        $candidatos = $db->query($sql, $params)->fetchAll();
        $total = $this->model->count();

        jsonResponse([
            'candidatos' => $candidatos,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset
        ]);
    }

    /**
     * GET /api/candidatos/:id
     * Obter perfil de um candidato
     */
    public function show($id)
    {
        requireMethod('GET');

        $candidato = $this->model->withUser($id);

        if (!$candidato) {
            jsonResponse([], 404, 'Candidato não encontrado');
        }

        // Adicionar candidaturas
        $candidatura_model = new Candidatura();
        $candidato['candidaturas'] = $candidatura_model->getByCandidate($id);
        $candidato['total_candidaturas'] = $this->model->countCandidaturas($id);

        jsonResponse($candidato);
    }

    /**
     * PUT /api/candidatos/:id
     * Atualizar perfil de candidato
     */
    public function updateProfile($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyToken();

        $candidato = $this->model->find($id);
        if (!$candidato) {
            jsonResponse([], 404, 'Candidato não encontrado');
        }

        $input = getJsonInput();
        $update_data = [];

        if (!empty($input['data_nascimento'])) {
            $update_data['data_nascimento'] = $input['data_nascimento'];
        }
        if (!empty($input['morada'])) {
            $update_data['morada'] = sanitize($input['morada']);
        }
        if (!empty($input['cidade'])) {
            $update_data['cidade'] = sanitize($input['cidade']);
        }
        if (!empty($input['competencias'])) {
            $update_data['competencias'] = sanitize($input['competencias']);
        }
        if (isset($input['disponivel_imediato'])) {
            $update_data['disponivel_imediato'] = (bool)$input['disponivel_imediato'];
        }

        if (empty($update_data)) {
            jsonResponse([], 400, 'Nenhum dado para atualizar');
        }

        try {
            $this->model->update($id, $update_data);
            logAction($user['id'], 'atualizar_perfil', 'candidato', $id, $candidato, $update_data);
            sendNotification($user['id'], 'Perfil Atualizado', 'Seu perfil foi atualizado com sucesso', 'sucesso');
            
            jsonResponse(['id' => $id], 200, 'Perfil atualizado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar perfil');
        }
    }

    /**
     * POST /api/candidatos/:id/cv
     * Upload de CV
     */
    public function uploadCV($id)
    {
        requireMethod('POST');
        AuthMiddleware::verifyToken();

        if (!isset($_FILES['cv'])) {
            jsonResponse([], 400, 'Nenhum ficheiro enviado');
        }

        $file = $_FILES['cv'];
        $allowed_types = ['pdf', 'doc', 'docx'];
        
        if (!isValidFileType($file['name'], $allowed_types)) {
            jsonResponse([], 400, 'Tipo de ficheiro não permitido. Use PDF ou Word.');
        }

        if (!isValidFileSize($file['size'], 5)) {
            jsonResponse([], 400, 'Ficheiro muito grande. Máximo 5MB.');
        }

        try {
            $upload_dir = ensureUploadDir('cv');
            $filename = uniqid('cv_' . $id . '_') . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
            $filepath = $upload_dir . '/' . $filename;

            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $this->model->update($id, [
                    'cv_original_filename' => $file['name'],
                    'cv_file_path' => 'uploads/cv/' . $filename
                ]);

                jsonResponse([
                    'filename' => $filename,
                    'original_name' => $file['name'],
                    'url' => UPLOADS_URL . '/cv/' . $filename
                ], 200, 'CV enviado com sucesso');
            } else {
                jsonResponse([], 500, 'Erro ao fazer upload do ficheiro');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao processar upload');
        }
    }

    /**
     * GET /api/candidatos/stats
     * Obter estatísticas de candidatos
     */
    public function stats()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('admin');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
