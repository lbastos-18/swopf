<?php
class AdminsController
{
    private $database;

    public function __construct()
    {
        $this->database = Database::getInstance();
    }

    /**
     * Listar todos os administradores
     */
    public function index()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        try {
            $sql = "SELECT u.id, u.nome, u.email, u.telefone, u.role, u.criado_em, u.actualizado_em,
                           COUNT(DISTINCT a.id) as acoes_auditoria
                    FROM utilizadores u
                    LEFT JOIN auditoria a ON u.id = a.admin_id
                    WHERE u.role = 'admin'
                    ORDER BY u.criado_em DESC";

            $stmt = $this->database->query($sql);
            $administradores = $stmt->fetchAll(PDO::FETCH_ASSOC);

            jsonResponse([
                'success' => true,
                'administradores' => $administradores,
                'total' => count($administradores)
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Obter detalhes de um administrador
     */
    public function show()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $id = (int)($_GET['id'] ?? 0);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do administrador é obrigatório');
            return;
        }

        try {
            $sql = "SELECT u.* FROM utilizadores u WHERE u.id = ? AND u.role = 'admin'";
            $stmt = $this->database->prepare($sql);
            $stmt->execute([$id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$admin) {
                jsonResponse([], 404, 'Administrador não encontrado');
                return;
            }

            jsonResponse([
                'success' => true,
                'administrador' => $admin
            ]);
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Criar novo administrador
     */
    public function store()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $input = json_decode(file_get_contents('php://input'), true);

        try {
            // Validações obrigatórias
            $campos_obrigatorios = ['nome', 'email', 'senha'];
            foreach ($campos_obrigatorios as $campo) {
                if (empty($input[$campo])) {
                    jsonResponse([], 400, "Campo '$campo' é obrigatório");
                    return;
                }
            }

            // Validar email
            if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
                jsonResponse([], 400, 'Email inválido');
                return;
            }

            // Verificar email único
            $sqlEmail = "SELECT COUNT(*) as total FROM utilizadores WHERE email = ?";
            $stmtEmail = $this->database->prepare($sqlEmail);
            $stmtEmail->execute([$input['email']]);
            $resultEmail = $stmtEmail->fetch(PDO::FETCH_ASSOC);

            if ($resultEmail['total'] > 0) {
                jsonResponse([], 400, 'Email já registado');
                return;
            }

            // Validar telefone se fornecido
            if (!empty($input['telefone'])) {
                if (!ValidadorAngola::validarTelefonAngola($input['telefone'])) {
                    jsonResponse([], 400, 'Número de telefone angolano inválido');
                    return;
                }
                $telefone_formatado = ValidadorAngola::formatarTelefonAngola($input['telefone']);
            } else {
                $telefone_formatado = null;
            }

            // Criar administrador
            $sql = "INSERT INTO utilizadores (
                        nome, email, password, telefone, role, criado_em, actualizado_em
                    ) VALUES (?, ?, ?, ?, ?, NOW(), NOW())";

            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute([
                $input['nome'],
                $input['email'],
                password_hash($input['senha'], PASSWORD_BCRYPT),
                $telefone_formatado,
                'admin'
            ]);

            if ($sucesso) {
                $novoId = $this->database->lastInsertId();
                
                jsonResponse([
                    'success' => true,
                    'message' => 'Administrador criado com sucesso',
                    'id' => $novoId
                ]);
            } else {
                jsonResponse([], 400, 'Erro ao criar administrador');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Actualizar administrador
     */
    public function update()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $id = (int)($_GET['id'] ?? 0);
        $input = json_decode(file_get_contents('php://input'), true);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do administrador é obrigatório');
            return;
        }

        try {
            // Validar telefone se fornecido
            if (isset($input['telefone']) && !empty($input['telefone'])) {
                if (!ValidadorAngola::validarTelefonAngola($input['telefone'])) {
                    jsonResponse([], 400, 'Número de telefone angolano inválido');
                    return;
                }
                $input['telefone'] = ValidadorAngola::formatarTelefonAngola($input['telefone']);
            }

            // Campos permitidos para actualizar
            $camposPermitidos = ['nome', 'email', 'telefone'];
            $update = [];
            $valores = [];

            foreach ($camposPermitidos as $campo) {
                if (isset($input[$campo])) {
                    $update[] = "$campo = ?";
                    $valores[] = $input[$campo];
                }
            }

            if (empty($update)) {
                jsonResponse([], 400, 'Nenhum campo para actualizar fornecido');
                return;
            }

            $valores[] = $id;
            $sql = "UPDATE utilizadores SET " . implode(', ', $update) . ", actualizado_em = NOW() WHERE id = ? AND role = 'admin'";
            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute($valores);

            if ($sucesso && $stmt->rowCount() > 0) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Administrador actualizado com sucesso'
                ]);
            } else {
                jsonResponse([], 404, 'Administrador não encontrado');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Apagar administrador (não permite apagar a si mesmo)
     */
    public function delete()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $id = (int)($_GET['id'] ?? 0);
        $usuarioAtual = Auth::getUsuarioAtual();

        if ($id === 0) {
            jsonResponse([], 400, 'ID do administrador é obrigatório');
            return;
        }

        // Prevenir auto-deletion
        if ($id === $usuarioAtual['id']) {
            jsonResponse([], 400, 'Não pode apagar a sua própria conta');
            return;
        }

        // Prevenir apagar o último admin
        $sqlCount = "SELECT COUNT(*) as total FROM utilizadores WHERE role = 'admin'";
        $stmtCount = $this->database->query($sqlCount);
        $resultCount = $stmtCount->fetch(PDO::FETCH_ASSOC);

        if ($resultCount['total'] <= 1) {
            jsonResponse([], 400, 'Não pode apagar o último administrador do sistema');
            return;
        }

        try {
            // Apagar administrador
            $sql = "DELETE FROM utilizadores WHERE id = ? AND role = 'admin'";
            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute([$id]);

            if ($sucesso && $stmt->rowCount() > 0) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Administrador apagado com sucesso'
                ]);
            } else {
                jsonResponse([], 404, 'Administrador não encontrado');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }

    /**
     * Alterar senha de um administrador
     */
    public function alterarSenha()
    {
        Auth::verifyToken();
        Auth::verifyRole(['admin']);

        $id = (int)($_GET['id'] ?? 0);
        $input = json_decode(file_get_contents('php://input'), true);

        if ($id === 0) {
            jsonResponse([], 400, 'ID do administrador é obrigatório');
            return;
        }

        if (empty($input['senha_nova'])) {
            jsonResponse([], 400, 'Nova senha é obrigatória');
            return;
        }

        if (strlen($input['senha_nova']) < 6) {
            jsonResponse([], 400, 'Senha deve ter pelo menos 6 caracteres');
            return;
        }

        try {
            $sql = "UPDATE utilizadores SET password = ?, actualizado_em = NOW() WHERE id = ? AND role = 'admin'";
            $stmt = $this->database->prepare($sql);
            $sucesso = $stmt->execute([
                password_hash($input['senha_nova'], PASSWORD_BCRYPT),
                $id
            ]);

            if ($sucesso && $stmt->rowCount() > 0) {
                jsonResponse([
                    'success' => true,
                    'message' => 'Senha alterada com sucesso'
                ]);
            } else {
                jsonResponse([], 404, 'Administrador não encontrado');
            }
        } catch (Exception $e) {
            jsonResponse([], 500, $e->getMessage());
        }
    }
}
