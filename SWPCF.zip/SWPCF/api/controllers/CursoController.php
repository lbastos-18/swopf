<?php
/**
 * Controller: Curso
 * Gerencia operações CRUD de cursos
 */

class CursoController
{
    private $model;

    public function __construct()
    {
        $this->model = new Curso();
    }

    /**
     * GET /api/cursos
     * Listar cursos
     */
    public function index()
    {
        requireMethod('GET');
        
        $limit = $_GET['limit'] ?? 20;
        $offset = $_GET['offset'] ?? 0;
        $only_active = $_GET['active'] ?? 1;

        $sql = "SELECT * FROM " . $this->model->table;
        
        if ($only_active) {
            $sql .= " WHERE ativo = 1";
        }
        
        $sql .= " ORDER BY data_inicio DESC LIMIT ? OFFSET ?";
        
        $cursos = $this->model->query($sql . " LIMIT ? OFFSET ?", [$limit, $offset])->fetchAll();
        $total = $this->model->count();

        jsonResponse([
            'cursos' => $cursos,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset
        ]);
    }

    /**
     * GET /api/cursos/:id
     * Obter um curso
     */
    public function show($id)
    {
        requireMethod('GET');

        $curso = $this->model->withInstructor($id);

        if (!$curso) {
            jsonResponse([], 404, 'Curso não encontrado');
        }

        // Adicionar contagem de inscrições
        $curso['inscritos'] = $this->model->countInscricoes($id);

        jsonResponse($curso);
    }

    /**
     * POST /api/cursos
     * Criar novo curso (Admin/Gestor)
     */
    public function store()
    {
        requireMethod('POST');
        $user = AuthMiddleware::verifyRole('gestor');

        $input = getJsonInput();

        // Validações
        if (empty($input['titulo']) || strlen($input['titulo']) < 3) {
            jsonResponse([], 400, 'Título deve ter pelo menos 3 caracteres');
        }

        if (empty($input['data_inicio']) || empty($input['data_fim'])) {
            jsonResponse([], 400, 'Datas de início e fim são obrigatórias');
        }

        $data = [
            'titulo' => sanitize($input['titulo']),
            'descricao' => sanitize($input['descricao'] ?? ''),
            'duracao_horas' => (int)$input['duracao_horas'] ?? 0,
            'nivel' => $input['nivel'] ?? 'principiante',
            'preco' => (float)$input['preco'] ?? 0,
            'numero_vagas' => (int)$input['numero_vagas'] ?? 20,
            'data_inicio' => $input['data_inicio'],
            'data_fim' => $input['data_fim'],
            'instructor_id' => $input['instructor_id'] ?? null,
            'criado_por' => $user['id'],
            'ativo' => 1
        ];

        try {
            $curso_id = $this->model->create($data);
            logAction($user['id'], 'criar', 'curso', $curso_id, null, $data);
            sendNotification($user['id'], 'Novo Curso', 'Curso criado com sucesso', 'sucesso', 'curso', $curso_id);
            
            jsonResponse(['id' => $curso_id], 201, 'Curso criado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao criar curso');
        }
    }

    /**
     * PUT /api/cursos/:id
     * Atualizar curso (Admin/Gestor)
     */
    public function update($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('gestor');

        $curso = $this->model->find($id);
        if (!$curso) {
            jsonResponse([], 404, 'Curso não encontrado');
        }

        $input = getJsonInput();
        $update_data = [];

        if (!empty($input['titulo'])) {
            $update_data['titulo'] = sanitize($input['titulo']);
        }
        if (!empty($input['descricao'])) {
            $update_data['descricao'] = sanitize($input['descricao']);
        }
        if (isset($input['status'])) {
            $update_data['ativo'] = (bool)$input['ativo'];
        }

        if (empty($update_data)) {
            jsonResponse([], 400, 'Nenhum dado para atualizar');
        }

        try {
            $this->model->update($id, $update_data);
            logAction($user['id'], 'atualizar', 'curso', $id, $curso, $update_data);
            jsonResponse(['id' => $id], 200, 'Curso atualizado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar curso');
        }
    }

    /**
     * DELETE /api/cursos/:id
     * Deletar curso (Admin)
     */
    public function destroy($id)
    {
        requireMethod('DELETE');
        $user = AuthMiddleware::verifyRole('admin');

        $curso = $this->model->find($id);
        if (!$curso) {
            jsonResponse([], 404, 'Curso não encontrado');
        }

        try {
            $this->model->delete($id);
            logAction($user['id'], 'deletar', 'curso', $id, $curso, null);
            jsonResponse([], 200, 'Curso deletado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao deletar curso');
        }
    }

    /**
     * GET /api/cursos/stats
     * Obter estatísticas de cursos
     */
    public function stats()
    {
        requireMethod('GET');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
