<?php

class EstagioController
{
    private $model;

    public function __construct()
    {
        $this->model = new Estagio();
    }

    public function index()
    {
        requireMethod('GET');
        
        $limit = $_GET['limit'] ?? 20;
        $offset = $_GET['offset'] ?? 0;
        $area = $_GET['area'] ?? null;
        $tipo = $_GET['tipo'] ?? null;
        $escola_id = $_GET['escola_id'] ?? null;

        $sql = "SELECT * FROM " . $this->model->table . " WHERE status = 'ativo' AND data_limite >= CURDATE()";
        $params = [];

        if ($area) {
            $sql .= " AND area = ?";
            $params[] = $area;
        }

        if ($tipo) {
            $sql .= " AND tipo = ?";
            $params[] = $tipo;
        }

        if ($escola_id) {
            $sql .= " AND escola_restrita_id = ?";
            $params[] = $escola_id;
        }

        $sql .= " ORDER BY data_limite ASC";

        $db = Database::getInstance();
        $estagios = $db->query($sql . " LIMIT ? OFFSET ?", array_merge($params, [$limit, $offset]))->fetchAll();
        $total = $this->model->count();

        jsonResponse([
            'estagios' => $estagios,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset
        ]);
    }

    public function show($id)
    {
        requireMethod('GET');

        $estagio = $this->model->withEscola($id);

        if (!$estagio) {
            jsonResponse([], 404, 'Estágio não encontrado');
        }

        $estagio['total_candidaturas'] = $this->model->countCandidaturas($id);
        $estagio['vagas_disponiveis'] = $estagio['numero_vagas'];

        jsonResponse($estagio);
    }

    public function store()
    {
        requireMethod('POST');
        $user = AuthMiddleware::verifyRole('gestor');

        $input = getJsonInput();

        if (empty($input['titulo']) || strlen($input['titulo']) < 3) {
            jsonResponse([], 400, 'Título deve ter pelo menos 3 caracteres');
        }

        if (empty($input['tipo']) || !in_array($input['tipo'], ['remunerado', 'nao_remunerado'])) {
            jsonResponse([], 400, 'Tipo de estágio inválido (remunerado ou nao_remunerado)');
        }

        if (empty($input['area'])) {
            jsonResponse([], 400, 'Área é obrigatória');
        }

        if (empty($input['data_limite'])) {
            jsonResponse([], 400, 'Data limite é obrigatória');
        }

        $data = [
            'titulo' => sanitize($input['titulo']),
            'descricao' => sanitize($input['descricao'] ?? ''),
            'tipo' => $input['tipo'],
            'bolsa_remuneracao' => $input['tipo'] === 'remunerado' ? (float)($input['bolsa_remuneracao'] ?? 0) : null,
            'area' => sanitize($input['area']),
            'duracao' => (int)($input['duracao'] ?? 12),
            'numero_vagas' => (int)($input['numero_vagas'] ?? 1),
            'data_limite' => $input['data_limite'],
            'escola_restrita_id' => $input['escola_restrita_id'] ?? null,
            'criado_por' => $user['id'],
            'status' => 'ativo'
        ];

        try {
            $estagio_id = $this->model->create($data);
            logAction($user['id'], 'criar', 'estagio', $estagio_id, null, $data);
            sendNotification($user['id'], 'Novo Estágio', 'Estágio publicado com sucesso', 'sucesso', 'estagio', $estagio_id);
            
            jsonResponse(['id' => $estagio_id], 201, 'Estágio criado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao criar estágio');
        }
    }

    public function update($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('gestor');

        $estagio = $this->model->find($id);
        if (!$estagio) {
            jsonResponse([], 404, 'Estágio não encontrado');
        }

        $input = getJsonInput();
        $update_data = [];

        if (!empty($input['titulo'])) {
            $update_data['titulo'] = sanitize($input['titulo']);
        }
        if (!empty($input['descricao'])) {
            $update_data['descricao'] = sanitize($input['descricao']);
        }
        if (!empty($input['area'])) {
            $update_data['area'] = sanitize($input['area']);
        }
        if (isset($input['tipo'])) {
            $update_data['tipo'] = $input['tipo'];
        }
        if (isset($input['bolsa_remuneracao'])) {
            $update_data['bolsa_remuneracao'] = $input['tipo'] === 'remunerado' ? (float)$input['bolsa_remuneracao'] : null;
        }
        if (isset($input['duracao'])) {
            $update_data['duracao'] = (int)$input['duracao'];
        }
        if (isset($input['numero_vagas'])) {
            $update_data['numero_vagas'] = (int)$input['numero_vagas'];
        }
        if (!empty($input['data_limite'])) {
            $update_data['data_limite'] = $input['data_limite'];
        }
        if (isset($input['status'])) {
            $update_data['status'] = $input['status'];
        }

        try {
            $this->model->update($id, $update_data);
            logAction($user['id'], 'atualizar', 'estagio', $id, $estagio, $update_data);
            
            jsonResponse([], 200, 'Estágio atualizado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar estágio');
        }
    }

    public function delete($id)
    {
        requireMethod('DELETE');
        $user = AuthMiddleware::verifyRole('admin');

        $estagio = $this->model->find($id);
        if (!$estagio) {
            jsonResponse([], 404, 'Estágio não encontrado');
        }

        try {
            $this->model->delete($id);
            logAction($user['id'], 'deletar', 'estagio', $id, $estagio, null);
            
            jsonResponse([], 200, 'Estágio deletado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao deletar estágio');
        }
    }

    public function close($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('gestor');

        $estagio = $this->model->find($id);
        if (!$estagio) {
            jsonResponse([], 404, 'Estágio não encontrado');
        }

        try {
            $this->model->update($id, ['status' => 'encerrado']);
            logAction($user['id'], 'encerrar', 'estagio', $id, $estagio, ['status' => 'encerrado']);
            sendNotification($user['id'], 'Estágio Encerrado', 'O estágio foi encerrado', 'info', 'estagio', $id);
            
            jsonResponse([], 200, 'Estágio encerrado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao encerrar estágio');
        }
    }

    public function getStats()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('gestor');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
