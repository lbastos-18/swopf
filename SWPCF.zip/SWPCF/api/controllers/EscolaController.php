<?php

class EscolaController
{
    private $model;

    public function __construct()
    {
        $this->model = new Escola();
    }

    public function index()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('gestor');

        $status = $_GET['status'] ?? null;

        if ($status) {
            $escolas = $this->model->getByStatus($status);
        } else {
            $escolas = $this->model->getWithEstagios();
        }

        jsonResponse(['escolas' => $escolas]);
    }

    public function show($id)
    {
        requireMethod('GET');

        $escola = $this->model->getWithEstagios($id);

        if (!$escola) {
            jsonResponse([], 404, 'Escola não encontrada');
        }

        jsonResponse($escola);
    }

    public function store()
    {
        requireMethod('POST');
        $user = AuthMiddleware::verifyRole('gestor');

        $input = getJsonInput();

        if (empty($input['nome'])) {
            jsonResponse([], 400, 'Nome é obrigatório');
        }

        if (empty($input['email']) || !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
            jsonResponse([], 400, 'Email inválido');
        }

        if ($this->model->find(['email' => $input['email']])) {
            jsonResponse([], 400, 'Email já registado');
        }

        $data = [
            'nome' => sanitize($input['nome']),
            'responsavel' => sanitize($input['responsavel'] ?? ''),
            'email' => sanitize($input['email']),
            'telefone' => $input['telefone'] ?? null,
            'documento_parceria' => $input['documento_parceria'] ?? null,
            'status' => 'pendente',
            'observacoes' => sanitize($input['observacoes'] ?? ''),
            'criado_por' => $user['id']
        ];

        try {
            $escola_id = $this->model->create($data);
            logAction($user['id'], 'criar', 'escola', $escola_id, null, $data);
            sendNotification($user['id'], 'Nova Escola Parceira', 'Escola parceira registada com sucesso', 'sucesso', 'escola', $escola_id);
            
            jsonResponse(['id' => $escola_id], 201, 'Escola criada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao criar escola');
        }
    }

    public function update($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('gestor');

        $escola = $this->model->find($id);
        if (!$escola) {
            jsonResponse([], 404, 'Escola não encontrada');
        }

        $input = getJsonInput();
        $update_data = [];

        if (!empty($input['nome'])) {
            $update_data['nome'] = sanitize($input['nome']);
        }
        if (!empty($input['responsavel'])) {
            $update_data['responsavel'] = sanitize($input['responsavel']);
        }
        if (!empty($input['email'])) {
            $update_data['email'] = sanitize($input['email']);
        }
        if (isset($input['telefone'])) {
            $update_data['telefone'] = $input['telefone'];
        }
        if (isset($input['documento_parceria'])) {
            $update_data['documento_parceria'] = $input['documento_parceria'];
        }
        if (isset($input['observacoes'])) {
            $update_data['observacoes'] = sanitize($input['observacoes']);
        }

        try {
            $this->model->update($id, $update_data);
            logAction($user['id'], 'atualizar', 'escola', $id, $escola, $update_data);
            
            jsonResponse([], 200, 'Escola atualizada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar escola');
        }
    }

    public function updateStatus($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('admin');

        $escola = $this->model->find($id);
        if (!$escola) {
            jsonResponse([], 404, 'Escola não encontrada');
        }

        $input = getJsonInput();

        if (empty($input['status']) || !in_array($input['status'], ['pendente', 'ativa', 'suspensa'])) {
            jsonResponse([], 400, 'Status inválido');
        }

        try {
            $this->model->update($id, ['status' => $input['status']]);
            logAction($user['id'], 'atualizar_status', 'escola', $id, $escola, ['status' => $input['status']]);
            
            $status_msg = [
                'ativa' => 'Escola ativada',
                'suspensa' => 'Escola suspensa',
                'pendente' => 'Escola em análise'
            ];
            
            sendNotification($user['id'], 'Status Escola Atualizado', $status_msg[$input['status']], 'info', 'escola', $id);
            
            jsonResponse([], 200, 'Status atualizado com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar status');
        }
    }

    public function getActive()
    {
        requireMethod('GET');

        $escolas = $this->model->getActive();
        jsonResponse(['escolas' => $escolas]);
    }

    public function getStats()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('gestor');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }
}
