<?php

class CandidaturaController
{
    private $model;

    public function __construct()
    {
        $this->model = new Candidatura();
    }

    public function index()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('gestor');

        $status = $_GET['status'] ?? null;
        $estagio_id = $_GET['estagio_id'] ?? null;
        $limit = $_GET['limit'] ?? 20;
        $offset = $_GET['offset'] ?? 0;

        $sql = "SELECT ca.*, e.titulo as estagio_titulo, u.nome as candidato_nome 
                FROM " . $this->model->table . " ca
                INNER JOIN estagios e ON ca.estagio_id = e.id
                INNER JOIN candidatos cand ON ca.candidato_id = cand.id
                INNER JOIN utilizadores u ON cand.utilizador_id = u.id
                WHERE 1=1";

        $params = [];

        if ($status) {
            $sql .= " AND ca.status = ?";
            $params[] = $status;
        }

        if ($estagio_id) {
            $sql .= " AND ca.estagio_id = ?";
            $params[] = $estagio_id;
        }

        $sql .= " ORDER BY ca.data_candidatura DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;

        $db = Database::getInstance();
        $candidaturas = $db->query($sql, $params)->fetchAll();

        jsonResponse([
            'candidaturas' => $candidaturas,
            'limit' => $limit,
            'offset' => $offset
        ]);
    }

    public function show($id)
    {
        requireMethod('GET');

        $candidatura = $this->model->getCandidaturaWithDocuments($id);

        if (!$candidatura) {
            jsonResponse([], 404, 'Candidatura não encontrada');
        }

        jsonResponse($candidatura);
    }

    public function store()
    {
        requireMethod('POST');
        $user = AuthMiddleware::verifyToken();

        $input = getJsonInput();

        if (empty($input['estagio_id'])) {
            jsonResponse([], 400, 'Estágio é obrigatório');
        }

        $candidato_model = new Candidato();
        $candidato = $candidato_model->findByUserId($user['id']);

        if (!$candidato) {
            jsonResponse([], 404, 'Perfil de candidato não encontrado');
        }

        if ($this->model->candidatureExists($input['estagio_id'], $candidato['id'])) {
            jsonResponse([], 409, 'Já se candidatou a este estágio');
        }

        $data = [
            'estagio_id' => (int)$input['estagio_id'],
            'candidato_id' => $candidato['id'],
            'nota_pessoal' => sanitize($input['nota_pessoal'] ?? ''),
            'status' => 'pendente'
        ];

        try {
            $candidatura_id = $this->model->create($data);
            logAction($user['id'], 'candidatar', 'candidatura', $candidatura_id, null, $data);
            
            sendNotification(1, 'Nova Candidatura', 'Novo candidato para estágio', 'info', 'candidatura', $candidatura_id);
            sendNotification($user['id'], 'Candidatura Submetida', 'Sua candidatura foi registada. Aguardando validação de documentos', 'sucesso', 'candidatura', $candidatura_id);

            jsonResponse(['id' => $candidatura_id], 201, 'Candidatura submetida com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao submeter candidatura');
        }
    }

    public function updateStatus($id)
    {
        requireMethod('PUT');
        $user = AuthMiddleware::verifyRole('gestor');

        $candidatura = $this->model->find($id);
        if (!$candidatura) {
            jsonResponse([], 404, 'Candidatura não encontrada');
        }

        $input = getJsonInput();

        $valid_status = ['pendente', 'em_analise_documentos', 'documentos_aprovados', 'documentos_rejeitados', 'aprovado', 'rejeitado', 'cancelado'];
        if (empty($input['status']) || !in_array($input['status'], $valid_status)) {
            jsonResponse([], 400, 'Status inválido');
        }

        $update_data = [
            'status' => $input['status'],
            'observacoes_admin' => sanitize($input['observacoes_admin'] ?? '')
        ];

        try {
            $this->model->update($id, $update_data);
            logAction($user['id'], 'atualizar_candidatura', 'candidatura', $id, $candidatura, $update_data);

            $utilizador_cand = new Candidato();
            $cand_data = $utilizador_cand->find($candidatura['candidato_id']);
            
            sendNotification($cand_data['utilizador_id'], 'Candidatura Atualizada', 'Status: ' . $input['status'], 'info', 'candidatura', $id);

            jsonResponse(['id' => $id], 200, 'Candidatura atualizada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao atualizar candidatura');
        }
    }

    public function destroy($id)
    {
        requireMethod('DELETE');
        $user = AuthMiddleware::verifyToken();

        $candidatura = $this->model->find($id);
        if (!$candidatura) {
            jsonResponse([], 404, 'Candidatura não encontrada');
        }

        try {
            $this->model->delete($id);
            logAction($user['id'], 'cancelar_candidatura', 'candidatura', $id, $candidatura, null);
            
            sendNotification($user['id'], 'Candidatura Cancelada', 'Sua candidatura foi cancelada', 'info');

            jsonResponse([], 200, 'Candidatura cancelada com sucesso');
        } catch (Exception $e) {
            jsonResponse([], 500, 'Erro ao cancelar candidatura');
        }
    }

    public function stats()
    {
        requireMethod('GET');
        AuthMiddleware::verifyRole('admin');

        $stats = $this->model->getStats();
        jsonResponse($stats);
    }

    public function getMyCandidaturas()
    {
        requireMethod('GET');
        $user = AuthMiddleware::verifyToken();

        $candidato_model = new Candidato();
        $candidato = $candidato_model->findByUserId($user['id']);

        if (!$candidato) {
            jsonResponse([], 404, 'Perfil de candidato não encontrado');
        }

        $candidaturas = $this->model->getByCandidate($candidato['id']);

        foreach ($candidaturas as &$cand) {
            $documento = new Documento();
            $cand['documentos'] = $documento->getByCandidatura($cand['id']);
        }

        jsonResponse(['candidaturas' => $candidaturas]);
    }
}
