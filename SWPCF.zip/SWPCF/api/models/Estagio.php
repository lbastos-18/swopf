<?php

class Estagio extends BaseModel
{
    protected $table = 'estagios';
    protected $fillable = ['titulo', 'descricao', 'tipo', 'bolsa_remuneracao', 'area', 'duracao', 'numero_vagas', 'data_limite', 'escola_restrita_id', 'status', 'criado_por'];

    public function withEscola($id = null)
    {
        $sql = "SELECT e.*, es.nome as escola_nome
                FROM {$this->table} e
                LEFT JOIN escolas es ON e.escola_restrita_id = es.id";

        if ($id) {
            $sql .= " WHERE e.id = ?";
            return $this->db->fetch($sql, [$id]);
        }

        $sql .= " ORDER BY e.data_criacao DESC";
        return $this->db->fetchAll($sql);
    }

    public function getActive()
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE status = 'ativo' AND data_limite >= CURDATE()
                ORDER BY data_limite ASC";
        return $this->db->fetchAll($sql);
    }

    public function getByArea($area)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE area = ? AND status = 'ativo'
                ORDER BY data_limite ASC";
        return $this->db->fetchAll($sql, [$area]);
    }

    public function getByType($tipo)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE tipo = ? AND status = 'ativo'
                ORDER BY data_criacao DESC";
        return $this->db->fetchAll($sql, [$tipo]);
    }

    public function getBySchool($escola_id)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE escola_restrita_id = ? AND status = 'ativo'
                ORDER BY data_limite ASC";
        return $this->db->fetchAll($sql, [$escola_id]);
    }

    public function countCandidaturas($estagio_id)
    {
        $sql = "SELECT COUNT(*) as total FROM candidaturas 
                WHERE estagio_id = ?";
        $result = $this->db->fetch($sql, [$estagio_id]);
        return $result['total'] ?? 0;
    }

    public function getCandidaturasByStatus($status)
    {
        $sql = "SELECT e.*, COUNT(ca.id) as total_candidaturas
                FROM {$this->table} e
                LEFT JOIN candidaturas ca ON e.id = ca.estagio_id AND ca.status = ?
                WHERE e.status = 'ativo'
                GROUP BY e.id
                ORDER BY e.data_criacao DESC";
        return $this->db->fetchAll($sql, [$status]);
    }

    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_estagios,
                    SUM(numero_vagas) as total_vagas,
                    COUNT(DISTINCT area) as areas_unicas,
                    (SELECT COUNT(*) FROM candidaturas) as total_candidaturas,
                    SUM(CASE WHEN tipo = 'remunerado' THEN 1 ELSE 0 END) as estagios_remunerados
                FROM {$this->table}
                WHERE status = 'ativo' AND data_limite >= CURDATE()";

        return $this->db->fetch($sql);
    }

    public function decrementVagas($estagio_id)
    {
        $sql = "UPDATE {$this->table} 
                SET numero_vagas = numero_vagas - 1 
                WHERE id = ? AND numero_vagas > 0";
        return $this->db->query($sql, [$estagio_id]);
    }
}
