<?php
/**
 * Classe Base Model
 * Fornece métodos comuns para todos os modelos
 */

abstract class BaseModel
{
    protected $table;
    protected $db;
    protected $fillable = [];
    protected $hidden = [];
    protected $casts = [];

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Buscar por ID
     */
    public function find($id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE id = ?";
        return $this->db->fetch($sql, [$id]);
    }

    /**
     * Buscar todos
     */
    public function all($limit = null, $offset = 0, $order_by = 'id', $order = 'ASC')
    {
        $sql = "SELECT * FROM {$this->table} ORDER BY {$order_by} {$order}";
        
        if ($limit !== null) {
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }
        
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar com filtros
     */
    public function where($column, $operator, $value = null)
    {
        // Suportar: where('column', 'value') e where('column', '=', 'value')
        if ($value === null) {
            $value = $operator;
            $operator = '=';
        }

        $sql = "SELECT * FROM {$this->table} WHERE {$column} {$operator} ?";
        return $this->db->fetchAll($sql, [$value]);
    }

    /**
     * Contar registos
     */
    public function count($where_column = null, $where_value = null)
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table}";
        
        if ($where_column && $where_value) {
            $sql .= " WHERE {$where_column} = ?";
            $result = $this->db->fetch($sql, [$where_value]);
        } else {
            $result = $this->db->fetch($sql);
        }
        
        return $result['total'] ?? 0;
    }

    /**
     * Inserir novo registro
     */
    public function create($data)
    {
        $data = $this->filterFillable($data);
        
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        
        $sql = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
        
        return $this->db->insert($sql, array_values($data));
    }

    /**
     * Atualizar registro
     */
    public function update($id, $data)
    {
        $data = $this->filterFillable($data);
        
        $set = implode(', ', array_map(fn($col) => "{$col} = ?", array_keys($data)));
        $values = array_values($data);
        $values[] = $id;
        
        $sql = "UPDATE {$this->table} SET {$set} WHERE id = ?";
        
        return $this->db->query($sql, $values);
    }

    /**
     * Deletar registro
     */
    public function delete($id)
    {
        $sql = "DELETE FROM {$this->table} WHERE id = ?";
        return $this->db->query($sql, [$id]);
    }

    /**
     * Filtrar dados pela propriedade $fillable
     */
    protected function filterFillable($data)
    {
        if (empty($this->fillable)) {
            return $data;
        }

        return array_filter(
            $data,
            fn($key) => in_array($key, $this->fillable),
            ARRAY_FILTER_USE_KEY
        );
    }

    /**
     * Executar query customizada
     */
    protected function query($sql, $params = [])
    {
        return $this->db->query($sql, $params);
    }
}
