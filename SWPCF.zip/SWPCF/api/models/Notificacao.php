<?php

/**
 * Model: Notificacao
 * Gerencia notificações para utilizadores
 */

class Notificacao extends BaseModel
{
    protected $table = 'notificacao';
    protected $fillable = ['utilizador_id', 'tipo', 'titulo', 'mensagem', 'referencia_tipo', 'referencia_id'];

    /**
     * Criar uma nova notificação
     * 
     * @param int $utilizadorId ID do utilizador
     * @param string $tipo Tipo de notificação
     * @param string $titulo Título da notificação
     * @param string $mensagem Mensagem detalhada
     * @param string $referenciaT ipo Tipo de referência (curso, estagio, etc)
     * @param int $referenciaId ID da referência
     * @return bool
     */
    public function criar($utilizadorId, $tipo, $titulo, $mensagem, $referenciatipo = null, $referenciaId = null)
    {
        $sql = "INSERT INTO notificacao (utilizador_id, tipo, titulo, mensagem, referencia_tipo, referencia_id) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$utilizadorId, $tipo, $titulo, $mensagem, $referenciatipo, $referenciaId]);
    }

    /**
     * Obter notificações de um utilizador
     * 
     * @param int $utilizadorId ID do utilizador
     * @param bool $apenasNaoLidas Se true, apenas não lidas
     * @param int $limite Limite de registos
     * @return array
     */
    public function getByUtilizadorId($utilizadorId, $apenasNaoLidas = false, $limite = 50)
    {
        $sql = "SELECT * FROM notificacao 
                WHERE utilizador_id = ?";
        
        $params = [$utilizadorId];
        
        if ($apenasNaoLidas) {
            $sql .= " AND lida = 0";
        }
        
        $sql .= " ORDER BY criada_em DESC LIMIT ?";
        $params[] = $limite;
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Contar notificações não lidas
     * 
     * @param int $utilizadorId ID do utilizador
     * @return int
     */
    public function contarNaoLidas($utilizadorId)
    {
        $sql = "SELECT COUNT(*) as total FROM notificacao 
                WHERE utilizador_id = ? AND lida = 0";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }

    /**
     * Marcar notificação como lida
     * 
     * @param int $notificacaoId ID da notificação
     * @return bool
     */
    public function marcarComoLida($notificacaoId)
    {
        $sql = "UPDATE notificacao 
                SET lida = 1, data_leitura = NOW()
                WHERE id = ?";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$notificacaoId]);
    }

    /**
     * Marcar todas as notificações como lidas para um utilizador
     * 
     * @param int $utilizadorId ID do utilizador
     * @return bool
     */
    public function marcarTodasComoLidas($utilizadorId)
    {
        $sql = "UPDATE notificacao 
                SET lida = 1, data_leitura = NOW()
                WHERE utilizador_id = ? AND lida = 0";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$utilizadorId]);
    }

    /**
     * Apagar notificação
     * 
     * @param int $notificacaoId ID da notificação
     * @return bool
     */
    public function apagar($notificacaoId)
    {
        $sql = "DELETE FROM notificacao WHERE id = ?";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$notificacaoId]);
    }

    /**
     * Apagar notificações antigas (mais de 30 dias)
     * 
     * @return int Número de notificações apagadas
     */
    public function apagarAntigas()
    {
        $sql = "DELETE FROM notificacao 
                WHERE lida = 1 AND DATEDIFF(NOW(), criada_em) > 30";
        
        $stmt = $this->database->query($sql);
        return $stmt->rowCount();
    }

    /**
     * Obter notificações por tipo
     * 
     * @param int $utilizadorId ID do utilizador
     * @param string $tipo Tipo de notificação
     * @return array
     */
    public function getByTipo($utilizadorId, $tipo)
    {
        $sql = "SELECT * FROM notificacao 
                WHERE utilizador_id = ? AND tipo = ?
                ORDER BY criada_em DESC";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId, $tipo]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Notificar sobre vaga disponível em curso
     * 
     * @param int $cursoId ID do curso
     * @param string $tituloCurso Título do curso
     * @return int Número de utilizadores notificados
     */
    public function notificarVagasCurso($cursoId, $tituloCurso)
    {
        // Obter lista de espera
        $sql = "SELECT DISTINCT le.utilizador_id, u.email, u.nome
                FROM lista_espera_curso le
                JOIN utilizadores u ON le.utilizador_id = u.id
                WHERE le.curso_id = ? AND le.notificado = 0
                ORDER BY le.posicao ASC
                LIMIT 1";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$cursoId]);
        
        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $notificados = 0;
        
        foreach ($resultado as $aluno) {
            $this->criar(
                $aluno['utilizador_id'],
                'curso_disponivel',
                'Vaga disponível! 🎓',
                "Excelente notícia! O curso \"{$tituloCurso}\" tem uma vaga disponível. Inscreva-se agora!",
                'curso',
                $cursoId
            );
            $notificados++;
        }
        
        return $notificados;
    }

    /**
     * Notificar sobre vaga disponível em estágio
     * 
     * @param int $estagioId ID do estágio
     * @param string $tituloEstagio Título do estágio
     * @return int Número de utilizadores notificados
     */
    public function notificarVagasEstagio($estagioId, $tituloEstagio)
    {
        // Obter lista de espera
        $sql = "SELECT DISTINCT le.candidatura_id, c.utilizador_id, u.email, u.nome
                FROM lista_espera_estagio le
                JOIN candidaturas c ON le.candidatura_id = c.id
                JOIN utilizadores u ON c.utilizador_id = u.id
                WHERE le.estagio_id = ? AND le.notificado = 0
                ORDER BY le.posicao ASC
                LIMIT 1";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$estagioId]);
        
        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $notificados = 0;
        
        foreach ($resultado as $candidato) {
            $this->criar(
                $candidato['utilizador_id'],
                'vaga_disponivel',
                'Vaga de Estágio Disponível! 🌟',
                "Excelente notícia! O estágio \"{$tituloEstagio}\" tem uma vaga disponível. Verifique sua candidatura!",
                'estagio',
                $estagioId
            );
            $notificados++;
        }
        
        return $notificados;
    }

    /**
     * Notificar quando documento é validado
     * 
     * @param int $utilizadorId ID do utilizador
     * @param string $tipoDoc Tipo de documento
     * @param string $status aprovado ou rejeitado
     * @return bool
     */
    public function notificarDocumentoValidado($utilizadorId, $tipoDoc, $status)
    {
        $titulo = ($status === 'aprovado') 
            ? "Documento Aprovado! ✅" 
            : "Documento Rejeitado ❌";
        
        $mensagem = ($status === 'aprovado')
            ? "Seu documento ({$tipoDoc}) foi aprovado com sucesso!"
            : "Seu documento ({$tipoDoc}) foi rejeitado. Por favor, verifique e reenvie.";
        
        return $this->criar($utilizadorId, 'documento_validado', $titulo, $mensagem, 'documento', null);
    }

    /**
     * Obter estatísticas de notificações
     * 
     * @param int $utilizadorId ID do utilizador
     * @return array
     */
    public function getEstatisticas($utilizadorId)
    {
        $sql = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN lida = 0 THEN 1 ELSE 0 END) as nao_lidas,
                    SUM(CASE WHEN lida = 1 THEN 1 ELSE 0 END) as lidas,
                    SUM(CASE WHEN tipo = 'curso_disponivel' THEN 1 ELSE 0 END) as cursos,
                    SUM(CASE WHEN tipo = 'vaga_disponivel' THEN 1 ELSE 0 END) as estagios,
                    SUM(CASE WHEN tipo = 'documento_validado' THEN 1 ELSE 0 END) as documentos
                FROM notificacao
                WHERE utilizador_id = ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }
}
