<?php
/**
 * Model: Utilizador
 */

class Utilizador extends BaseModel
{
    protected $table = 'utilizadores';
    protected $fillable = ['nome', 'email', 'password_hash', 'tipo_utilizador', 'telefone', 'ativo'];
    protected $hidden = ['password_hash'];

    /**
     * Buscar por email
     */
    public function findByEmail($email)
    {
        $sql = "SELECT * FROM {$this->table} WHERE email = ? LIMIT 1";
        return $this->db->fetch($sql, [$email]);
    }

    /**
     * Verificar se email já existe
     */
    public function emailExists($email, $exclude_id = null)
    {
        $sql = "SELECT id FROM {$this->table} WHERE email = ?";
        $params = [$email];

        if ($exclude_id) {
            $sql .= " AND id != ?";
            $params[] = $exclude_id;
        }

        return $this->db->fetch($sql, $params) !== false;
    }

    /**
     * Registar novo utilizador
     */
    public function register($nome, $email, $password, $telefone = null)
    {
        if ($this->emailExists($email)) {
            throw new Exception('Este email já está registado');
        }

        $data = [
            'nome' => $nome,
            'email' => $email,
            'password_hash' => hashPassword($password),
            'telefone' => $telefone,
            'tipo_utilizador' => 'candidato',
            'ativo' => true
        ];

        return $this->create($data);
    }

    /**
     * Autenticar utilizador
     */
    public function authenticate($email, $password)
    {
        $user = $this->findByEmail($email);

        if (!$user) {
            throw new Exception('Email ou password incorretos');
        }

        if (!$user['ativo']) {
            throw new Exception('Utilizador desativado');
        }

        if (!verifyPassword($password, $user['password_hash'])) {
            throw new Exception('Email ou password incorretos');
        }

        unset($user['password_hash']);
        return $user;
    }

    /**
     * Obter utilizadores por tipo
     */
    public function getByType($type)
    {
        $sql = "SELECT * FROM {$this->table} WHERE tipo_utilizador = ? AND ativo = 1 ORDER BY nome";
        return $this->db->fetchAll($sql, [$type]);
    }

    /**
     * Obter estatísticas de utilizadores
     */
    public function getStats()
    {
        $sql = "SELECT 
                    tipo_utilizador,
                    COUNT(*) as total,
                    SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativos
                FROM {$this->table}
                GROUP BY tipo_utilizador";

        return $this->db->fetchAll($sql);
    }
}
