<?php
/**
 * Model: Curso
 */

class Curso extends BaseModel
{
    protected $table = 'cursos';
    protected $fillable = ['titulo', 'descricao', 'duracao_horas', 'nivel', 'preco', 'numero_vagas', 'data_inicio', 'data_fim', 'instructor_id', 'ativo'];

    /**
     * Buscar cursos com instrutor
     */
    public function withInstructor($id = null)
    {
        $sql = "SELECT c.*, u.nome as instructor_nome, u.email as instructor_email
                FROM {$this->table} c
                LEFT JOIN utilizadores u ON c.instructor_id = u.id";

        if ($id) {
            $sql .= " WHERE c.id = ?";
            return $this->db->fetch($sql, [$id]);
        }

        $sql .= " ORDER BY c.data_inicio DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar cursos ativos
     */
    public function getActive()
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE ativo = 1 AND data_inicio <= CURDATE() 
                ORDER BY data_inicio DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar cursos por nível
     */
    public function getByLevel($level)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE nivel = ? AND ativo = 1 
                ORDER BY data_inicio DESC";
        return $this->db->fetchAll($sql, [$level]);
    }

    /**
     * Contar inscritos em curso
     */
    public function countInscricoes($curso_id)
    {
        $sql = "SELECT COUNT(*) as total FROM inscricoes_cursos 
                WHERE curso_id = ? AND status_inscricao = 'ativa'";
        $result = $this->db->fetch($sql, [$curso_id]);
        return $result['total'] ?? 0;
    }

    /**
     * Obter estatísticas de cursos
     */
    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_cursos,
                    SUM(numero_vagas) as total_vagas,
                    AVG(duracao_horas) as duracao_media,
                    SUM(numero_vagas) - COUNT(DISTINCT ic.candidato_id) as vagas_disponiveis
                FROM {$this->table} c
                LEFT JOIN inscricoes_cursos ic ON c.id = ic.curso_id";

        return $this->db->fetch($sql);
    }
}
