<?php
/**
 * Model: Candidato
 */

class Candidato extends BaseModel
{
    protected $table = 'candidatos';
    protected $fillable = ['utilizador_id', 'data_nascimento', 'genero', 'morada', 'cidade', 'codigo_postal', 'pais', 'experiencia_profissional', 'formacao_academica', 'cv_file_path', 'foto_perfil_path', 'linkdin_url', 'github_url', 'portfolio_url', 'competencias', 'disponivel_imediato'];

    /**
     * Buscar candidato com dados do utilizador
     */
    public function withUser($id = null)
    {
        $sql = "SELECT c.*, u.nome, u.email, u.telefone, u.ativo
                FROM {$this->table} c
                INNER JOIN utilizadores u ON c.utilizador_id = u.id";

        if ($id) {
            $sql .= " WHERE c.id = ?";
            return $this->db->fetch($sql, [$id]);
        }

        $sql .= " ORDER BY c.data_criacao DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar por utilizador_id
     */
    public function findByUserId($user_id)
    {
        $sql = "SELECT * FROM {$this->table} WHERE utilizador_id = ? LIMIT 1";
        return $this->db->fetch($sql, [$user_id]);
    }

    /**
     * Buscar candidatos disponíveis
     */
    public function getAvailable()
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE disponivel_imediato = 1
                ORDER BY data_criacao DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar candidatos por cidade
     */
    public function getByCity($cidade)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE cidade = ?
                ORDER BY data_criacao DESC";
        return $this->db->fetchAll($sql, [$cidade]);
    }

    /**
     * Buscar candidatos por competência
     */
    public function searchByCompetence($competencia)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE competencias LIKE ?
                ORDER BY data_criacao DESC";
        return $this->db->fetchAll($sql, ['%' . $competencia . '%']);
    }

    /**
     * Contar candidaturas de um candidato
     */
    public function countCandidaturas($candidato_id)
    {
        $sql = "SELECT COUNT(*) as total FROM candidaturas 
                WHERE candidato_id = ?";
        $result = $this->db->fetch($sql, [$candidato_id]);
        return $result['total'] ?? 0;
    }

    /**
     * Obter inscrições em cursos
     */
    public function getInscricoes($candidato_id)
    {
        $sql = "SELECT ic.*, c.titulo as curso_titulo, c.data_inicio, c.data_fim
                FROM inscricoes_cursos ic
                INNER JOIN cursos c ON ic.curso_id = c.id
                WHERE ic.candidato_id = ?
                ORDER BY ic.data_inscricao DESC";
        return $this->db->fetchAll($sql, [$candidato_id]);
    }

    /**
     * Obter estatísticas
     */
    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_candidatos,
                    SUM(CASE WHEN disponivel_imediato = 1 THEN 1 ELSE 0 END) as candidatos_disponiveis,
                    COUNT(DISTINCT cidade) as cidades_representadas,
                    (SELECT COUNT(*) FROM candidaturas) as total_candidaturas
                FROM {$this->table}";

        return $this->db->fetch($sql);
    }
}
