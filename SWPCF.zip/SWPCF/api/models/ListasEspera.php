<?php

/**
 * Model: ListasEspera
 * Gerencia listas de espera para cursos e estágios
 */

class ListasEspera extends BaseModel
{
    /**
     * Adicionar aluno à lista de espera de um curso
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @return bool
     */
    public function adicionarAListaEsperaCurso($utilizadorId, $cursoId)
    {
        // Verificar se já está na lista
        $sqlVerifica = "SELECT COUNT(*) as total FROM lista_espera_curso 
                       WHERE utilizador_id = ? AND curso_id = ?";
        
        $stmtVerifica = $this->database->prepare($sqlVerifica);
        $stmtVerifica->execute([$utilizadorId, $cursoId]);
        $result = $stmtVerifica->fetch(PDO::FETCH_ASSOC);
        
        if ($result['total'] > 0) {
            return false; // Já está na lista
        }
        
        // Obter próxima posição
        $sqlPosicao = "SELECT MAX(posicao) as proxima FROM lista_espera_curso WHERE curso_id = ?";
        $stmtPosicao = $this->database->prepare($sqlPosicao);
        $stmtPosicao->execute([$cursoId]);
        $resPosicao = $stmtPosicao->fetch(PDO::FETCH_ASSOC);
        
        $proximaPosicao = ($resPosicao['proxima'] ?? 0) + 1;
        
        // Inserir na lista de espera
        $sql = "INSERT INTO lista_espera_curso (utilizador_id, curso_id, posicao, data_inscricao) 
                VALUES (?, ?, ?, NOW())";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$utilizadorId, $cursoId, $proximaPosicao]);
    }

    /**
     * Obter posição na lista de espera de um curso
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @return int|null Posição ou null se não estiver
     */
    public function getPosicaoListaEsperaCurso($utilizadorId, $cursoId)
    {
        $sql = "SELECT posicao FROM lista_espera_curso 
                WHERE utilizador_id = ? AND curso_id = ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId, $cursoId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['posicao'] : null;
    }

    /**
     * Obter lista de espera de um curso
     * 
     * @param int $cursoId ID do curso
     * @param int $limite Limite de registos
     * @return array
     */
    public function getListaEsperaCurso($cursoId, $limite = 50)
    {
        $sql = "SELECT le.*, u.nome, u.email, u.telefone
                FROM lista_espera_curso le
                JOIN utilizadores u ON le.utilizador_id = u.id
                WHERE le.curso_id = ?
                ORDER BY le.posicao ASC
                LIMIT ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$cursoId, $limite]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obter cursos em lista de espera para um aluno
     * 
     * @param int $utilizadorId ID do utilizador
     * @return array
     */
    public function getCursosEmEspera($utilizadorId)
    {
        $sql = "SELECT le.*, c.titulo, c.descricao, c.duracao, c.vagas_disponibilidade, c.total_inscritos
                FROM lista_espera_curso le
                JOIN cursos c ON le.curso_id = c.id
                WHERE le.utilizador_id = ?
                ORDER BY le.posicao ASC";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Remover aluno da lista de espera de um curso
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @return bool
     */
    public function removerDaListaEsperaCurso($utilizadorId, $cursoId)
    {
        $sql = "DELETE FROM lista_espera_curso 
                WHERE utilizador_id = ? AND curso_id = ?";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$utilizadorId, $cursoId]);
    }

    /**
     * Promover primeiro da lista de espera (vaga disponível)
     * 
     * @param int $cursoId ID do curso
     * @return array|null Utilizador promovido
     */
    public function promoverDaListaEsperaCurso($cursoId)
    {
        // Obter primeiro da fila
        $sqlPrimeiro = "SELECT le.*, u.email, u.nome FROM lista_espera_curso le
                       JOIN utilizadores u ON le.utilizador_id = u.id
                       WHERE le.curso_id = ? AND le.posicao = 1
                       LIMIT 1";
        
        $stmtPrimeiro = $this->database->prepare($sqlPrimeiro);
        $stmtPrimeiro->execute([$cursoId]);
        $primeiro = $stmtPrimeiro->fetch(PDO::FETCH_ASSOC);
        
        if (!$primeiro) {
            return null;
        }
        
        // Marcar como notificado
        $sqlNotifica = "UPDATE lista_espera_curso 
                       SET notificado = 1, data_notificacao = NOW() 
                       WHERE id = ?";
        
        $stmtNotifica = $this->database->prepare($sqlNotifica);
        $stmtNotifica->execute([$primeiro['id']]);
        
        // Reorganizar posições restantes
        $sqlReorganiza = "UPDATE lista_espera_curso 
                         SET posicao = posicao - 1 
                         WHERE curso_id = ? AND posicao > 1";
        
        $stmtReorganiza = $this->database->prepare($sqlReorganiza);
        $stmtReorganiza->execute([$cursoId]);
        
        return $primeiro;
    }

    /**
     * ========== MÉTODOS PARA ESTÁGIOS ==========
     */

    /**
     * Adicionar candidadura à lista de espera de um estágio
     * 
     * @param int $candidaturaId ID da candidatura
     * @param int $estagioId ID do estágio
     * @return bool
     */
    public function adicionarAListaEsperaEstagio($candidaturaId, $estagioId)
    {
        // Verificar se já está na lista
        $sqlVerifica = "SELECT COUNT(*) as total FROM lista_espera_estagio 
                       WHERE candidatura_id = ? AND estagio_id = ?";
        
        $stmtVerifica = $this->database->prepare($sqlVerifica);
        $stmtVerifica->execute([$candidaturaId, $estagioId]);
        $result = $stmtVerifica->fetch(PDO::FETCH_ASSOC);
        
        if ($result['total'] > 0) {
            return false;
        }
        
        // Obter próxima posição
        $sqlPosicao = "SELECT MAX(posicao) as proxima FROM lista_espera_estagio WHERE estagio_id = ?";
        $stmtPosicao = $this->database->prepare($sqlPosicao);
        $stmtPosicao->execute([$estagioId]);
        $resPosicao = $stmtPosicao->fetch(PDO::FETCH_ASSOC);
        
        $proximaPosicao = ($resPosicao['proxima'] ?? 0) + 1;
        
        // Inserir na lista de espera
        $sql = "INSERT INTO lista_espera_estagio (candidatura_id, estagio_id, posicao, data_inscricao) 
                VALUES (?, ?, ?, NOW())";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$candidaturaId, $estagioId, $proximaPosicao]);
    }

    /**
     * Obter posição na lista de espera de um estágio
     * 
     * @param int $candidaturaId ID da candidatura
     * @param int $estagioId ID do estágio
     * @return int|null Posição ou null
     */
    public function getPosicaoListaEsperaEstagio($candidaturaId, $estagioId)
    {
        $sql = "SELECT posicao FROM lista_espera_estagio 
                WHERE candidatura_id = ? AND estagio_id = ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$candidaturaId, $estagioId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['posicao'] : null;
    }

    /**
     * Obter lista de espera de um estágio
     * 
     * @param int $estagioId ID do estágio
     * @return array
     */
    public function getListaEsperaEstagio($estagioId)
    {
        $sql = "SELECT le.*, c.utilizador_id, u.nome, u.email
                FROM lista_espera_estagio le
                JOIN candidaturas c ON le.candidatura_id = c.id
                JOIN utilizadores u ON c.utilizador_id = u.id
                WHERE le.estagio_id = ?
                ORDER BY le.posicao ASC";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$estagioId]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Remover candidatura da lista de espera de um estágio
     * 
     * @param int $candidaturaId ID da candidatura
     * @param int $estagioId ID do estágio
     * @return bool
     */
    public function removerDaListaEsperaEstagio($candidaturaId, $estagioId)
    {
        $sql = "DELETE FROM lista_espera_estagio 
                WHERE candidatura_id = ? AND estagio_id = ?";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$candidaturaId, $estagioId]);
    }

    /**
     * Contar posições na lista de espera
     * 
     * @param int $estagioId ID do estágio
     * @return int
     */
    public function contarListaEsperaEstagio($estagioId)
    {
        $sql = "SELECT COUNT(*) as total FROM lista_espera_estagio WHERE estagio_id = ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$estagioId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }
}
