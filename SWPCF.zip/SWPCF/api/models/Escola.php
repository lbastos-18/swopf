<?php

class Escola extends BaseModel
{
    protected $table = 'escolas';
    protected $fillable = ['nome', 'responsavel', 'email', 'telefone', 'documento_parceria', 'status', 'observacoes', 'criado_por'];

    public function getActive()
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE status = 'ativa'
                ORDER BY nome ASC";
        return $this->db->fetchAll($sql);
    }

    public function getByStatus($status)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE status = ?
                ORDER BY data_registo DESC";
        return $this->db->fetchAll($sql, [$status]);
    }

    public function getWithEstagios($id = null)
    {
        $sql = "SELECT e.*, COUNT(est.id) as total_estagios
                FROM {$this->table} e
                LEFT JOIN estagios est ON e.id = est.escola_restrita_id
                WHERE 1=1";

        if ($id) {
            $sql .= " AND e.id = ?";
            $result = $this->db->fetch($sql, [$id]);
            return $result;
        }

        $sql .= " GROUP BY e.id ORDER BY e.nome ASC";
        return $this->db->fetchAll($sql);
    }

    public function countEstagios($escola_id)
    {
        $sql = "SELECT COUNT(*) as total FROM estagios 
                WHERE escola_restrita_id = ? AND status = 'ativo'";
        $result = $this->db->fetch($sql, [$escola_id]);
        return $result['total'] ?? 0;
    }

    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_escolas,
                    SUM(CASE WHEN status = 'ativa' THEN 1 ELSE 0 END) as escolas_ativas,
                    SUM(CASE WHEN status = 'suspensa' THEN 1 ELSE 0 END) as escolas_suspensas,
                    SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as escolas_pendentes
                FROM {$this->table}";

        return $this->db->fetch($sql);
    }
}
