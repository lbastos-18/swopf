<?php

class Documento extends BaseModel
{
    protected $table = 'documentos';
    protected $fillable = ['candidatura_id', 'tipo', 'caminho_arquivo', 'nome_original', 'status_validacao', 'observacao_admin', 'validado_por'];

    public function getByCandidatura($candidatura_id)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE candidatura_id = ?
                ORDER BY data_upload DESC";
        return $this->db->fetchAll($sql, [$candidatura_id]);
    }

    public function getRequiredDocuments($candidatura_id)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE candidatura_id = ? AND tipo IN ('bi', 'comprovativo')
                ORDER BY tipo ASC";
        return $this->db->fetchAll($sql, [$candidatura_id]);
    }

    public function allDocumentsApproved($candidatura_id)
    {
        $sql = "SELECT COUNT(*) as total FROM {$this->table} 
                WHERE candidatura_id = ? AND tipo IN ('bi', 'comprovativo') AND status_validacao != 'aprovado'";
        $result = $this->db->fetch($sql, [$candidatura_id]);
        return $result['total'] === 0;
    }

    public function getByStatus($status)
    {
        $sql = "SELECT d.*, ca.id as candidatura_id, c.utilizador_id, u.nome, u.email
                FROM {$this->table} d
                INNER JOIN candidaturas ca ON d.candidatura_id = ca.id
                INNER JOIN candidatos c ON ca.candidato_id = c.id
                INNER JOIN utilizadores u ON c.utilizador_id = u.id
                WHERE d.status_validacao = ?
                ORDER BY d.data_upload DESC";
        return $this->db->fetchAll($sql, [$status]);
    }

    public function getPendingDocuments()
    {
        $sql = "SELECT d.*, ca.id as candidatura_id, c.utilizador_id, u.nome, u.email, 
                       est.titulo as estagio_titulo
                FROM {$this->table} d
                INNER JOIN candidaturas ca ON d.candidatura_id = ca.id
                INNER JOIN candidatos c ON ca.candidato_id = c.id
                INNER JOIN utilizadores u ON c.utilizador_id = u.id
                INNER JOIN estagios est ON ca.estagio_id = est.id
                WHERE d.status_validacao = 'pendente'
                ORDER BY d.data_upload ASC";
        return $this->db->fetchAll($sql);
    }

    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_documentos,
                    SUM(CASE WHEN status_validacao = 'pendente' THEN 1 ELSE 0 END) as pendentes,
                    SUM(CASE WHEN status_validacao = 'aprovado' THEN 1 ELSE 0 END) as aprovados,
                    SUM(CASE WHEN status_validacao = 'rejeitado' THEN 1 ELSE 0 END) as rejeitados
                FROM {$this->table}";

        return $this->db->fetch($sql);
    }

    public function validate($documento_id, $aprovado, $observacao = null, $validado_por)
    {
        $status = $aprovado ? 'aprovado' : 'rejeitado';
        
        $sql = "UPDATE {$this->table} 
                SET status_validacao = ?, 
                    observacao_admin = ?,
                    validado_por = ?,
                    data_validacao = NOW()
                WHERE id = ?";
        
        return $this->db->query($sql, [$status, $observacao, $validado_por, $documento_id]);
    }
}
