<?php
/**
 * Model: Vaga
 */

class Vaga extends BaseModel
{
    protected $table = 'vagas';
    protected $fillable = ['titulo', 'descricao', 'empresa', 'localizacao', 'tipo_contracto', 'salario_minimo', 'salario_maximo', 'numero_vagas', 'competencias_requeridas', 'beneficios', 'data_encerramento', 'curso_relacionado_id', 'ativo'];

    /**
     * Buscar vagas com curso relacionado
     */
    public function withCurso($id = null)
    {
        $sql = "SELECT v.*, c.titulo as curso_titulo
                FROM {$this->table} v
                LEFT JOIN cursos c ON v.curso_relacionado_id = c.id";

        if ($id) {
            $sql .= " WHERE v.id = ?";
            return $this->db->fetch($sql, [$id]);
        }

        $sql .= " ORDER BY v.data_publicacao DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar vagas abertas
     */
    public function getOpen()
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE ativo = 1 AND (data_encerramento IS NULL OR data_encerramento >= CURDATE())
                ORDER BY data_publicacao DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Buscar vagas por empresa
     */
    public function getByCompany($empresa)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE empresa = ? AND ativo = 1
                ORDER BY data_publicacao DESC";
        return $this->db->fetchAll($sql, [$empresa]);
    }

    /**
     * Buscar vagas por localização
     */
    public function getByLocation($localizacao)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE localizacao = ? AND ativo = 1
                ORDER BY data_publicacao DESC";
        return $this->db->fetchAll($sql, [$localizacao]);
    }

    /**
     * Buscar vagas por tipo de contrato
     */
    public function getByType($tipo_contracto)
    {
        $sql = "SELECT * FROM {$this->table} 
                WHERE tipo_contracto = ? AND ativo = 1
                ORDER BY data_publicacao DESC";
        return $this->db->fetchAll($sql, [$tipo_contracto]);
    }

    /**
     * Contar candidaturas para vaga
     */
    public function countCandidaturas($vaga_id)
    {
        $sql = "SELECT COUNT(*) as total FROM candidaturas 
                WHERE vaga_id = ?";
        $result = $this->db->fetch($sql, [$vaga_id]);
        return $result['total'] ?? 0;
    }

    /**
     * Obter vagas por status de candidatura
     */
    public function getCandidaturasByStatus($status)
    {
        $sql = "SELECT v.*, COUNT(ca.id) as total_candidaturas
                FROM {$this->table} v
                LEFT JOIN candidaturas ca ON v.id = ca.vaga_id AND ca.status = ?
                WHERE v.ativo = 1
                GROUP BY v.id
                ORDER BY v.data_publicacao DESC";
        return $this->db->fetchAll($sql, [$status]);
    }

    /**
     * Obter estatísticas gerais de vagas
     */
    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_vagas,
                    SUM(numero_vagas) as total_posicoes,
                    COUNT(DISTINCT empresa) as empresas_unicas,
                    (SELECT COUNT(*) FROM candidaturas) as total_candidaturas,
                    AVG(salario_maximo) as salario_medio
                FROM {$this->table}
                WHERE ativo = 1 AND (data_encerramento IS NULL OR data_encerramento >= CURDATE())";

        return $this->db->fetch($sql);
    }
}
