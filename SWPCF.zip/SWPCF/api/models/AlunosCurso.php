<?php

/**
 * Model: AlunosCurso
 * Gerencia o histórico de cursos dos alunos
 */

class AlunosCurso extends BaseModel
{
    protected $table = 'aluno_curso';
    protected $fillable = ['utilizador_id', 'curso_id', 'status', 'data_conclusao', 'nota_final', 'certificado_url'];

    /**
     * Obter cursos de um aluno por status
     * 
     * @param int $utilizadorId ID do utilizador
     * @param string $status Status do curso (guardado, em_progresso, completado)
     * @return array
     */
    public function getByUserAndStatus($utilizadorId, $status = null)
    {
        $sql = "SELECT ac.*, c.titulo, c.descricao, c.duracao, c.criador_id, u.nome as criador_nome
                FROM aluno_curso ac
                JOIN cursos c ON ac.curso_id = c.id
                LEFT JOIN utilizadores u ON c.criador_id = u.id
                WHERE ac.utilizador_id = ?";
        
        $params = [$utilizadorId];
        
        if ($status) {
            $sql .= " AND ac.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY ac.data_inscricao DESC";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Contar cursos completados
     * 
     * @param int $utilizadorId ID do utilizador
     * @return int
     */
    public function countCompletados($utilizadorId)
    {
        $sql = "SELECT COUNT(*) as total FROM aluno_curso 
                WHERE utilizador_id = ? AND status = 'completado'";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }

    /**
     * Contar cursos em progresso
     * 
     * @param int $utilizadorId ID do utilizador
     * @return int
     */
    public function countEmProgresso($utilizadorId)
    {
        $sql = "SELECT COUNT(*) as total FROM aluno_curso 
                WHERE utilizador_id = ? AND status = 'em_progresso'";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }

    /**
     * Contar cursos guardados
     * 
     * @param int $utilizadorId ID do utilizador
     * @return int
     */
    public function countGuardados($utilizadorId)
    {
        $sql = "SELECT COUNT(*) as total FROM aluno_curso 
                WHERE utilizador_id = ? AND status = 'guardado'";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }

    /**
     * Verificar se aluno já está inscrito num curso
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @return bool
     */
    public function estaInscrito($utilizadorId, $cursoId)
    {
        $sql = "SELECT COUNT(*) as total FROM aluno_curso 
                WHERE utilizador_id = ? AND curso_id = ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId, $cursoId]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return isset($result['total']) && $result['total'] > 0;
    }

    /**
     * Adicionar curso ao aluno (guardado)
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @param string $status Status inicial
     * @return bool
     */
    public function adicionarCurso($utilizadorId, $cursoId, $status = 'em_progresso')
    {
        // Verificar se já existe
        if ($this->estaInscrito($utilizadorId, $cursoId)) {
            return false;
        }
        
        $sql = "INSERT INTO aluno_curso (utilizador_id, curso_id, status, data_inscricao) 
                VALUES (?, ?, ?, NOW())";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$utilizadorId, $cursoId, $status]);
    }

    /**
     * Atualizar status do curso
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @param string $novoStatus Novo status
     * @return bool
     */
    public function atualizarStatus($utilizadorId, $cursoId, $novoStatus)
    {
        $statusValidos = ['guardado', 'em_progresso', 'completado'];
        
        if (!in_array($novoStatus, $statusValidos)) {
            return false;
        }
        
        $sql = "UPDATE aluno_curso 
                SET status = ?, actualizado_em = NOW()";
        
        $params = [$novoStatus];
        
        // Se concluído, registar data de conclusão
        if ($novoStatus === 'completado') {
            $sql = "UPDATE aluno_curso 
                    SET status = ?, data_conclusao = NOW(), actualizado_em = NOW()";
        }
        
        $sql .= " WHERE utilizador_id = ? AND curso_id = ?";
        $params[] = $utilizadorId;
        $params[] = $cursoId;
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Remover curso (guardado ou cancelar inscrição)
     * 
     * @param int $utilizadorId ID do utilizador
     * @param int $cursoId ID do curso
     * @return bool
     */
    public function removerCurso($utilizadorId, $cursoId)
    {
        $sql = "DELETE FROM aluno_curso 
                WHERE utilizador_id = ? AND curso_id = ? AND status IN ('guardado', 'em_progresso')";
        
        $stmt = $this->database->prepare($sql);
        return $stmt->execute([$utilizadorId, $cursoId]);
    }

    /**
     * Obter estatísticas do aluno
     * 
     * @param int $utilizadorId ID do utilizador
     * @return array
     */
    public function getEstatisticas($utilizadorId)
    {
        $sql = "SELECT 
                    COUNT(*) as total_inscrito,
                    SUM(CASE WHEN status = 'completado' THEN 1 ELSE 0 END) as completados,
                    SUM(CASE WHEN status = 'em_progresso' THEN 1 ELSE 0 END) as em_progresso,
                    SUM(CASE WHEN status = 'guardado' THEN 1 ELSE 0 END) as guardados,
                    AVG(CASE WHEN nota_final IS NOT NULL THEN nota_final ELSE NULL END) as media_notas
                FROM aluno_curso
                WHERE utilizador_id = ?";
        
        $stmt = $this->database->prepare($sql);
        $stmt->execute([$utilizadorId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }
}
