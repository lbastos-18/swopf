<?php

class Candidatura extends BaseModel
{
    protected $table = 'candidaturas';
    protected $fillable = ['estagio_id', 'candidato_id', 'nota_pessoal', 'resumo_candidato', 'status', 'observacoes_admin'];

    public function withRelations($id = null)
    {
        $sql = "SELECT ca.*, 
                    e.titulo as estagio_titulo, e.tipo, e.bolsa_remuneracao,
                    cand.id as candidato_id_pk, u.nome as candidato_nome, u.email as candidato_email
                FROM {$this->table} ca
                INNER JOIN estagios e ON ca.estagio_id = e.id
                INNER JOIN candidatos cand ON ca.candidato_id = cand.id
                INNER JOIN utilizadores u ON cand.utilizador_id = u.id";

        if ($id) {
            $sql .= " WHERE ca.id = ?";
            return $this->db->fetch($sql, [$id]);
        }

        $sql .= " ORDER BY ca.data_candidatura DESC";
        return $this->db->fetchAll($sql);
    }

    public function candidatureExists($estagio_id, $candidato_id)
    {
        $sql = "SELECT id FROM {$this->table} 
                WHERE estagio_id = ? AND candidato_id = ?";
        return $this->db->fetch($sql, [$estagio_id, $candidato_id]) !== false;
    }

    public function getByEstagio($estagio_id, $status = null)
    {
        $sql = "SELECT ca.*, u.nome as candidato_nome, u.email
                FROM {$this->table} ca
                INNER JOIN candidatos cand ON ca.candidato_id = cand.id
                INNER JOIN utilizadores u ON cand.utilizador_id = u.id
                WHERE ca.estagio_id = ?";

        $params = [$estagio_id];

        if ($status) {
            $sql .= " AND ca.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY ca.data_candidatura DESC";
        return $this->db->fetchAll($sql, $params);
    }

    public function getByCandidate($candidato_id, $status = null)
    {
        $sql = "SELECT ca.*, e.titulo as estagio_titulo, e.tipo, e.bolsa_remuneracao
                FROM {$this->table} ca
                INNER JOIN estagios e ON ca.estagio_id = e.id
                WHERE ca.candidato_id = ?";

        $params = [$candidato_id];

        if ($status) {
            $sql .= " AND ca.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY ca.data_candidatura DESC";
        return $this->db->fetchAll($sql, $params);
    }

    public function getByStatus($status)
    {
        $sql = "SELECT ca.*, e.titulo as estagio_titulo, u.nome as candidato_nome
                FROM {$this->table} ca
                INNER JOIN estagios e ON ca.estagio_id = e.id
                INNER JOIN candidatos cand ON ca.candidato_id = cand.id
                INNER JOIN utilizadores u ON cand.utilizador_id = u.id
                WHERE ca.status = ?
                ORDER BY ca.data_candidatura DESC";
        return $this->db->fetchAll($sql, [$status]);
    }

    public function countByStatus()
    {
        $sql = "SELECT status, COUNT(*) as total 
                FROM {$this->table}
                GROUP BY status";
        return $this->db->fetchAll($sql);
    }

    public function getStats()
    {
        $sql = "SELECT 
                    COUNT(*) as total_candidaturas,
                    SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendentes,
                    SUM(CASE WHEN status = 'em_analise_documentos' THEN 1 ELSE 0 END) as em_analise_docs,
                    SUM(CASE WHEN status = 'documentos_aprovados' THEN 1 ELSE 0 END) as docs_aprovados,
                    SUM(CASE WHEN status = 'aprovado' THEN 1 ELSE 0 END) as aprovadas,
                    SUM(CASE WHEN status = 'rejeitado' THEN 1 ELSE 0 END) as rejeitadas
                FROM {$this->table}";

        return $this->db->fetch($sql);
    }

    public function getCandidaturaWithDocuments($candidatura_id)
    {
        $candidatura = $this->withRelations($candidatura_id);
        
        $documento = new Documento();
        $candidatura['documentos'] = $documento->getByCandidatura($candidatura_id);
        
        return $candidatura;
    }
}
