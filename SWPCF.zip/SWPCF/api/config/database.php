<?php
/**
 * Database configuration and singleton wrapper for PDO.
 *
 * This file defines default constants and provides a simple
 * Database class with a singleton connection. Environment variables
 * (e.g. from a .env file) may override the defaults.
 */

// load .env if present (basic key=value parsing)
$envFile = dirname(__DIR__, 2) . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        if (!defined($key)) {
            define($key, $value);
        }
    }
}

// Default configuration (can be overridden by environment)
defined('DB_HOST')        or define('DB_HOST', 'localhost');
defined('DB_USER')        or define('DB_USER', 'root');
defined('DB_PASS')        or define('DB_PASS', '');
defined('DB_NAME')        or define('DB_NAME', 'swpcf');
defined('DB_CHARSET')     or define('DB_CHARSET', 'utf8mb4');

// URLs and paths
defined('BASE_URL')       or define('BASE_URL', 'http://localhost/SWPCF');
defined('API_URL')        or define('API_URL', BASE_URL . '/api');
defined('UPLOADS_DIR')    or define('UPLOADS_DIR', dirname(__DIR__) . '/uploads');
defined('UPLOADS_URL')    or define('UPLOADS_URL', BASE_URL . '/uploads');

// Security / tokens
defined('JWT_SECRET')     or define('JWT_SECRET', 'change_me_in_production');
defined('JWT_ALGORITHM')  or define('JWT_ALGORITHM', 'HS256');
defined('TOKEN_EXPIRY')   or define('TOKEN_EXPIRY', 86400); // 24h

// Session settings
defined('SESSION_LIFETIME') or define('SESSION_LIFETIME', 3600);
defined('SESSION_COOKIE_HTTPONLY') or define('SESSION_COOKIE_HTTPONLY', true);
defined('SESSION_COOKIE_SECURE') or define('SESSION_COOKIE_SECURE', false);

// Timezone
date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'Europe/Lisbon');

// Error reporting (override in production)
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// CORS defaults
defined('ALLOWED_ORIGINS') or define('ALLOWED_ORIGINS', ['http://127.0.0.1:8001', 'http://localhost']);
defined('ALLOWED_METHODS') or define('ALLOWED_METHODS', ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']);

// ---------------------------------------------------------------------------
// PDO database singleton
// ---------------------------------------------------------------------------
class Database
{
    private static ?Database $instance = null;
    private ?\PDO $connection = null;
    private ?string $last_error = null;
    private ?string $last_query = null;

    private function __construct()
    {
        $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
        try {
            $this->connection = new \PDO(
                $dsn,
                DB_USER,
                DB_PASS,
                [
                    \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                    \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                    \PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (\PDOException $e) {
            $this->last_error = $e->getMessage();
            throw new \Exception('Erro na conexão com a base de dados: ' . $e->getMessage());
        }
    }

    // Prevent cloning and unserialization
    private function __clone() {}
    public function __wakeup()
    {
        throw new \Exception('Cannot unserialize singleton');
    }

    /**
     * Get singleton instance
     *
     * @return Database
     */
    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection(): ?\PDO
    {
        return $this->connection;
    }

    public function query(string $sql, array $params = []): ?\PDOStatement
    {
        try {
            $stmt = $this->connection->prepare($sql);
            $this->last_query = $sql;
            $stmt->execute($params);
            return $stmt;
        } catch (\PDOException $e) {
            $this->last_error = $e->getMessage();
            throw $e;
        }
    }

    public function fetch(string $sql, array $params = []): ?array
    {
        return $this->query($sql, $params)?->fetch();
    }

    public function fetchAll(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)?->fetchAll() ?? [];
    }

    public function insert(string $sql, array $params = []): bool
    {
        return (bool)$this->query($sql, $params);
    }

    public function lastInsertId(): string
    {
        return $this->connection->lastInsertId();
    }

    public function lastError(): ?string
    {
        return $this->last_error;
    }

    public function lastQuery(): ?string
    {
        return $this->last_query;
    }
}
