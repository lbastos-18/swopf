# 🚀 Como Usar - Rápido e Fácil

## Passo 1: Copiar para XAMPP
```bash
# No macOS
cp -r SWPCF /Applications/XAMPP/xamppfiles/htdocs/
```

## Passo 2: Iniciar XAMPP
1. Abrir **XAMPP Control Panel**
2. Clique em **"Start"** ao lado de:
   - Apache
   - MySQL

## Passo 3: Criar Banco de Dados
1. Abrir http://localhost/phpmyadmin
2. Clicar em **"Import"** no menu superior
3. Clique em **"Choose File"** e selecionar `database.sql` (arquivo na raiz da pasta SWPCF)
4. Clicar em **"Import"** (vai criar a BD automaticamente)

## Passo 4: Pronto! 🎉
Agora aceda a:
- **Admin**: http://localhost/SWPCF/admin
- **Público**: http://localhost/SWPCF/

## Login Admin Padrão
```
Email: admin@swpcf.local
Senha: admin123
```

---

## O que está Incluído

✅ **Login/Logout** - Autenticação completa  
✅ **Dashboard Admin** - Painel de controle  
✅ **CRUD Cursos** - Adicionar, editar, deletar, listar  
✅ **CRUD Estágios** - Gerenciar estágios  
✅ **CRUD Vagas/Formações** - Gerenciar vagas de estágio / formações  
✅ **CRUD Candidatos** - Gerenciar candidaturas  
✅ **Página Pública** - Visualizar estágios e formações  
✅ **Banco MySQL** - Com dados de teste  
✅ **100% XAMPP Compatível**

---

## Estrutura de Pastas

```
SWPCF/
├── config.php              ← Configuração (sem mudanças necessárias!)
├── database.sql            ← Importar no phpmyadmin
├── index.php               ← Router principal
├── admin/                  ← Páginas admin
│   ├── index.html
│   ├── dashboard.html
│   ├── cursos-lista.html
│   ├── estagios-lista.html
│   ├── vagas-lista.html
│   └── candidatos-lista.html
├── public/                 ← Páginas públicas
│   ├── index.html
│   ├── formacoes.html
│   ├── estagios.html
│   └── sobre.html
├── api/                    ← API REST
└── assets/                 ← CSS e JS
```

---

## Troubleshooting

**Erro de Banco de Dados?**
- Verifique se MySQL está ativo no XAMPP
- Vá para phpmyadmin e importe o `database.sql`

**Página em branco?**
- Verifique o Apache no XAMPP
- Abra http://localhost/XAMPP/ para confirmar

**Login não funciona?**
- Use email: `admin@swpcf.local` 
- Use senha: `admin123`

---

💡 **Tudo pronto! Apresentação 100% funcional!**

