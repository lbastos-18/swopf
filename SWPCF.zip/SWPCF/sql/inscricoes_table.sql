-- Tabela: inscricoes
CREATE TABLE IF NOT EXISTS `inscricoes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `curso_id` int unsigned NOT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `documento` varchar(100) NOT NULL,
  `doc_copy` varchar(512) DEFAULT NULL,
  `payment_proof` varchar(512) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_curso` (`curso_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
