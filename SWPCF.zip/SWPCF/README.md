# Projeto de Estágio - SWPCF

Sistema simples de gerenciamento de candidaturas com Login, Dashboard Admin e CRUD.

## 🚀 Requisitos

- PHP 7.4+
- MySQL
- XAMPP (recomendado)

## 📦 Instalação

### 1. Copiar para XAMPP
```bash
cp -r SWPCF /Applications/XAMPP/xamppfiles/htdocs/
```

### 2. Criar Banco de Dados
```sql
CREATE DATABASE swpcf;
USE swpcf;
-- Ver arquivo config.php para estrutura das tabelas
```

### 3. Configurar config.php
Editar as credenciais do banco de dados em `config.php`

## 🎯 Funcionalidades

- ✅ **Login/Logout** - Autenticação simples
- ✅ **Dashboard Admin** - Painel de controle
- ✅ **Gerenciar Cursos** - CRUD de cursos
- ✅ **Gerenciar Estágios** - CRUD de estágios
- ✅ **Gerenciar Vagas** - CRUD de vagas
- ✅ **Página Pública** - Visualização de estágios

## 📂 Estrutura

```
SWPCF/
├── index.php           # Router principal
├── config.php          # Configuração BD
├── admin/              # Páginas do admin
├── public/             # Páginas públicas
├── api/                # API REST
├── includes/           # Includes PHP
└── assets/             # CSS, JS, Imagens
```

## 🔐 Acesso

**Admin:** http://localhost/SWPCF/admin
**Público:** http://localhost/SWPCF/

## 💡 Nota

Este projeto foi simplificado para facilitar apresentação e explicação durante o estágio.
