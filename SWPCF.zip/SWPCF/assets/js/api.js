/**
 * API.JS - Cliente HTTP para chamadas à API SWPCF
 * Encapsula chamadas AJAX/Fetch com tratamento de erros
 */

class ApiClient {
  constructor(baseUrl = 'http://127.0.0.1:8001') {
    this.baseUrl = baseUrl;
    this.timeout = 10000; // 10 segundos
  }

  /**
   * GET request
   */
  async get(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'GET' });
  }

  /**
   * POST request
   */
  async post(endpoint, data = {}, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  /**
   * PUT request
   */
  async put(endpoint, data = {}, options = {}) {
    return this.request(endpoint, {
      ...options,
      method: 'PUT',
      body: JSON.stringify(data)
    });
  }

  /**
   * DELETE request
   */
  async delete(endpoint, options = {}) {
    return this.request(endpoint, { ...options, method: 'DELETE' });
  }

  /**
   * Requisição genérica
   */
  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}/api/${endpoint}`;
    
    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    // Adicionar token de autenticação se disponível
    if (window.auth && window.auth.getToken()) {
      defaultHeaders['Authorization'] = `Bearer ${window.auth.getToken()}`;
    }

    const config = {
      headers: { ...defaultHeaders, ...options.headers },
      method: options.method || 'GET',
      timeout: options.timeout || this.timeout
    };

    if (options.body) {
      config.body = options.body;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), config.timeout);

      const response = await fetch(url, {
        ...config,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      // Tentar fazer parse JSON
      let data;
      try {
        data = await response.json();
      } catch (e) {
        data = null;
      }

      // Se erro HTTP
      if (!response.ok) {
        const error = new Error(data?.message || `HTTP ${response.status}`);
        error.status = response.status;
        error.data = data;
        throw error;
      }

      return {
        success: true,
        status: response.status,
        data: data
      };

    } catch (error) {
      if (error.name === 'AbortError') {
        console.error(`[API] Timeout em ${endpoint}`);
        return {
          success: false,
          error: 'Timeout: Servidor demorou muito a responder',
          status: 0
        };
      }

      console.error(`[API] Erro em ${endpoint}:`, error);
      return {
        success: false,
        error: error.message || 'Erro na requisição',
        status: error.status || 0,
        data: error.data
      };
    }
  }

  /**
   * Endpoints específicos
   */

  // HEALTH CHECK
  async health() {
    return this.get('');
  }

  // UTILIZADORES
  async loginUser(email, password) {
    return this.post('utilizadores/login', { email, password });
  }

  async registerUser(userData) {
    return this.post('utilizadores/registo', userData);
  }

  async getProfile() {
    return this.get('utilizadores/perfil');
  }

  async updateProfile(userData) {
    return this.put('utilizadores/perfil', userData);
  }

  // CANDIDATOS
  async getCandidatos(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.get(`candidatos${params ? '?' + params : ''}`);
  }

  async getCandidato(id) {
    return this.get(`candidatos/${id}`);
  }

  async createCandidato(data) {
    return this.post('candidatos', data);
  }

  async updateCandidato(id, data) {
    return this.put(`candidatos/${id}`, data);
  }

  async deleteCandidato(id) {
    return this.delete(`candidatos/${id}`);
  }

  // ESTÁGIOS
  async getEstagios(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.get(`estagios${params ? '?' + params : ''}`);
  }

  async getEstagio(id) {
    return this.get(`estagios/${id}`);
  }

  async createEstagio(data) {
    return this.post('estagios', data);
  }

  async updateEstagio(id, data) {
    return this.put(`estagios/${id}`, data);
  }

  async deleteEstagio(id) {
    return this.delete(`estagios/${id}`);
  }

  // CANDIDATURAS
  async getCandidaturas(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.get(`candidaturas${params ? '?' + params : ''}`);
  }

  async getCandidatura(id) {
    return this.get(`candidaturas/${id}`);
  }

  async createCandidatura(data) {
    return this.post('candidaturas', data);
  }

  async updateCandidatura(id, data) {
    return this.put(`candidaturas/${id}`, data);
  }

  async deleteCandidatura(id) {
    return this.delete(`candidaturas/${id}`);
  }

  // CURSOS
  async getCursos(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.get(`cursos${params ? '?' + params : ''}`);
  }

  async getCurso(id) {
    return this.get(`cursos/${id}`);
  }

  async createCurso(data) {
    return this.post('cursos', data);
  }

  async updateCurso(id, data) {
    return this.put(`cursos/${id}`, data);
  }

  async deleteCurso(id) {
    return this.delete(`cursos/${id}`);
  }

  // ADMINS
  async getAdmins(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.get(`admins${params ? '?' + params : ''}`);
  }

  async getAdmin(id) {
    return this.get(`admins/${id}`);
  }

  async createAdmin(data) {
    return this.post('admins', data);
  }

  async updateAdmin(id, data) {
    return this.put(`admins/${id}`, data);
  }

  async deleteAdmin(id) {
    return this.delete(`admins/${id}`);
  }

  // DOCUMENTOS
  async getDocumentos(filters = {}) {
    const params = new URLSearchParams(filters).toString();
    return this.get(`documentos${params ? '?' + params : ''}`);
  }

  async getDocumento(id) {
    return this.get(`documentos/${id}`);
  }

  async validateDocumento(id, status) {
    return this.put(`documentos/${id}/validar`, { status });
  }

  // NOTIFICAÇÕES
  async getNotificacoes() {
    return this.get('notificacoes');
  }

  async markNotificationAsRead(id) {
    return this.put(`notificacoes/${id}/lida`, {});
  }

  // RELATÓRIOS
  async getRelatorio(tipo) {
    return this.get(`relatorios/${tipo}`);
  }
}

// Criar instância global
window.api = new ApiClient();

// Log de debug
console.log('[API] Cliente API inicializado');
console.log('[API] Base URL:', window.api.baseUrl);

// Testar conexão com health check
window.api.health().then(response => {
  if (response.success) {
    console.log('[API] ✓ Servidor está online');
  } else {
    console.warn('[API] ✗ Servidor offline:', response.error);
  }
});
