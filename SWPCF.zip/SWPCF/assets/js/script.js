
const submenuItems = document.querySelectorAll('.has-submenu');

submenuItems.forEach(item => {
    item.addEventListener('click', () => {
      
        submenuItems.forEach(i => {
            if (i !== item) i.classList.remove('open');
            i.querySelector('.submenu').style.display = 'none';
        });

  
        const submenu = item.querySelector('.submenu');
        if (item.classList.contains('open')) {
            submenu.style.display = 'none';
            item.classList.remove('open');
        } else {
            submenu.style.display = 'block';
            item.classList.add('open');
        }
    });
});
