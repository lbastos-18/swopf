/**
 * Script - Página de Vagas
 */

let vagasData = [];
let filtrosAtivos = {};
let paginaAtual = 1;

document.addEventListener('DOMContentLoaded', async () => {
    setupFiltros();
    await carregarVagas();
    setupSearchBusca();
});

/**
 * Carregar vagas da API
 */
async function carregarVagas(pagina = 1) {
    try {
        const offset = (pagina - 1) * 20;
        const params = {
            limit: 20,
            offset: offset,
            ...filtrosAtivos
        };

        showLoading(true);
        const response = await api.getVagas(params);
        
        vagasData = response.data.vagas || [];
        renderizarVagas(vagasData);
        renderizarPaginacao(response.data.total);
        
        paginaAtual = pagina;
        showLoading(false);
    } catch (error) {
        showAlert('Erro ao carregar vagas: ' + error.message, 'danger');
        showLoading(false);
    }
}

/**
 * Setup de filtros
 */
function setupFiltros() {
    // Filtros checkbox
    document.querySelectorAll('.filter-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateFiltros();
        });
    });

    // Range slider de salário
    const sliderSalario = document.getElementById('filterSalario');
    if (sliderSalario) {
        sliderSalario.addEventListener('input', (e) => {
            document.getElementById('salarioValue').textContent = e.target.value;
        });
    }

    // Botão aplicar filtros
    const btnAplicar = document.getElementById('btnAplicarFiltros');
    if (btnAplicar) {
        btnAplicar.addEventListener('click', () => {
            updateFiltros();
            carregarVagas(1);
        });
    }

    // Botão limpar filtros
    const btnLimpar = document.getElementById('btnLimparFiltros');
    if (btnLimpar) {
        btnLimpar.addEventListener('click', () => {
            document.querySelectorAll('.filter-checkbox').forEach(cb => cb.checked = false);
            document.getElementById('filterLocalizacao').value = '';
            document.getElementById('filterSalario').value = 5000;
            document.getElementById('salarioValue').textContent = '5000';
            filtrosAtivos = {};
            carregarVagas(1);
        });
    }
}

/**
 * Atualizar filtros ativos
 */
function updateFiltros() {
    filtrosAtivos = {};

    // Tipos de contrato selecionados
    const tiposChecked = Array.from(document.querySelectorAll('.filter-checkbox:checked'))
        .map(cb => cb.value);
    if (tiposChecked.length > 0) {
        filtrosAtivos.tipos = tiposChecked.join(',');
    }

    // Localização
    const localizacao = document.getElementById('filterLocalizacao')?.value;
    if (localizacao) {
        filtrosAtivos.localizacao = localizacao;
    }

    // Salário máximo
    const salario = document.getElementById('filterSalario')?.value;
    if (salario && salario < 5000) {
        filtrosAtivos.salario_max = salario;
    }
}

/**
 * Setup busca em tempo real
 */
function setupSearchBusca() {
    const buscaInput = document.getElementById('buscaVaga');
    if (!buscaInput) return;

    buscaInput.addEventListener('input', (e) => {
        const termo = e.target.value.toLowerCase();
        
        if (termo === '') {
            renderizarVagas(vagasData);
            return;
        }

        const vagasFiltradas = vagasData.filter(vaga => {
            return vaga.titulo.toLowerCase().includes(termo) || 
                   vaga.empresa.toLowerCase().includes(termo) ||
                   vaga.localizacao.toLowerCase().includes(termo);
        });

        renderizarVagas(vagasFiltradas);
    });
}

/**
 * Renderizar cards de vagas
 */
function renderizarVagas(vagas) {
    const container = document.getElementById('vagasContainer');
    if (!container) return;

    if (vagas.length === 0) {
        container.innerHTML = `
            <div class="col-12">
                <div class="estado-vazio">
                    <i class="bi bi-inbox"></i>
                    <h5 class="mt-3">Nenhuma vaga encontrada</h5>
                    <p>Tente ajustar os filtros para ver mais oportunidades</p>
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = vagas.map(vaga => `
        <div class="col-12">
            <div class="vaga-item">
                <div class="row align-items-start">
                    <div class="col-md-8">
                        <h5 class="vaga-titulo">${vaga.titulo}</h5>
                        <p class="vaga-empresa">
                            <i class="bi bi-building me-2"></i>${vaga.empresa}
                        </p>
                        <p class="vaga-localizacao">
                            <i class="bi bi-geo-alt me-1"></i>${vaga.localizacao}
                        </p>
                        <p class="vaga-descricao">${truncateText(vaga.descricao || '', 200)}</p>
                        <div class="d-flex flex-wrap gap-2">
                            <span class="badge bg-light text-dark">
                                <i class="bi bi-briefcase me-1"></i>${formatTipoContrato(vaga.tipo_contracto)}
                            </span>
                            <span class="badge bg-light text-dark">
                                <i class="bi bi-clock me-1"></i>${formatDate(vaga.data_publicacao)}
                            </span>
                            ${vaga.data_encerramento ? `
                                <span class="badge bg-primary text-white">
                                    Encerramento: ${formatDate(vaga.data_encerramento)}
                                </span>
                            ` : ''}
                        </div>
                    </div>
                    <div class="col-md-4">
                        ${vaga.salario_minimo && vaga.salario_maximo ? `
                            <div class="vaga-salario text-center mb-3">
                                <strong>${formatCurrency(vaga.salario_minimo)} - ${formatCurrency(vaga.salario_maximo)}</strong>
                            </div>
                        ` : ''}
                        <button class="btn btn-primary w-100" onclick="abrirDetalhesVaga(${vaga.id})">
                            <i class="bi bi-search me-1"></i>Ver Detalhes
                        </button>
                        ${api.isAuthenticated() ? `
                            <button class="btn btn-outline-primary w-100 mt-2" onclick="candidatarVaga(${vaga.id})">
                                <i class="bi bi-check-circle me-1"></i>Candidatar-se
                            </button>
                        ` : `
                            <button class="btn btn-outline-primary w-100 mt-2" onclick="loginParaCandidatar()">
                                <i class="bi bi-lock me-1"></i>Faça Login para Candidatar
                            </button>
                        `}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Abrir modal com detalhes da vaga
 */
async function abrirDetalhesVaga(vagaId) {
    try {
        const response = await api.getVaga(vagaId);
        const vaga = response.data;

        const modalBody = document.getElementById('modalVagaBody');
        const modalTitle = document.getElementById('modalVagaTitle');

        modalTitle.textContent = vaga.titulo;
        modalBody.innerHTML = `
            <div class="detalhes-empresa mb-3">
                <i class="bi bi-building me-2"></i>${vaga.empresa}
            </div>

            <div class="detalhes-localizacao mb-2">
                <i class="bi bi-geo-alt me-2"></i>${vaga.localizacao}
            </div>

            ${vaga.salario_minimo && vaga.salario_maximo ? `
                <div class="detalhes-salario">
                    ${formatCurrency(vaga.salario_minimo)} - ${formatCurrency(vaga.salario_maximo)}
                </div>
            ` : ''}

            <div class="detalhes-section">
                <h6>Tipo de Contrato</h6>
                <p>${formatTipoContrato(vaga.tipo_contracto)}</p>
            </div>

            ${vaga.descricao ? `
                <div class="detalhes-section">
                    <h6>Descrição da Vaga</h6>
                    <p>${vaga.descricao}</p>
                </div>
            ` : ''}

            ${vaga.competencias_requeridas ? `
                <div class="detalhes-section">
                    <h6>Competências Requeridas</h6>
                    <ul>${vaga.competencias_requeridas.split(',').map(c => `<li>${c.trim()}</li>`).join('')}</ul>
                </div>
            ` : ''}

            ${vaga.beneficios ? `
                <div class="detalhes-section">
                    <h6>Benefícios</h6>
                    <ul>${vaga.beneficios.split(',').map(b => `<li>${b.trim()}</li>`).join('')}</ul>
                </div>
            ` : ''}

            ${vaga.data_encerramento ? `
                <div class="alert alert-warning mt-3">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    <strong>Encerramento:</strong> ${formatDate(vaga.data_encerramento)}
                </div>
            ` : ''}
        `;

        // Update button de candidatura
        const btnCandidatar = document.getElementById('btnCandidatar');
        btnCandidatar.onclick = () => {
            if (api.isAuthenticated()) {
                candidatarVaga(vagaId);
            } else {
                loginParaCandidatar();
            }
        };

        const modal = new bootstrap.Modal(document.getElementById('modalVaga'));
        modal.show();
    } catch (error) {
        showAlert('Erro ao carregar detalhes da vaga', 'danger');
    }
}

/**
 * Candidatar a uma vaga
 */
async function candidatarVaga(vagaId) {
    try {
        if (!api.isAuthenticated()) {
            showAlert('Faça login para candidatar-se', 'warning');
            return;
        }

        const notaPessoal = prompt('Adicione uma nota pessoal para sua candidatura:');
        if (notaPessoal === null) return;

        await api.candidatar(vagaId, notaPessoal);

        showAlert('Candidatura submetida com sucesso!', 'success');
        
        // Fechar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalVaga'));
        if (modal) modal.hide();
    } catch (error) {
        showAlert('Erro ao submeter candidatura: ' + error.message, 'danger');
    }
}

/**
 * Redirecionar para login
 */
function loginParaCandidatar() {
    showAlert('Faça login para candidatar-se', 'info');
    const modal = new bootstrap.Modal(document.getElementById('modalAuth'));
    document.getElementById('loginTab').click();
    modal.show();
}

/**
 * Renderizar paginação
 */
function renderizarPaginacao(total) {
    const paginacao = document.querySelector('.pagination ul');
    if (!paginacao) return;

    const totalPaginas = Math.ceil(total / 20);
    let html = '';

    if (paginaAtual > 1) {
        html += `<li class="page-item"><button class="page-link" onclick="carregarVagas(${paginaAtual - 1})">Anterior</button></li>`;
    }

    for (let i = Math.max(1, paginaAtual - 2); i <= Math.min(totalPaginas, paginaAtual + 2); i++) {
        html += `<li class="page-item ${i === paginaAtual ? 'active' : ''}">
            <button class="page-link" onclick="carregarVagas(${i})">${i}</button>
        </li>`;
    }

    if (paginaAtual < totalPaginas) {
        html += `<li class="page-item"><button class="page-link" onclick="carregarVagas(${paginaAtual + 1})">Próxima</button></li>`;
    }

    paginacao.innerHTML = html;
}

/**
 * Formatar tipo de contrato
 */
function formatTipoContrato(tipo) {
    const tipos = {
        'permanente': 'Contrato Permanente',
        'termo_certo': 'Contrato a Termo Certo',
        'estagio': 'Estágio',
        'freelance': 'Freelance'
    };
    return tipos[tipo] || tipo;
}

/**
 * Mostrar/esconder loading
 */
function showLoading(show) {
    const container = document.getElementById('vagasContainer');
    if (!container) return;
    
    if (show) {
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Carregando...</span>
                </div>
            </div>
        `;
    }
}
