/**
 * Script Global - SWPCF
 */

document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

function initializeApp() {
    // Inicializar modais de autenticação
    setupAuthModals();
    
    // Verificar se utilizador está autenticado
    updateNavBar();
}

/**
 * Setup dos modals de Login e Registro
 */
function setupAuthModals() {
    // Botões para abrir modal
    const btnLogin = document.getElementById('btnLogin');
    const btnRegisterHero = document.getElementById('btnRegisterHero');
    const btnRegisterCTA = document.getElementById('btnRegisterCTA');
    
    if (btnLogin) btnLogin.addEventListener('click', () => {
        const modal = new bootstrap.Modal(document.getElementById('modalAuth'));
        document.getElementById('loginTab').click();
        modal.show();
    });
    
    if (btnRegisterHero) btnRegisterHero.addEventListener('click', () => {
        const modal = new bootstrap.Modal(document.getElementById('modalAuth'));
        document.getElementById('registroTab').click();
        modal.show();
    });
    
    if (btnRegisterCTA) btnRegisterCTA.addEventListener('click', () => {
        const modal = new bootstrap.Modal(document.getElementById('modalAuth'));
        document.getElementById('registroTab').click();
        modal.show();
    });

    // Formulário de Login
    const formLogin = document.getElementById('formLogin');
    if (formLogin) {
        formLogin.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = formLogin.querySelector('input[name="email"]').value;
            const password = formLogin.querySelector('input[name="password"]').value;
            
            try {
                const response = await api.login(email, password);
                showAlert('Login realizado com sucesso!', 'success');
                
                // Fechar modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalAuth'));
                modal.hide();
                
                // Atualizar navbar
                updateNavBar();
                
                // Redirecionar para dashboard do candidato
                setTimeout(() => {
                    window.location.href = 'perfil.html';
                }, 1500);
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });
    }

    // Formulário de Registro
    const formRegistro = document.getElementById('formRegistro');
    if (formRegistro) {
        formRegistro.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const nome = formRegistro.querySelector('input[name="nome"]').value;
            const email = formRegistro.querySelector('input[name="email"]').value;
            const password = formRegistro.querySelector('input[name="password"]').value;
            const telefone = formRegistro.querySelector('input[name="telefone"]').value;
            
            try {
                await api.register(nome, email, password, telefone);
                showAlert('Conta criada com sucesso! Faça login para continuar.', 'success');
                
                // Limpar formulário
                formRegistro.reset();
                
                // Mudar para aba de login
                document.getElementById('loginTab').click();
            } catch (error) {
                showAlert(error.message, 'danger');
            }
        });
    }
}

/**
 * Atualizar navbar baseado no estado de autenticação
 */
function updateNavBar() {
    const btnLogin = document.getElementById('btnLogin');
    const navbarNav = document.querySelector('.navbar-collapse');
    
    if (api.isAuthenticated()) {
        const user = api.getUser();
        
        if (btnLogin) {
            btnLogin.innerHTML = `
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-light dropdown-toggle" type="button" 
                            id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle me-1"></i>${user.nome}
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser">
                        <li><a class="dropdown-item" href="perfil.html">
                            <i class="bi bi-person me-2"></i>Meu Perfil
                        </a></li>
                        <li><a class="dropdown-item" href="candidaturas.html">
                            <i class="bi bi-file-earmark me-2"></i>Minhas Candidaturas
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><button class="dropdown-item" onclick="logout()" style="border: none; background: none; cursor: pointer; text-align: left;">
                            <i class="bi bi-box-arrow-right me-2"></i>Sair
                        </button></li>
                    </ul>
                </div>
            `;
        }
    } else {
        if (btnLogin) {
            btnLogin.innerHTML = `
                <i class="bi bi-box-arrow-in-right me-1"></i>Login
            `;
            btnLogin.onclick = () => {
                const modal = new bootstrap.Modal(document.getElementById('modalAuth'));
                document.getElementById('loginTab').click();
                modal.show();
            };
        }
    }
}

/**
 * Logout
 */
function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        api.logout();
        showAlert('Até logo!', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
}

/**
 * Mostrar alertas
 */
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '20px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '9999';
    alertDiv.style.minWidth = '300px';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Remover após 5 segundos
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

/**
 * Formatar moeda
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-PT', {
        style: 'currency',
        currency: 'EUR'
    }).format(value);
}

/**
 * Formatar data
 */
function formatDate(date) {
    return new Date(date).toLocaleDateString('pt-PT', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

/**
 * Truncar texto
 */
function truncateText(text, length = 150) {
    if (text.length <= length) return text;
    return text.substring(0, length) + '...';
}
