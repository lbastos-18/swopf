/**
 * Script - Página Inicial
 */

document.addEventListener('DOMContentLoaded', async () => {
    await carregarVagasDestaque();
});

async function carregarVagasDestaque() {
    try {
        const response = await api.getVagas({ limit: 3, offset: 0 });
        renderizarVagasDestaque(response.data.vagas);
    } catch (error) {
        console.error('Erro ao carregar vagas destaque:', error);
    }
}

function renderizarVagasDestaque(vagas) {
    const container = document.getElementById('vagasDestaque');
    if (!container || vagas.length === 0) return;

    container.innerHTML = vagas.map(vaga => `
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow-sm border-0 hover-card">
                <div class="card-body">
                    <span class="badge bg-primary mb-2">${formatTipoContrato(vaga.tipo_contracto)}</span>
                    <h5 class="card-title">${vaga.titulo}</h5>
                    <p class="text-muted small mb-3">
                        <i class="bi bi-building me-1"></i>${vaga.empresa}
                    </p>
                    <p class="card-text">${truncateText(vaga.descricao || '', 100)}</p>
                    <div class="mt-3 gap-2 d-flex align-items-center justify-content-between">
                        ${vaga.salario_minimo && vaga.salario_maximo ? `
                            <span class="badge bg-primary text-white">${formatCurrency(vaga.salario_minimo)} - ${formatCurrency(vaga.salario_maximo)}</span>
                        ` : '<span></span>'}
                        <a href="formacoes.html" class="btn btn-sm btn-primary">Ver</a>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function formatTipoContrato(tipo) {
    const tipos = {
        'permanente': 'Permanente',
        'termo_certo': 'Termo Certo',
        'estagio': 'Estágio',
        'freelance': 'Freelance'
    };
    return tipos[tipo] || tipo;
}
