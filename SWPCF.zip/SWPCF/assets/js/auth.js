/**
 * AUTH.JS - Sistema de Autenticação SWPCF
 * Gerencia login, logout, e estado de autenticação do utilizador
 */

class Auth {
  constructor() {
    this.user = this.loadUser();
    this.token = this.loadToken();
  }

  /**
   * Carrega utilizador do localStorage
   */
  loadUser() {
    try {
      const userData = localStorage.getItem('swpcf_user');
      return userData ? JSON.parse(userData) : null;
    } catch (e) {
      console.error('Erro ao carregar utilizador:', e);
      return null;
    }
  }

  /**
   * Carrega token do localStorage
   */
  loadToken() {
    return localStorage.getItem('swpcf_token') || null;
  }

  /**
   * Realiza login
   * @param {string} email - Email do utilizador
   * @param {string} password - Senha
   * @returns {object} - { success: boolean, user?: object, message?: string }
   */
  login(email, password) {
    // Validações
    if (!email || !password) {
      return { success: false, message: 'Email e senha são obrigatórios' };
    }

    // Mock: Simular diferentes tipos de utilizadores para teste
    let user = null;

    // Admin principal
    if (email === 'admin@swpcf.pt' && password === 'admin123') {
      user = {
        id: 1,
        nome: 'Administrador SWPCF',
        email: email,
        role: 'super_admin',
        permissoes: ['full', 'gerenciar_admins', 'gerenciar_candidatos', 'gerenciar_estagios'],
        avatar: null
      };
    }
    // Admin secundário
    else if (email.endsWith('@admin.swpcf.pt') && password.length >= 6) {
      user = {
        id: Math.floor(Math.random() * 1000),
        nome: email.split('@')[0],
        email: email,
        role: 'admin',
        permissoes: ['gerenciar_candidatos', 'gerenciar_estagios', 'ver_relatorios'],
        avatar: null
      };
    }
    // Candidato
    else if (email.includes('@') && password.length >= 6) {
      user = {
        id: Math.floor(Math.random() * 100000),
        nome: 'Candidato ' + email.split('@')[0],
        email: email,
        role: 'candidato',
        permissoes: ['candidatar', 'ver_perfil', 'ver_estagios'],
        avatar: null
      };
    }

    if (user) {
      // Gerar token mock
      const token = 'token_' + Date.now() + '_' + Math.random().toString(36).substr(2);

      // Guardar em localStorage
      this.user = user;
      this.token = token;
      localStorage.setItem('swpcf_user', JSON.stringify(user));
      localStorage.setItem('swpcf_token', token);

      // Disparar evento de autenticação
      window.dispatchEvent(new CustomEvent('auth-changed', { detail: { user } }));

      return { success: true, user };
    }

    return { success: false, message: 'Email ou senha inválidos' };
  }

  /**
   * Realiza logout
   */
  logout() {
    this.user = null;
    this.token = null;
    localStorage.removeItem('swpcf_user');
    localStorage.removeItem('swpcf_token');

    // Disparar evento de logout
    window.dispatchEvent(new CustomEvent('auth-changed', { detail: { user: null } }));

    // Redirecionar para homepage
    window.location.href = '../public/index.html';
  }

  /**
   * Verifica se utilizador está autenticado
   */
  isAuthenticated() {
    return !!this.user && !!this.token;
  }

  /**
   * Verifica se é administrador
   */
  isAdmin() {
    return this.user?.role === 'admin' || this.user?.role === 'super_admin';
  }

  /**
   * Verifica se é super administrador
   */
  isSuperAdmin() {
    return this.user?.role === 'super_admin';
  }

  /**
   * Verifica se é candidato
   */
  isCandidato() {
    return this.user?.role === 'candidato';
  }

  /**
   * Verifica se tem permissão específica
   */
  hasPermission(permission) {
    return this.user?.permissoes?.includes(permission) || false;
  }

  /**
   * Retorna dados do utilizador atual
   */
  getUser() {
    return this.user;
  }

  /**
   * Retorna token de autenticação
   */
  getToken() {
    return this.token;
  }

  /**
   * Atualiza dados do utilizador
   */
  updateUser(userData) {
    this.user = { ...this.user, ...userData };
    localStorage.setItem('swpcf_user', JSON.stringify(this.user));
    window.dispatchEvent(new CustomEvent('auth-changed', { detail: { user: this.user } }));
  }

  /**
   * Valida se utilizador pode acessar rota protegida
   */
  canAccess(requiredRole = null, requiredPermission = null) {
    if (!this.isAuthenticated()) {
      return false;
    }

    if (requiredRole && this.user.role !== requiredRole) {
      return false;
    }

    if (requiredPermission && !this.hasPermission(requiredPermission)) {
      return false;
    }

    return true;
  }

  /**
   * Protege rota - redireciona se não autenticado
   */
  requireAuthenticated(redirectUrl = '../public/login.html') {
    if (!this.isAuthenticated()) {
      console.warn('Acesso negado: Utilizador não autenticado');
      window.location.href = redirectUrl;
      return false;
    }
    return true;
  }

  /**
   * Protege rota - redireciona se não for admin
   */
  requireAdmin(redirectUrl = '../public/index.html') {
    if (!this.isAuthenticated()) {
      console.warn('Acesso negado: Utilizador não autenticado');
      window.location.href = '../public/login.html';
      return false;
    }

    if (!this.isAdmin()) {
      console.warn('Acesso negado: Apenas administradores');
      alert('Acesso Negado: Apenas administradores podem acessar esta área.');
      window.location.href = redirectUrl;
      return false;
    }

    return true;
  }

  /**
   * Protege rota - redireciona se não for super admin
   */
  requireSuperAdmin(redirectUrl = '../public/index.html') {
    if (!this.isSuperAdmin()) {
      console.warn('Acesso negado: Apenas super administradores');
      alert('Acesso Negado: Apenas super administradores podem acessar esta área.');
      window.location.href = redirectUrl;
      return false;
    }

    return true;
  }
}

// Criar instância global de autenticação
window.auth = new Auth();

// Auto-proteger rotas ao carregar página
document.addEventListener('DOMContentLoaded', function() {
  // Se página tem data-auth-required, proteger
  const htmlElement = document.documentElement;
  
  if (htmlElement.getAttribute('data-auth-required') === 'true') {
    window.auth.requireAuthenticated();
  }

  if (htmlElement.getAttribute('data-admin-required') === 'true') {
    window.auth.requireAdmin();
  }

  if (htmlElement.getAttribute('data-super-admin-required') === 'true') {
    window.auth.requireSuperAdmin();
  }
});

// Log de debug (remover em produção)
console.log('[Auth] Sistema de autenticação carregado');
console.log('[Auth] Utilizador autenticado:', window.auth.isAuthenticated());
if (window.auth.isAuthenticated()) {
  console.log('[Auth] Utilizador:', window.auth.getUser().nome, '(' + window.auth.getUser().role + ')');
}
