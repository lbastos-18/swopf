const api = new APIClient();
let allEstagios = [];
let currentPage = 1;
const itemsPerPage = 6;

async function carregarEstagios() {
    try {
        const response = await api.get('/api/estagios');
        allEstagios = response.estagios || [];
        exibirEstagios();
    } catch (error) {
        console.error('Erro ao carregar estágios:', error);
        document.getElementById('estagiosContainer').innerHTML = 
            '<div class="col-12"><div class="alert alert-warning">Erro ao carregar estágios</div></div>';
    }
}

function exibirEstagios() {
    const inicio = (currentPage - 1) * itemsPerPage;
    const fim = inicio + itemsPerPage;
    const estagiosPage = allEstagios.slice(inicio, fim);

    const container = document.getElementById('estagiosContainer');

    if (estagiosPage.length === 0) {
        container.innerHTML = '<div class="col-12"><div class="alert alert-info">Nenhum estágio encontrado</div></div>';
        gerarPaginacao(0);
        return;
    }

    container.innerHTML = estagiosPage.map(estagio => `
        <div class="col-12">
            <div class="card estagio-card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="estagio-title">${estagio.titulo}</h5>
                            <p class="text-muted mb-2">${estagio.descricao}</p>
                            
                            <div class="estagio-info mb-2">
                                <span class="me-3">
                                    <i class="fas fa-folder-open me-1"></i>
                                    <strong class="estagio-area">${estagio.area}</strong>
                                </span>
                                <span class="me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    ${estagio.duracao} semanas
                                </span>
                                <span>
                                    <i class="fas fa-users me-1"></i>
                                    ${estagio.numero_vagas} vaga${estagio.numero_vagas !== 1 ? 's' : ''}
                                </span>
                            </div>

                            <div class="mb-2">
                                <span class="badge ${estagio.tipo === 'remunerado' ? 'badge-remunerado' : 'badge-nao-remunerado'}">
                                    ${estagio.tipo === 'remunerado' ? `Remunerado: ${estagio.bolsa_remuneracao} Kz` : 'Não Remunerado'}
                                </span>
                            </div>

                            <div class="estagio-info">
                                <small class="text-muted">
                                    <i class="fas fa-calendar-alt me-1"></i>
                                    Data limite: ${new Date(estagio.data_limite).toLocaleDateString('pt-PT')}
                                </small>
                            </div>
                        </div>

                        <div class="col-md-4 d-flex flex-column justify-content-between align-items-end">
                            <div class="text-end">
                                <small class="text-muted">ID: ${estagio.id}</small>
                            </div>
                            <button class="btn btn-candidatar btn-sm" onclick="candidatarEstagio(${estagio.id})">
                                <i class="fas fa-paper-plane me-2"></i>Candidatar-se
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `).join('');

    gerarPaginacao(allEstagios.length);
}

function gerarPaginacao(total) {
    const paginas = Math.ceil(total / itemsPerPage);
    const paginationEl = document.getElementById('pagination');

    if (paginas <= 1) {
        paginationEl.innerHTML = '';
        return;
    }

    let html = '';
    for (let i = 1; i <= paginas; i++) {
        html += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="irParaPagina(${i})">${i}</a>
            </li>
        `;
    }

    paginationEl.innerHTML = html;
}

function irParaPagina(pagina) {
    currentPage = pagina;
    exibirEstagios();
    window.scrollTo({top: 0, behavior: 'smooth'});
}

function aplicarFiltros() {
    const tipo = Array.from(document.querySelectorAll('.filter-checkbox:checked'))
        .map(cb => cb.value);
    const area = document.getElementById('filterArea').value.toLowerCase();

    let filtrados = allEstagios;

    if (tipo.length > 0) {
        filtrados = filtrados.filter(e => tipo.includes(e.tipo));
    }

    if (area) {
        filtrados = filtrados.filter(e => e.area.toLowerCase().includes(area));
    }

    allEstagios = filtrados;
    currentPage = 1;
    exibirEstagios();
}

function candidatarEstagio(estagioId) {
    // Verificar se o utilizador está autenticado
    const token = localStorage.getItem('token');
    if (!token) {
        // Abrir modal de login
        const modal = new bootstrap.Modal(document.getElementById('authModal'));
        modal.show();
        return;
    }

    // Aqui redirecionar para página de candidatura ou abrir modal
    alert('Funcionalidade de candidatura será implementada. Estágio ID: ' + estagioId);
}

// Setup para formulários de autenticação
document.addEventListener('DOMContentLoaded', function() {
    const btnLogin = document.getElementById('btnLogin');
    const authModal = new bootstrap.Modal(document.getElementById('authModal'));

    btnLogin.addEventListener('click', () => {
        authModal.show();
    });

    // Carregar estágios
    carregarEstagios();
});
