<?php
/**
 * Router Principal - SWPCF
 * Sistema de roteamento simples com templates PHP
 */

session_start();

// Configurações básicas
define('BASE_URL', 'http://' . $_SERVER['HTTP_HOST']);
define('ROOT_PATH', __DIR__);

// Obter página solicitada
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$requestPath = parse_url($requestUri, PHP_URL_PATH) ?? '/';
$basePath = '';
if ($requestPath === '/SWPCF' || strpos($requestPath, '/SWPCF/') === 0) {
    $basePath = '/SWPCF';
}

// Remover prefixo base quando existir; suporta com e sem /SWPCF
$relativePath = $requestPath;
if ($basePath !== '' && strpos($requestPath, $basePath) === 0) {
    $relativePath = substr($requestPath, strlen($basePath));
}
if ($relativePath === '' || $relativePath[0] !== '/') {
    $relativePath = '/' . ltrim($relativePath, '/');
}

// Alias para servir ficheiros estáticos que vivem em /public mas são pedidos em /
$publicAliasFile = ROOT_PATH . '/public' . $relativePath;
if (is_file($publicAliasFile) && pathinfo($publicAliasFile, PATHINFO_EXTENSION) !== 'php') {
    $mime = function_exists('mime_content_type') ? mime_content_type($publicAliasFile) : null;
    if (!empty($mime)) {
        header('Content-Type: ' . $mime);
    }
    readfile($publicAliasFile);
    exit;
}

// Servir ficheiros admin HTML diretamente
if (strpos($relativePath, '/admin/') === 0) {
    $adminFile = ROOT_PATH . $relativePath;
    if (is_file($adminFile) && pathinfo($adminFile, PATHINFO_EXTENSION) === 'html') {
        header('Content-Type: text/html; charset=utf-8');
        readfile($adminFile);
        exit;
    }
}

// Servir páginas públicas HTML diretamente (ex.: /registo.html, /login.html)
if (pathinfo($relativePath, PATHINFO_EXTENSION) === 'html') {
    $publicHtml = ROOT_PATH . '/public' . $relativePath;
    if (is_file($publicHtml)) {
        header('Content-Type: text/html; charset=utf-8');
        readfile($publicHtml);
        exit;
    }
}

// Servir arquivos estáticos diretamente no servidor embutido
if (php_sapi_name() === 'cli-server') {
    $staticCandidates = [
        ROOT_PATH . $relativePath,
        ROOT_PATH . '/public' . $relativePath,
    ];
    foreach ($staticCandidates as $staticFile) {
        if (is_file($staticFile) && pathinfo($staticFile, PATHINFO_EXTENSION) !== 'php') {
            return false;
        }
    }
}

// Encaminhar chamadas da API para arquivos reais
if (strpos($relativePath, '/api/') === 0) {
    $apiFile = ROOT_PATH . $relativePath;
    if (is_file($apiFile)) {
        require $apiFile;
        exit;
    }
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Endpoint da API não encontrado']);
    exit;
}

// Remover base path e limpar
$path = '/' . trim(strtok($relativePath, '?'), '/');

// Mapping de rotas
$routes = [
    '/' => 'index',
    '/home' => 'index',
    '/estagios' => 'estagios',
    '/vagas' => 'vagas',
    '/formacoes' => 'formacoes',
    '/sobre' => 'sobre',
    '/contactos' => 'contatos',
    '/contatos' => 'contatos',
    '/login' => 'login',
    '/registo' => 'registo',
    '/dashboard' => 'dashboard',
    '/perfil' => 'perfil',
    '/candidaturas' => 'candidaturas',
];

// Determinar página
$page = $routes[$path] ?? 'index';

// Incluir página
$pageFile = ROOT_PATH . '/public/pages/' . $page . '.php';

// Se arquivo não existe, mostrar home
if (!file_exists($pageFile)) {
    $pageFile = ROOT_PATH . '/public/pages/index.php';
}

// Renderizar página
require_once ROOT_PATH . '/public/includes/header.php';
require_once $pageFile;
require_once ROOT_PATH . '/public/includes/footer.php';
?>

