# SWPCF - Sistema de Gestão de Estágios

## 🚀 Instalação Rápida (XAMPP)

### 1. Preparar XAMPP
Copiar pasta SWPCF para: `C:\xampp\htdocs\SWPCF` (Windows) ou `/Applications/XAMPP/htdocs/SWPCF` (Mac)

### 2. Criar Base de Dados
1. Abrir XAMPP Control Panel
2. Iniciar **Apache** e **MySQL**
3. Abrir navegador: `http://localhost/phpmyadmin`
4. Clicar em "Novo" → Nome: `swpcf`
5. Clicar em "Importar" → Selecionar `database.sql`
6. Clicar em "Executar"

### 3. Testar Conexão
Abrir: `http://localhost/SWPCF/test-conexao.php`

### 4. Acessar Sistema
- **Login**: `http://localhost/SWPCF/public/login.html`
- **Admin**: `http://localhost/SWPCF/admin/dashboard.html`

## 👤 Credenciais Padrão

**Admin:**
- Email: `admin@swpcf.local`
- Senha: `admin123`

**Candidato Teste:**
- Email: `candidato@teste.com`
- Senha: `admin123`

## ✅ Funcionalidades

- ✅ Login/Registo funcional com PHP
- ✅ CRUD de Vagas (Criar, Editar, Listar, Apagar)
- ✅ CRUD de Cursos (Criar, Editar, Listar, Apagar)
- ✅ Dashboard Admin com estatísticas
- ✅ Solicitações de Estágios (Escolas pedem, Admin aprova)
- ✅ Candidaturas (Alunos candidatam-se)

## 📂 Estrutura
```
SWPCF/
├── admin/              # Painel administrativo
│   ├── dashboard.html  # Dashboard principal
│   ├── vagas-*.html    # Gestão de vagas
│   ├── cursos-*.html   # Gestão de cursos
│   └── js/             # JavaScript admin
├── public/             # Área pública/alunos
│   ├── login.html      # Login funcional
│   ├── registo.html    # Registo funcional
│   └── dashboard.html  # Dashboard aluno
├── api/                # Endpoints PHP
│   ├── login.php       # API login
│   ├── register.php    # API registo
│   ├── vagas.php       # CRUD vagas
│   └── cursos.php      # CRUD cursos
├── config.php          # Configuração DB
├── database.sql        # Schema completo
└── test-conexao.php    # Teste conexão
```

## 🔧 Troubleshooting

**Erro de conexão?**
1. Verificar se MySQL está rodando no XAMPP
2. Verificar credenciais em `config.php` (user: root, pass: vazio)
3. Verificar se database `swpcf` existe no phpMyAdmin

**Página em branco?**
1. Abrir `http://localhost/SWPCF/test-conexao.php`
2. Ver erros no console (F12)
3. Verificar logs do Apache em `xampp/apache/logs/error.log`

**Login não funciona?**
1. Verificar se tabela `utilizadores` existe
2. Importar `database.sql` novamente
3. Testar com credenciais padrão acima

**Admin:** http://localhost/SWPCF/admin
**Público:** http://localhost/SWPCF/

## 💡 Nota

Este projeto foi simplificado para facilitar apresentação e explicação durante o estágio.
