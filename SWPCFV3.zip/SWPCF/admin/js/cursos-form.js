/**
 * CURSOS-FORM.JS - Gerencia formulários de criação/edição de cursos
 */

document.addEventListener('DOMContentLoaded', function() {
    const formNovoCurso = document.getElementById('formNovoCurso');
    
    if (formNovoCurso) {
        // Verificar se é edição
        const urlParams = new URLSearchParams(window.location.search);
        const cursoId = urlParams.get('edit');
        
        if (cursoId) {
            carregarCursoParaEdicao(cursoId);
        }
        
        // Setup do formulário
        setupFormCurso(formNovoCurso);
    }
});

/**
 * Carregar curso para edição
 */
async function carregarCursoParaEdicao(cursoId) {
    try {
        const response = await fetch(`../api/cursos.php?id=${cursoId}`);
        const data = await response.json();
        
        if (data.success && data.data) {
            const curso = data.data;
            const form = document.getElementById('formNovoCurso');
            
            // Preencher formulário
            document.querySelector('input[name="nome"]').value = curso.nome || '';
            document.querySelector('textarea[name="descricao"]').value = curso.descricao || '';
            document.querySelector('input[name="duracao"]').value = curso.duracao || '';
            document.querySelector('input[name="vagas"]').value = curso.vagas || '';
            
            // Mudar título e ID da form
            document.querySelector('.page-header h1').textContent = '✏️ Editar Curso';
            form.dataset.cursoId = cursoId;
            
            // Mudar botão
            document.querySelector('button[type="submit"]').innerHTML = '<i class="fas fa-save me-2"></i>Atualizar';
        }
    } catch (error) {
        Admin.showNotification('Erro ao carregar curso: ' + error.message, 'danger');
    }
}

/**
 * Setup do formulário de curso
 */
function setupFormCurso(form) {
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Validar campos obrigatórios
        const nome = document.querySelector('input[name="nome"]').value.trim();
        
        if (!nome) {
            Admin.showNotification('O nome do curso é obrigatório', 'warning');
            return;
        }
        
        // Coletar dados
        const dadosCurso = {
            nome: nome,
            descricao: document.querySelector('textarea[name="descricao"]').value.trim(),
            duracao: parseInt(document.querySelector('input[name="duracao"]').value) || 1,
            vagas: parseInt(document.querySelector('input[name="vagas"]').value) || 1
        };
        
        // Validar
        if (dadosCurso.duracao < 1) {
            Admin.showNotification('A duração deve ser pelo menos 1 mês', 'warning');
            return;
        }
        
        if (dadosCurso.vagas < 1) {
            Admin.showNotification('Deve haver pelo menos 1 vaga', 'warning');
            return;
        }
        
        const cursoId = form.dataset.cursoId;
        
        try {
            let response;
            
            if (cursoId) {
                response = await fetch(`../api/cursos.php?id=${cursoId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(dadosCurso)
                });
            } else {
                response = await fetch('../api/cursos.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(dadosCurso)
                });
            }
            
            const data = await response.json();
            
            if (data.success) {
                Admin.showNotification(
                    cursoId ? 'Curso atualizado com sucesso!' : 'Curso criado com sucesso!',
                    'success'
                );
                
                // Redirecionar após 1.5 segundos
                setTimeout(() => {
                    window.location.href = 'cursos-lista.html';
                }, 1500);
            } else {
                Admin.showNotification(data.message || 'Erro ao guardar curso', 'danger');
            }
        } catch (error) {
            Admin.showNotification('Erro: ' + error.message, 'danger');
        }
    });
}
