/**
 * VAGAS-FORM.JS - Gerencia formulários de criação/edição de vagas
 */

document.addEventListener('DOMContentLoaded', function() {
    const formNovaVaga = document.getElementById('formNovaVaga');
    
    if (formNovaVaga) {
        // Verificar se é edição
        const urlParams = new URLSearchParams(window.location.search);
        const vagaId = urlParams.get('edit');
        
        if (vagaId) {
            carregarVagaParaEdicao(vagaId);
        }
        
        // Setup do formulário
        setupFormVaga(formNovaVaga);
    }
});

function notify(message, type = 'info') {
    if (window.Admin && typeof window.Admin.showNotification === 'function') {
        window.Admin.showNotification(message, type);
        return;
    }
    alert(message);
}

async function apiJsonRequest(path, options = {}) {
    const baseCandidates = ['../api', '/api', '/SWPCF/api'];
    let lastError = null;

    for (const base of baseCandidates) {
        const url = `${base}/${path}`;
        try {
            const response = await fetch(url, options);
            const raw = await response.text();
            const contentType = response.headers.get('content-type') || '';

            if (!contentType.includes('application/json')) {
                lastError = new Error(`Resposta não-JSON em ${url}`);
                continue;
            }

            const data = JSON.parse(raw);
            return { response, data };
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError || new Error('Falha ao contactar API');
}

/**
 * Carregar vaga para edição
 */
async function carregarVagaParaEdicao(vagaId) {
    try {
        const { data } = await apiJsonRequest(`vagas.php?id=${vagaId}`);
        
        if (data.success && data.data) {
            const vaga = data.data;
            const form = document.getElementById('formNovaVaga');
            
            // Preencher formulário
            document.querySelector('input[name="posicao"]').value = vaga.posicao || vaga.titulo || '';
            document.querySelector('input[name="empresa"]').value = vaga.empresa || '';
            document.querySelector('input[name="local"]').value = vaga.local || '';
            document.querySelector('textarea[name="descricao"]').value = vaga.descricao || '';
            document.querySelector('input[name="vagas"]').value = vaga.vagas_disponiveis || vaga.quantidade || '';
            
            // Mudar título e ID da form
            document.querySelector('.page-header h1').textContent = '✏️ Editar Vaga';
            form.dataset.vagaId = vagaId;
            
            // Mudar botão
            document.querySelector('button[type="submit"]').innerHTML = '<i class="fas fa-save me-2"></i>Atualizar';
        }
    } catch (error) {
        notify('Erro ao carregar vaga: ' + error.message, 'danger');
    }
}

/**
 * Setup do formulário de vaga
 */
function setupFormVaga(form) {
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Validar campos obrigatórios
        const posicao = document.querySelector('input[name="posicao"]').value.trim();
        
        if (!posicao) {
            notify('A posição é obrigatória', 'warning');
            return;
        }
        
        // Coletar dados
        const dadosVaga = {
            posicao: posicao,
            empresa: document.querySelector('input[name="empresa"]').value.trim(),
            local: document.querySelector('input[name="local"]').value.trim(),
            descricao: document.querySelector('textarea[name="descricao"]').value.trim(),
            vagas_disponiveis: parseInt(document.querySelector('input[name="vagas"]').value) || 1
        };
        
        // Validar vagas
        if (dadosVaga.vagas_disponiveis < 1) {
            notify('Deve haver pelo menos 1 vaga', 'warning');
            return;
        }
        
        const vagaId = form.dataset.vagaId;
        
        try {
            let result;
            
            if (vagaId) {
                result = await apiJsonRequest(`vagas.php?id=${vagaId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(dadosVaga)
                });
            } else {
                result = await apiJsonRequest('vagas.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(dadosVaga)
                });
            }

            const data = result.data;
            
            if (data.success) {
                notify(
                    vagaId ? 'Vaga atualizada com sucesso!' : 'Vaga criada com sucesso!',
                    'success'
                );
                
                // Redirecionar após 1.5 segundos
                setTimeout(() => {
                    window.location.href = 'vagas-lista.html';
                }, 1500);
            } else {
                notify(data.message || 'Erro ao guardar vaga', 'danger');
            }
        } catch (error) {
            notify('Erro: ' + error.message, 'danger');
        }
    });
}
