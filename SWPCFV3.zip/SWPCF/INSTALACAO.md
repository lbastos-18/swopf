# 🚀 INSTALAÇÃO RÁPIDA - SWPCF

## ⚡ Passos (5 minutos)

### 1️⃣ Copiar para XAMPP
```bash
# Windows:
C:\xampp\htdocs\SWPCF

# Linux/Mac:
/opt/lampp/htdocs/SWPCF
```

### 2️⃣ Iniciar XAMPP
- Abrir XAMPP Control Panel
- Iniciar **Apache**
- Iniciar **MySQL**

### 3️⃣ Criar Base de Dados
1. Abrir: `http://localhost/phpmyadmin`
2. Clicar em **"Novo"**
3. Nome: `swpcf`
4. Clicar em **"Importar"**
5. Selecionar: `database.sql`
6. Clicar em **"Executar"**

### 4️⃣ Testar
```
http://localhost/SWPCF/test-conexao.php
```

Se aparecer ✅ está pronto!

### 5️⃣ Login
```
http://localhost/SWPCF/public/login.html

Admin:
Email: admin@swpcf.local
Senha: admin123

Candidato:
Email: candidato@teste.com
Senha: admin123
```

## ✅ O que funciona:

- ✅ Login/Registo (PHP + MySQL)
- ✅ Dashboard Admin
- ✅ CRUD Vagas
- ✅ CRUD Cursos
- ✅ Solicitações Escolas
- ✅ Candidaturas Alunos

## 🔧 Problemas?

**Erro de conexão?**
1. MySQL rodando?
2. Database `swpcf` criada?
3. Importou `database.sql`?

**Página em branco?**
1. Apache rodando?
2. Arquivo em `htdocs/SWPCF`?
3. Ver console (F12)

## 📁 Estrutura Final
```
SWPCF/
├── admin/           ← Dashboard admin
├── public/          ← Área pública
├── api/             ← Backend PHP
├── config.php       ← Configuração DB
├── database.sql     ← Schema
├── test-conexao.php ← Teste
└── README.md        ← Este arquivo
```

**Pronto para usar!** 🎉
