<?php
require_once 'config.php';

echo "<h2>Teste de Conexão - SWPCF</h2>";

try {
    $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "✅ <strong>Conexão OK!</strong><br><br>";
    
    echo "<h3>Tabelas:</h3><ul>";
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $count = $db->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        echo "<li><strong>$table</strong>: $count registros</li>";
    }
    echo "</ul>";
    
    echo "<h3>Utilizadores:</h3><ul>";
    $users = $db->query("SELECT id, nome, email, tipo FROM utilizadores")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($users as $user) {
        echo "<li>{$user['nome']} ({$user['email']}) - Tipo: {$user['tipo']}</li>";
    }
    echo "</ul>";
    
    echo "<hr><p><a href='public/login.html'>Ir para Login</a> | <a href='admin/dashboard.html'>Admin Dashboard</a></p>";
    
} catch (PDOException $e) {
    echo "❌ <strong>Erro:</strong> " . $e->getMessage();
    echo "<br><br><strong>Passos para corrigir:</strong>";
    echo "<ol>";
    echo "<li>Abrir XAMPP Control Panel</li>";
    echo "<li>Iniciar Apache e MySQL</li>";
    echo "<li>Abrir phpMyAdmin (http://localhost/phpmyadmin)</li>";
    echo "<li>Importar o arquivo database.sql</li>";
    echo "</ol>";
}
