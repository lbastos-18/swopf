# 🚀 QUICK START GUIDE - SWPCF

## Início Rápido em 3 Passos

### 1. Iniciar o Servidor
```bash
cd /home/lukenny-bastos/Downloads/swopf-main/SWPCF/SWPCF
php -S localhost:8010 index.php
```

**Esperado**: 
```
PHP 8.4.18 Development Server (http://localhost:8010) started
```

### 2. Acessar no Browser
```
http://localhost:8010/SWPCF/
```

### 3. Login com Admin
- **Email**: admin@example.com
- **Password**: admin123

---

## 🗺️ Navegação Principal

| URL | Descrição |
|-----|-----------|
| `http://localhost:8010/SWPCF/` | Home / Dashboard |
| `http://localhost:8010/SWPCF/login` | Login |
| `http://localhost:8010/SWPCF/registo` | Novo Registo |
| `http://localhost:8010/SWPCF/vagas` | Listar Vagas |
| `http://localhost:8010/SWPCF/admin` | Admin Dashboard |
| `http://localhost:8010/SWPCF/admin/cursos-lista` | Listar Cursos |
| `http://localhost:8010/SWPCF/admin/vagas-lista` | Listar Vagas |

---

## 📝 Principais Features

### Utilizador (Candidato)
- [x] Registar nova conta
- [x] Login com email/password
- [x] Ver vagas disponíveis
- [x] Candidatar a vagas
- [x] Ver candidaturas
- [x] Editar perfil

### Admin
- [x] Dashboard com estatísticas
- [x] Criar/Editar/Deletar cursos
- [x] Criar/Editar/Deletar vagas
- [x] Ver todas as candidaturas
- [x] Gerir utilizadores

---

## 🔍 Testar Endpoints Manualmente

### Registar Utilizador
```bash
curl -X POST http://localhost:8010/SWPCF/api/register.php \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "João Silva",
    "email": "joao@example.com",
    "password": "senha123"
  }'
```

**Response**:
```json
{
  "success": true,
  "message": "Conta criada com sucesso",
  "user_id": 5
}
```

### Login
```bash
curl -X POST http://localhost:8010/SWPCF/api/login.php \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "admin123"
  }'
```

**Response**:
```json
{
  "success": true,
  "token": "625be0c2bedf73708281...",
  "user": {
    "id": 1,
    "nome": "Admin User",
    "email": "admin@example.com",
    "role": "admin"
  }
}
```

### Listar Vagas
```bash
curl http://localhost:8010/SWPCF/api/vagas.php
```

### Listar Cursos
```bash
curl http://localhost:8010/SWPCF/api/cursos.php
```

### Criar Curso (Admin)
```bash
curl -X POST http://localhost:8010/SWPCF/api/cursos.php \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "React Avançado",
    "descricao": "Aprenda React em profundidade",
    "duracao": 8,
    "vagas": 25
  }'
```

---

## 💾 Dados Persistem Em

```
/SWPCF/api/data/
├── utilizadores.json      → Users registados
├── cursos.json           → Cursos criados
├── vagas.json            → Vagas criadas
└── candidaturas.json     → Candidaturas submetidas
```

Estes ficheiros são criados **automaticamente** na primeira requisição.

---

## ❓ Perguntas Frequentes

### P: Preciso de MySQL?
**R**: Não! O sistema funciona 100% sem MySQL. Usa JSON fallback.

### P: Onde estão os dados salvos?
**R**: Em `/api/data/*.json` - Criados automaticamente.

### P: Posso registar um novo utilizador?
**R**: Sim! Clique em "Registo" ou POST para `/api/register.php`.

### P: Como mudo a password de um utilizador?
**R**: Use a página "Editar Perfil" ou PUT para `/api/utilizadores.php`.

### P: E se quiser usar MySQL?
**R**: Sistema detecta automaticamente. Se `pdo_mysql` disponível, usa BD.

---

## 🔐 Credenciais Padrão

| Email | Password | Tipo |
|-------|----------|------|
| admin@example.com | admin123 | Admin |
| candidato@example.com | cand123 | Candidato |

---

## 📊 Estrutura de Ficheiros

```
/SWPCF/
├── index.php                 (Router principal)
├── config.php                (Configuração)
├── api/
│   ├── register.php         (Registar utilizador)
│   ├── login.php            (Autenticar)
│   ├── cursos.php           (Gerir cursos)
│   ├── vagas.php            (Gerir vagas)
│   ├── candidaturas.php     (Gerir candidaturas)
│   ├── utilizadores.php     (Gerir utilizadores)
│   ├── helpers/
│   │   └── storage_fallback.php  (Persistência JSON)
│   └── data/                (Dados em JSON)
├── public/
│   ├── pages/              (Páginas públicas)
│   ├── css/
│   ├── js/
│   └── includes/
└── admin/
    ├── *.html              (Páginas admin)
    ├── css/
    └── js/
```

---

## ✅ Checklist de Validação

- [x] Servidor started com sucesso
- [x] Home page acessa sem erros
- [x] Login funciona (admin@example.com / admin123)
- [x] Pode registar novo utilizador
- [x] Vagas carregam corretamente
- [x] Admin dashboard mostra dados
- [x] Pode criar novo curso
- [x] Pode criar nova vaga
- [x] Dados persistem após refresh
- [x] API endpoints retornam JSON válido

---

## 🎯 Próximos Passos

1. **Teste o Login**: admin@example.com / admin123
2. **Crie um Novo Utilizador**: Vá para /registo
3. **Explore o Admin**: /admin
4. **Crie Dados de Teste**: Adicione cursos e vagas
5. **Faça Candidaturas**: Teste a candidatura a vagas

---

## 📞 Troubleshooting

### "Connection refused"
- Verifique se servidor está running
- Comandos: `php -S localhost:8010 index.php`

### "Data directory not found"
- Diretório é criado automaticamente
- Verifique permissões de escrita em `/api/`

### "Session already active"
- Erro foi corrigido! Sistema agora verifica antes de iniciar

### "PDF/CSS não carrega"
- Verifique URL no navegador
- Deve ser: `http://localhost:8010/SWPCF/...`

---

## 🎉 Tudo Pronto!

Seu sistema SWPCF está **100% operacional** e pronto para usar!

**Comande agora**: `http://localhost:8010/SWPCF/`
