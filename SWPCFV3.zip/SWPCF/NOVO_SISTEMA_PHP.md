# 🚀 NOVO SISTEMA PHP - INSTRUÇÕES

## O que foi feito?

Convertemos o projeto de um sistema JavaScript dinâmico para um **sistema PHP simples e robusto**.

### Mudanças principais:

1. **❌ Eliminado**: JavaScript loader (loader.js) que carregava navbar/footer dinamicamente
2. **✅ Criado**: `header.php` - Inclui navbar e tags HTML
3. **✅ Criado**: `footer.php` - Inclui footer e scripts
4. **✅ Criado**: Pasta `public/pages/` com 14 páginas PHP
5. **✅ Simplificado**: `index.php` - Router simples que monta página completa

## Estrutura nova

```
SWPCF/
├── index.php                    (Router principal)
├── public/
│   ├── pages/                   (Conteúdo das páginas)
│   │   ├── index.php            (Home)
│   │   ├── estagios.php
│   │   ├── sobre.php
│   │   └── ... (12 mais)
│   ├── includes/                (Componentes reutilizáveis)
│   │   ├── header.php           (Navbar + head HTML)
│   │   └── footer.php           (Footer + scripts)
│   └── css/public-style.css     (Estilos)
└── api/                         (APIs se necessário)
```

## Como funciona?

1. Utilizador acessa: `http://localhost:8000/SWPCF/`
2. PHP router (`index.php`) detecta a URL
3. Carrega `header.php` (com navbar)
4. Carrega a página específica (ex: `pages/estagios.php`)
5. Carrega `footer.php` (com footer)
6. Resultado: Página HTML completa com navbar e footer

## Como usar?

### Opção 1: PHP Built-in Server (Recomendado)

```bash
cd /home/lukenny-bastos/Downloads/swopf-main/SWPCF/SWPCF
php -S localhost:8000
```

Depois acesse: **http://localhost:8000/SWPCF/**

### Opção 2: Apache/XAMPP

Coloque o projeto em `htdocs/` e acesse via `http://localhost/SWPCF/`

## Rotas disponíveis

| URL | Página | Arquivo |
|-----|--------|---------|
| `/SWPCF/` | Home | `index.php` |
| `/SWPCF/estagios` | Estágios | `estagios.php` |
| `/SWPCF/vagas` | Vagas | `vagas.php` |
| `/SWPCF/formacoes` | Formações | `formacoes.php` |
| `/SWPCF/sobre` | Sobre | `sobre.php` |
| `/SWPCF/contactos` | Contactos | `contactos.php` |
| `/SWPCF/login` | Login | `login.php` |
| `/SWPCF/registo` | Registar | `registo.php` |
| `/SWPCF/dashboard` | Dashboard | `dashboard.php` |
| `/SWPCF/perfil` | Perfil | `perfil.php` |
| `/SWPCF/candidaturas` | Candidaturas | `candidaturas.php` |

## Como adicionar nova página?

1. Crie o arquivo `public/pages/nova-pagina.php`
2. Adicione a rota em `index.php`:
   ```php
   '/nova-pagina' => 'nova-pagina',
   ```
3. Pronto! Acesse via `http://localhost:8000/SWPCF/nova-pagina`

## Como modificar navbar/footer?

- **Navbar**: Edite `public/includes/header.php`
- **Footer**: Edite `public/includes/footer.php`

Ambas mudam em TODAS as páginas automaticamente.

## Arquivos removidos

❌ `/public/js/loader.js` - Não mais necessário
❌ `.htaccess` complexo - Não necessário com roteamento PHP

## Problemas resolvidos

✅ Navbar não aparecia → Agora carrega via PHP
✅ Páginas não carregavam → Roteamento PHP simples e confiável
✅ Assets estáticos falhavam → Caminhos relativos corrigidos
✅ JavaScript complexo → Eliminado, sistema PHP mais simples

## Próximos passos

1. Testar em http://localhost:8000/SWPCF/
2. Verificar navbar e footer aparecem
3. Testar links de navegação
4. Conectar com API/Database conforme necessário

## Troubleshooting

### Erro: "Página não encontrada"
- Verifique URL em `index.php` rotas
- Verifique arquivo existe em `public/pages/`

### Navbar/Footer não aparecem
- Verifique `header.php` e `footer.php` existem
- Verifique sintaxe do PHP

### Assets (CSS, JS) não carregam
- Verifique caminhos em `header.php` e `footer.php`
- Use caminhos absolutos: `/SWPCF/public/css/...`

---

**Sistema pronto! 🚀**
