<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers/storage_fallback.php';

$method = $_SERVER['REQUEST_METHOD'];
try {
    switch($method) {
        case 'GET':
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                if (isset($_GET['id'])) {
                    $stmt = $db->prepare("SELECT c.*, v.titulo as vaga_titulo FROM candidatura c LEFT JOIN vaga v ON c.vaga_id = v.id WHERE c.id = ?");
                    $stmt->execute([$_GET['id']]);
                    $item = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $item]);
                } elseif (isset($_GET['candidato_id'])) {
                    $stmt = $db->prepare("SELECT c.*, v.titulo as vaga_titulo FROM candidatura c LEFT JOIN vaga v ON c.vaga_id = v.id WHERE c.candidato_id = ? ORDER BY c.data_candidatura DESC");
                    $stmt->execute([$_GET['candidato_id']]);
                    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $items]);
                } else {
                    $stmt = $db->query("SELECT c.*, v.titulo as vaga_titulo, cand.nome as candidato_nome FROM candidatura c LEFT JOIN vaga v ON c.vaga_id = v.id LEFT JOIN candidato cand ON c.candidato_id = cand.id ORDER BY c.id DESC");
                    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $items]);
                }
            } else {
                $storage = new StorageFallback();
                $items = $storage->all('candidaturas');
                $vagas = $storage->all('vagas');
                $users = $storage->all('utilizadores');

                $vagaMap = [];
                foreach ($vagas as $v) {
                    $vagaMap[(int)($v['id'] ?? 0)] = $v;
                }
                $userMap = [];
                foreach ($users as $u) {
                    $userMap[(int)($u['id'] ?? 0)] = $u;
                }

                $enriched = array_map(function ($c) use ($vagaMap, $userMap) {
                    $vagaId = (int)($c['vaga_id'] ?? 0);
                    $candId = (int)($c['candidato_id'] ?? 0);
                    $c['vaga_titulo'] = $c['vaga_titulo'] ?? ($vagaMap[$vagaId]['titulo'] ?? '');
                    $c['candidato_nome'] = $c['candidato_nome'] ?? ($userMap[$candId]['nome'] ?? '');
                    return $c;
                }, $items);

                if (isset($_GET['id'])) {
                    $id = (int)$_GET['id'];
                    $item = null;
                    foreach ($enriched as $c) {
                        if ((int)($c['id'] ?? 0) === $id) {
                            $item = $c;
                            break;
                        }
                    }
                    echo json_encode(['success' => true, 'data' => $item]);
                } elseif (isset($_GET['candidato_id'])) {
                    $candidatoId = (int)$_GET['candidato_id'];
                    $filtered = array_values(array_filter($enriched, fn($c) => (int)($c['candidato_id'] ?? 0) === $candidatoId));
                    usort($filtered, fn($a, $b) => strcmp((string)($b['data_candidatura'] ?? ''), (string)($a['data_candidatura'] ?? '')));
                    echo json_encode(['success' => true, 'data' => $filtered]);
                } else {
                    usort($enriched, fn($a, $b) => (int)($b['id'] ?? 0) <=> (int)($a['id'] ?? 0));
                    echo json_encode(['success' => true, 'data' => $enriched]);
                }
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $db->prepare("INSERT INTO candidatura (candidato_id, vaga_id, status, notas) VALUES (?, ?, 'pendente', ?)");
                $stmt->execute([
                    $input['candidato_id'],
                    $input['vaga_id'],
                    $input['notas'] ?? ''
                ]);
                echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
            } else {
                $storage = new StorageFallback();
                $id = $storage->insert('candidaturas', [
                    'candidato_id' => (int)($input['candidato_id'] ?? 0),
                    'vaga_id' => (int)($input['vaga_id'] ?? 0),
                    'status' => $input['status'] ?? 'pendente',
                    'notas' => $input['notas'] ?? '',
                    'data_candidatura' => date('Y-m-d H:i:s')
                ]);
                echo json_encode(['success' => true, 'id' => $id]);
            }
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            $id = (int)($_GET['id'] ?? ($input['id'] ?? 0));
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $db->prepare("UPDATE candidatura SET status = ?, notas = ? WHERE id = ?");
                $stmt->execute([
                    $input['status'] ?? 'pendente',
                    $input['notas'] ?? '',
                    $id
                ]);
            } else {
                $storage = new StorageFallback();
                $storage->update('candidaturas', $id, [
                    'status' => $input['status'] ?? 'pendente',
                    'notas' => $input['notas'] ?? ''
                ]);
            }

            echo json_encode(['success' => true]);
            break;

        case 'DELETE':
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("DELETE FROM candidatura WHERE id = ?");
                $stmt->execute([$id]);
            } else {
                $storage = new StorageFallback();
                $items = $storage->all('candidaturas');
                $items = array_values(array_filter($items, fn($c) => (int)($c['id'] ?? 0) !== $id));
                $storage->saveAll('candidaturas', $items);
            }

            echo json_encode(['success' => true]);
            break;
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao processar candidaturas: ' . $e->getMessage()]);
}
