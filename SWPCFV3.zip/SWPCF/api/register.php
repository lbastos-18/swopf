<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers/storage_fallback.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$nome = $input['nome'] ?? '';
$email = $input['email'] ?? '';
$telefone = $input['telefone'] ?? '';
$password = $input['password'] ?? '';

if (empty($nome) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Nome, email e senha são obrigatórios']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'A senha deve ter pelo menos 6 caracteres']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Email inválido']);
    exit;
}

try {
    $userId = null;
    
    if (StorageFallback::hasMySqlDriver()) {
        $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stmt = $db->prepare("SELECT id FROM utilizadores WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Este email já está registado']);
            exit;
        }

        $senha_hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $db->prepare("INSERT INTO utilizadores (nome, email, telefone, senha, tipo, ativo) VALUES (?, ?, ?, ?, 'candidato', 1)");
        $stmt->execute([$nome, $email, $telefone, $senha_hash]);
        
        $userId = $db->lastInsertId();
    } else {
        $storage = new StorageFallback();
        $users = $storage->all('utilizadores');

        foreach ($users as $u) {
            if (strtolower((string)($u['email'] ?? '')) === strtolower($email)) {
                echo json_encode(['success' => false, 'message' => 'Este email já está registado']);
                exit;
            }
        }

        $userId = $storage->insert('utilizadores', [
            'nome' => $nome,
            'email' => $email,
            'telefone' => $telefone,
            'senha' => password_hash($password, PASSWORD_DEFAULT),
            'tipo' => 'candidato',
            'ativo' => 1,
            'criado_em' => date('Y-m-d H:i:s')
        ]);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Conta criada com sucesso',
        'user_id' => $userId
    ]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao criar conta: ' . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao criar conta: ' . $e->getMessage()]);
}
