<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers/storage_fallback.php';

$method = $_SERVER['REQUEST_METHOD'];
try {
    switch($method) {
        case 'GET':
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                if (isset($_GET['id'])) {
                    $stmt = $db->prepare("SELECT id, nome, email, telefone, tipo FROM utilizadores WHERE id = ?");
                    $stmt->execute([$_GET['id']]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $user]);
                } else {
                    $stmt = $db->query("SELECT id, nome, email, telefone, tipo, ativo FROM utilizadores ORDER BY id DESC");
                    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $users]);
                }
            } else {
                $storage = new StorageFallback();
                $users = $storage->all('utilizadores');
                if (isset($_GET['id'])) {
                    $user = $storage->findById('utilizadores', (int)$_GET['id']);
                    if ($user) {
                        unset($user['senha']);
                    }
                    echo json_encode(['success' => true, 'data' => $user]);
                } else {
                    $users = array_map(function($u) {
                        unset($u['senha']);
                        return $u;
                    }, $users);
                    usort($users, fn($a, $b) => (int)($b['id'] ?? 0) <=> (int)($a['id'] ?? 0));
                    echo json_encode(['success' => true, 'data' => $users]);
                }
            }
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            $id = (int)($_GET['id'] ?? ($input['id'] ?? 0));

            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $fields = [];
                $params = [];

                if (isset($input['nome'])) {
                    $fields[] = 'nome = ?';
                    $params[] = $input['nome'];
                }
                if (isset($input['email'])) {
                    $fields[] = 'email = ?';
                    $params[] = $input['email'];
                }
                if (isset($input['telefone'])) {
                    $fields[] = 'telefone = ?';
                    $params[] = $input['telefone'];
                }
                if (isset($input['senha']) && !empty($input['senha'])) {
                    $fields[] = 'senha = ?';
                    $params[] = password_hash($input['senha'], PASSWORD_DEFAULT);
                }

                $params[] = $id;

                if (count($fields) > 0) {
                    $sql = "UPDATE utilizadores SET " . implode(', ', $fields) . " WHERE id = ?";
                    $stmt = $db->prepare($sql);
                    $stmt->execute($params);
                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Nenhum campo para atualizar']);
                }
            } else {
                $storage = new StorageFallback();
                $payload = [];
                if (isset($input['nome'])) $payload['nome'] = $input['nome'];
                if (isset($input['email'])) $payload['email'] = $input['email'];
                if (isset($input['telefone'])) $payload['telefone'] = $input['telefone'];
                if (!empty($input['senha'])) $payload['senha'] = password_hash($input['senha'], PASSWORD_DEFAULT);

                if (count($payload) === 0) {
                    echo json_encode(['success' => false, 'message' => 'Nenhum campo para atualizar']);
                    exit;
                }

                $ok = $storage->update('utilizadores', $id, $payload);
                echo json_encode(['success' => $ok]);
            }
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Método não suportado']);
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao processar utilizadores: ' . $e->getMessage()]);
}
