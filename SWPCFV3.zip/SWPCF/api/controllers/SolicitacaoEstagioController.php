<?php

class SolicitacaoEstagioController
{
    private $model;
    private $db;

    public function __construct()
    {
        $this->model = new SolicitacaoEstagio();
        $this->db = Database::getInstance();
    }

    /**
     * POST /api/solicitacoes-estagios
     * Criar nova solicitação (escola)
     */
    public function criar()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return error('Método não permitido', [], 405);
        }

        try {
            $data = json_decode(file_get_contents('php://input'), true);

            // Validação
            if (empty($data['escola_id']) || empty($data['curso_id']) || empty($data['titulo'])) {
                return error('Campos obrigatórios ausentes');
            }

            if (empty($data['periodo_inicio']) || empty($data['periodo_fim'])) {
                return error('Período é obrigatório');
            }

            if ($data['periodo_inicio'] > $data['periodo_fim']) {
                return error('Data de fim não pode ser anterior ao início');
            }

            // Verificar se escola existe
            $escola = $this->db->fetch("SELECT id FROM escolas WHERE id = ?", [$data['escola_id']]);
            if (!$escola) {
                return error('Escola não encontrada', [], 404);
            }

            // Verificar se curso existe
            $curso = $this->db->fetch("SELECT id FROM curso WHERE id = ?", [$data['curso_id']]);
            if (!$curso) {
                return error('Curso não encontrado', [], 404);
            }

            // Criar solicitação
            $resultado = $this->model->create([
                'escola_id' => $data['escola_id'],
                'curso_id' => $data['curso_id'],
                'titulo' => $data['titulo'],
                'descricao' => $data['descricao'] ?? null,
                'vagas_quantidade' => $data['vagas_quantidade'] ?? 1,
                'periodo_inicio' => $data['periodo_inicio'],
                'periodo_fim' => $data['periodo_fim'],
                'status' => 'pendente',
                'criado_por' => $_SESSION['user_id'] ?? null
            ]);

            return success([
                'id' => $this->db->lastInsertId(),
                'mensagem' => 'Solicitação criada com sucesso. Aguardando aprovação.'
            ], 'Solicitação criada', 201);

        } catch (Exception $e) {
            return error('Erro ao criar solicitação: ' . $e->getMessage());
        }
    }

    /**
     * GET /api/solicitacoes-estagios
     * Listar solicitações
     */
    public function listar()
    {
        try {
            $tipo = $_GET['tipo'] ?? 'todas'; // todas, pendentes, aprovadas
            $escola_id = $_GET['escola_id'] ?? null;

            $dados = [];

            if ($tipo === 'pendentes') {
                $dados = $this->model->getPendentes();
            } elseif ($tipo === 'aprovadas') {
                $dados = $this->model->getAprovadas();
            } elseif ($escola_id) {
                $dados = $this->model->getByEscola($escola_id);
            } else {
                $dados = $this->model->withRelations();
            }

            return success($dados, 'Solicitações listadas');

        } catch (Exception $e) {
            return error('Erro ao listar solicitações: ' . $e->getMessage());
        }
    }

    /**
     * GET /api/solicitacoes-estagios/:id
     * Obter solicitação específica
     */
    public function obter($id)
    {
        try {
            $solicitacao = $this->model->withRelations($id);

            if (!$solicitacao) {
                return error('Solicitação não encontrada', [], 404);
            }

            return success($solicitacao);

        } catch (Exception $e) {
            return error('Erro ao obter solicitação: ' . $e->getMessage());
        }
    }

    /**
     * PUT /api/solicitacoes-estagios/:id/aprovar
     * Aprovar solicitação (admin)
     */
    public function aprovar($id)
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
            return error('Método não permitido', [], 405);
        }

        try {
            // Verificar se é admin
            if ($_SESSION['user_type'] !== 'admin') {
                return error('Acesso negado', [], 403);
            }

            $solicitacao = $this->model->obter($id);
            if (!$solicitacao) {
                return error('Solicitação não encontrada', [], 404);
            }

            if ($solicitacao['status'] !== 'pendente') {
                return error('Apenas solicitações pendentes podem ser aprovadas');
            }

            $this->model->aprovar($id, $_SESSION['user_id']);

            return success(['id' => $id], 'Solicitação aprovada com sucesso');

        } catch (Exception $e) {
            return error('Erro ao aprovar: ' . $e->getMessage());
        }
    }

    /**
     * PUT /api/solicitacoes-estagios/:id/rejeitar
     * Rejeitar solicitação (admin)
     */
    public function rejeitar($id)
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
            return error('Método não permitido', [], 405);
        }

        try {
            // Verificar se é admin
            if ($_SESSION['user_type'] !== 'admin') {
                return error('Acesso negado', [], 403);
            }

            $data = json_decode(file_get_contents('php://input'), true);
            $motivo = $data['motivo'] ?? 'Solicitação rejeitada pelo administrador';

            $solicitacao = $this->model->obter($id);
            if (!$solicitacao) {
                return error('Solicitação não encontrada', [], 404);
            }

            if ($solicitacao['status'] !== 'pendente') {
                return error('Apenas solicitações pendentes podem ser rejeitadas');
            }

            $this->model->rejeitar($id, $motivo, $_SESSION['user_id']);

            return success(['id' => $id], 'Solicitação rejeitada');

        } catch (Exception $e) {
            return error('Erro ao rejeitar: ' . $e->getMessage());
        }
    }

    /**
     * GET /api/solicitacoes-estagios/escola/:id
     * Listar solicitações da escola (visão da escola)
     */
    public function porEscola($escola_id)
    {
        try {
            $status = $_GET['status'] ?? null;
            $dados = $this->model->getByEscola($escola_id, $status);

            return success($dados);

        } catch (Exception $e) {
            return error('Erro ao listar solicitações: ' . $e->getMessage());
        }
    }

    /**
     * GET /api/solicitacoes-estagios/curso/:id/aprovadas
     * Solicitações aprovadas por curso (para alunos)
     */
    public function approvadasPorCurso($curso_id)
    {
        try {
            $dados = $this->model->getAprovadosPorCurso($curso_id);
            return success($dados);

        } catch (Exception $e) {
            return error('Erro ao listar solicitações: ' . $e->getMessage());
        }
    }

    /**
     * DELETE /api/solicitacoes-estagios/:id
     * Cancelar solicitação (escola ou admin)
     */
    public function cancelar($id)
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
            return error('Método não permitido', [], 405);
        }

        try {
            $data = json_decode(file_get_contents('php://input'), true);
            $motivo = $data['motivo'] ?? null;

            $solicitacao = $this->model->obter($id);
            if (!$solicitacao) {
                return error('Solicitação não encontrada', [], 404);
            }

            // Apenas escola ou admin podem cancelar
            if ($solicitacao['status'] === 'cancelada' || $solicitacao['status'] === 'rejeitada') {
                return error('Esta solicitação não pode ser cancelada');
            }

            $this->model->cancelar($id, $motivo);

            return success(['id' => $id], 'Solicitação cancelada');

        } catch (Exception $e) {
            return error('Erro ao cancelar: ' . $e->getMessage());
        }
    }

    /**
     * GET /api/solicitacoes-estagios/stats
     * Estatísticas
     */
    public function stats()
    {
        try {
            $stats = $this->model->getStats();
            return success($stats);

        } catch (Exception $e) {
            return error('Erro ao obter estatísticas: ' . $e->getMessage());
        }
    }
}
