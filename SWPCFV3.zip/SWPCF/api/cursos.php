<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers/storage_fallback.php';

$method = $_SERVER['REQUEST_METHOD'];
try {
    switch($method) {
        case 'GET':
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                if (isset($_GET['id'])) {
                    $stmt = $db->prepare("SELECT * FROM curso WHERE id = ?");
                    $stmt->execute([$_GET['id']]);
                    $curso = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $curso]);
                } else {
                    $stmt = $db->query("SELECT * FROM curso WHERE ativo = 1 ORDER BY nome ASC");
                    $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $cursos]);
                }
            } else {
                $storage = new StorageFallback();
                $cursos = array_values(array_filter($storage->all('cursos'), fn($c) => (int)($c['ativo'] ?? 1) === 1));

                if (isset($_GET['id'])) {
                    $curso = $storage->findById('cursos', (int)$_GET['id']);
                    echo json_encode(['success' => true, 'data' => $curso]);
                } else {
                    usort($cursos, fn($a, $b) => strcmp((string)($a['nome'] ?? ''), (string)($b['nome'] ?? '')));
                    echo json_encode(['success' => true, 'data' => $cursos]);
                }
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $db->prepare("INSERT INTO curso (nome, descricao, duracao_meses) VALUES (?, ?, ?)");
                $stmt->execute([
                    $input['nome'],
                    $input['descricao'] ?? '',
                    $input['duracao'] ?? 1
                ]);
                echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
            } else {
                $storage = new StorageFallback();
                $id = $storage->insert('cursos', [
                    'nome' => $input['nome'] ?? '',
                    'descricao' => $input['descricao'] ?? '',
                    'duracao' => (int)($input['duracao'] ?? 1),
                    'vagas' => (int)($input['vagas'] ?? 1),
                    'ativo' => 1
                ]);
                echo json_encode(['success' => true, 'id' => $id]);
            }
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $db->prepare("UPDATE curso SET nome = ?, descricao = ?, duracao_meses = ? WHERE id = ?");
                $stmt->execute([
                    $input['nome'],
                    $input['descricao'] ?? '',
                    $input['duracao'] ?? 1,
                    $id
                ]);
            } else {
                $storage = new StorageFallback();
                $storage->update('cursos', $id, [
                    'nome' => $input['nome'] ?? '',
                    'descricao' => $input['descricao'] ?? '',
                    'duracao' => (int)($input['duracao'] ?? 1),
                    'vagas' => (int)($input['vagas'] ?? 1)
                ]);
            }

            echo json_encode(['success' => true]);
            break;

        case 'DELETE':
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE curso SET ativo = 0 WHERE id = ?");
                $stmt->execute([$id]);
            } else {
                $storage = new StorageFallback();
                $storage->update('cursos', $id, ['ativo' => 0]);
            }

            echo json_encode(['success' => true]);
            break;
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao processar cursos: ' . $e->getMessage()]);
}
