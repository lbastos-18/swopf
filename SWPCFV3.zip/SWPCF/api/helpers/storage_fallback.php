<?php
/**
 * Armazenamento fallback em JSON quando o driver MySQL não está disponível.
 */

class StorageFallback
{
    private string $dataDir;

    public function __construct()
    {
        $this->dataDir = dirname(__DIR__) . '/data';
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0775, true);
        }
        $this->ensureSeeds();
    }

    public static function hasMySqlDriver(): bool
    {
        return extension_loaded('pdo_mysql');
    }

    private function filePath(string $collection): string
    {
        return $this->dataDir . '/' . $collection . '.json';
    }

    public function all(string $collection): array
    {
        $path = $this->filePath($collection);
        if (!file_exists($path)) {
            return [];
        }

        $content = file_get_contents($path);
        if ($content === false || trim($content) === '') {
            return [];
        }

        $decoded = json_decode($content, true);
        return is_array($decoded) ? $decoded : [];
    }

    public function saveAll(string $collection, array $rows): void
    {
        $path = $this->filePath($collection);
        file_put_contents(
            $path,
            json_encode(array_values($rows), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    public function findById(string $collection, int $id): ?array
    {
        foreach ($this->all($collection) as $row) {
            if ((int)($row['id'] ?? 0) === $id) {
                return $row;
            }
        }
        return null;
    }

    public function insert(string $collection, array $payload): int
    {
        $rows = $this->all($collection);
        $maxId = 0;
        foreach ($rows as $r) {
            $maxId = max($maxId, (int)($r['id'] ?? 0));
        }
        $id = $maxId + 1;
        $payload['id'] = $id;
        $rows[] = $payload;
        $this->saveAll($collection, $rows);
        return $id;
    }

    public function update(string $collection, int $id, array $payload): bool
    {
        $rows = $this->all($collection);
        $updated = false;

        foreach ($rows as &$row) {
            if ((int)($row['id'] ?? 0) === $id) {
                $row = array_merge($row, $payload, ['id' => $id]);
                $updated = true;
                break;
            }
        }

        if ($updated) {
            $this->saveAll($collection, $rows);
        }

        return $updated;
    }

    private function ensureSeeds(): void
    {
        $utilizadores = $this->all('utilizadores');
        if (count($utilizadores) === 0) {
            $this->saveAll('utilizadores', [
                [
                    'id' => 1,
                    'nome' => 'Administrador',
                    'email' => 'admin@swpcf.ao',
                    'telefone' => '',
                    'senha' => password_hash('admin123', PASSWORD_DEFAULT),
                    'tipo' => 'admin',
                    'ativo' => 1,
                    'criado_em' => date('Y-m-d H:i:s')
                ]
            ]);
        }

        $cursos = $this->all('cursos');
        if (count($cursos) === 0) {
            $this->saveAll('cursos', [
                [
                    'id' => 1,
                    'nome' => 'Programação Python',
                    'descricao' => 'Fundamentos e prática de Python',
                    'duracao' => 3,
                    'vagas' => 28,
                    'ativo' => 1
                ],
                [
                    'id' => 2,
                    'nome' => 'Desenvolvimento Web',
                    'descricao' => 'HTML, CSS, JavaScript e PHP',
                    'duracao' => 4,
                    'vagas' => 20,
                    'ativo' => 1
                ]
            ]);
        }

        $vagas = $this->all('vagas');
        if (count($vagas) === 0) {
            $this->saveAll('vagas', [
                [
                    'id' => 1,
                    'estagio_id' => 1,
                    'titulo' => 'Programador Full Stack',
                    'posicao' => 'Programador Full Stack',
                    'empresa' => 'TechCorp',
                    'local' => 'Luanda',
                    'descricao' => 'Vaga para estágio em desenvolvimento full stack',
                    'quantidade' => 5,
                    'vagas_disponiveis' => 5,
                    'ativa' => 1,
                    'criado_em' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 2,
                    'estagio_id' => 1,
                    'titulo' => 'Designer Gráfico',
                    'posicao' => 'Designer Gráfico',
                    'empresa' => 'Creative Solutions',
                    'local' => 'Bengo',
                    'descricao' => 'Vaga para estágio em design',
                    'quantidade' => 3,
                    'vagas_disponiveis' => 3,
                    'ativa' => 1,
                    'criado_em' => date('Y-m-d H:i:s')
                ]
            ]);
        }

        if (count($this->all('candidaturas')) === 0) {
            $this->saveAll('candidaturas', []);
        }
    }
}
