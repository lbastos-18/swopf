<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/helpers/storage_fallback.php';

$method = $_SERVER['REQUEST_METHOD'];
try {
    switch($method) {
        case 'GET':
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                if (isset($_GET['id'])) {
                    $stmt = $db->prepare("SELECT * FROM vaga WHERE id = ?");
                    $stmt->execute([$_GET['id']]);
                    $vaga = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $vaga]);
                } else {
                    $stmt = $db->query("SELECT v.*, e.titulo as estagio_titulo FROM vaga v LEFT JOIN estagio e ON v.estagio_id = e.id WHERE v.ativa = 1 ORDER BY v.id DESC");
                    $vagas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    echo json_encode(['success' => true, 'data' => $vagas]);
                }
            } else {
                $storage = new StorageFallback();
                if (isset($_GET['id'])) {
                    $vaga = $storage->findById('vagas', (int)$_GET['id']);
                    echo json_encode(['success' => true, 'data' => $vaga]);
                } else {
                    $vagas = array_values(array_filter($storage->all('vagas'), fn($v) => (int)($v['ativa'] ?? 1) === 1));
                    usort($vagas, fn($a, $b) => (int)($b['id'] ?? 0) <=> (int)($a['id'] ?? 0));
                    echo json_encode(['success' => true, 'data' => $vagas]);
                }
            }
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $db->prepare("INSERT INTO vaga (estagio_id, titulo, descricao, quantidade) VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $input['estagio_id'] ?? 1,
                    $input['posicao'] ?? $input['titulo'],
                    $input['descricao'] ?? '',
                    $input['vagas_disponiveis'] ?? $input['quantidade'] ?? 1
                ]);
                echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
            } else {
                $storage = new StorageFallback();
                $titulo = $input['posicao'] ?? ($input['titulo'] ?? 'Vaga');
                $quantidade = (int)($input['vagas_disponiveis'] ?? ($input['quantidade'] ?? 1));
                $id = $storage->insert('vagas', [
                    'estagio_id' => (int)($input['estagio_id'] ?? 1),
                    'titulo' => $titulo,
                    'posicao' => $titulo,
                    'empresa' => $input['empresa'] ?? '',
                    'local' => $input['local'] ?? '',
                    'descricao' => $input['descricao'] ?? '',
                    'quantidade' => $quantidade,
                    'vagas_disponiveis' => $quantidade,
                    'ativa' => 1,
                    'criado_em' => date('Y-m-d H:i:s')
                ]);
                echo json_encode(['success' => true, 'id' => $id]);
            }
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $db->prepare("UPDATE vaga SET titulo = ?, descricao = ?, quantidade = ? WHERE id = ?");
                $stmt->execute([
                    $input['posicao'] ?? $input['titulo'],
                    $input['descricao'] ?? '',
                    $input['vagas_disponiveis'] ?? $input['quantidade'] ?? 1,
                    $id
                ]);
            } else {
                $storage = new StorageFallback();
                $titulo = $input['posicao'] ?? ($input['titulo'] ?? 'Vaga');
                $quantidade = (int)($input['vagas_disponiveis'] ?? ($input['quantidade'] ?? 1));
                $storage->update('vagas', $id, [
                    'titulo' => $titulo,
                    'posicao' => $titulo,
                    'empresa' => $input['empresa'] ?? '',
                    'local' => $input['local'] ?? '',
                    'descricao' => $input['descricao'] ?? '',
                    'quantidade' => $quantidade,
                    'vagas_disponiveis' => $quantidade
                ]);
            }

            echo json_encode(['success' => true]);
            break;

        case 'DELETE':
            $id = (int)($_GET['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID não fornecido']);
                exit;
            }

            if (StorageFallback::hasMySqlDriver()) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stmt = $db->prepare("UPDATE vaga SET ativa = 0 WHERE id = ?");
                $stmt->execute([$id]);
            } else {
                $storage = new StorageFallback();
                $storage->update('vagas', $id, ['ativa' => 0]);
            }

            echo json_encode(['success' => true]);
            break;
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao processar vagas: ' . $e->getMessage()]);
}
