<?php


require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/helpers/functions.php';
require_once __DIR__ . '/middleware/Auth.php';

handleCORS();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    // Inicializar DB
    $db = Database::getInstance();
    $pdo = $db->getConnection();

    // Receber campos básicos
    $curso_id = isset($_POST['curso_id']) ? (int)$_POST['curso_id'] : null;
    $nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $documento = isset($_POST['documento']) ? trim($_POST['documento']) : '';

    if (empty($curso_id) || empty($nome) || empty($email) || empty($documento)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Campos obrigatórios em falta']);
        exit;
    }

    // Identificar usuário (opcional) via token
    $user_id = null;
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    if (!empty($headers['Authorization'])) {
        try {
            $decoded = AuthMiddleware::verifyToken();
            $user_id = $decoded['id'] ?? null;
        } catch (Exception $e) {
            // token inválido -> ignorar (permitir sem auth)
            $user_id = null;
        }
    }

    // Preparar uploads
    $allowed = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    $maxBytes = 5 * 1024 * 1024; // 5 MB

    $uploadDir = UPLOADS_DIR . '/inscricoes';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $docPath = null;
    if (isset($_FILES['docCopy']) && $_FILES['docCopy']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['docCopy'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Erro no upload do documento');
        }
        if ($file['size'] > $maxBytes) {
            throw new Exception('Ficheiro demasiado grande');
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowed)) {
            throw new Exception('Tipo de ficheiro não permitido');
        }
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $safeName = 'insc_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
        $dest = $uploadDir . '/' . $safeName;
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            throw new Exception('Falha a mover ficheiro');
        }
        $docPath = str_replace(dirname(__DIR__), '', $dest); // caminho relativo
    }

    $paymentPath = null;
    if (isset($_FILES['paymentProof']) && $_FILES['paymentProof']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['paymentProof'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Erro no upload do comprovativo');
        }
        if ($file['size'] > $maxBytes) {
            throw new Exception('Ficheiro demasiado grande');
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowed)) {
            throw new Exception('Tipo de ficheiro não permitido');
        }
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $safeName = 'pay_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
        $dest = $uploadDir . '/' . $safeName;
        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            throw new Exception('Falha a mover ficheiro');
        }
        $paymentPath = str_replace(dirname(__DIR__), '', $dest);
    }

    // Garantir tabela de inscricoes (evita falha em bases ainda nao migradas)
    $pdo->exec("CREATE TABLE IF NOT EXISTS inscricoes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        curso_id INT NOT NULL,
        user_id INT NULL,
        nome VARCHAR(150) NOT NULL,
        email VARCHAR(150) NOT NULL,
        documento VARCHAR(100) NOT NULL,
        doc_copy VARCHAR(255),
        payment_proof VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (curso_id),
        INDEX (user_id),
        FOREIGN KEY (curso_id) REFERENCES curso(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES utilizadores(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Inserir na base de dados
    $sql = "INSERT INTO inscricoes (curso_id, user_id, nome, email, documento, doc_copy, payment_proof, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $pdo->prepare($sql);
    $ok = $stmt->execute([
        $curso_id,
        $user_id,
        $nome,
        $email,
        $documento,
        $docPath,
        $paymentPath
    ]);

    if (!$ok) {
        throw new Exception('Erro ao gravar inscrição');
    }

    $insertedId = $pdo->lastInsertId();

    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => true, 'id' => $insertedId, 'message' => 'Inscrição recebida']);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    exit;
}
