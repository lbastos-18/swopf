<?php

class SolicitacaoEstagio extends BaseModel
{
    protected $table = 'solicitacoes_estagios';
    protected $fillable = [
        'escola_id',
        'curso_id',
        'titulo',
        'descricao',
        'vagas_quantidade',
        'periodo_inicio',
        'periodo_fim',
        'status',
        'motivo_rejeicao',
        'criado_por',
        'aprovado_por',
        'data_aprovacao'
    ];

    /**
     * Obter solicitações com relações (escola e curso)
     */
    public function withRelations($id = null)
    {
        $sql = "SELECT se.*,
                    e.nome as escola_nome, e.email as escola_email, e.responsavel as escola_responsavel,
                    c.nome as curso_nome,
                    u.nome as criado_por_nome,
                    ua.nome as aprovado_por_nome
                FROM {$this->table} se
                LEFT JOIN escolas e ON se.escola_id = e.id
                LEFT JOIN curso c ON se.curso_id = c.id
                LEFT JOIN utilizador u ON se.criado_por = u.id
                LEFT JOIN utilizador ua ON se.aprovado_por = ua.id";

        if ($id) {
            $sql .= " WHERE se.id = ?";
            return $this->db->fetch($sql, [$id]);
        }

        $sql .= " ORDER BY se.criado_em DESC";
        return $this->db->fetchAll($sql);
    }

    /**
     * Obter solicitações por escola
     */
    public function getByEscola($escola_id, $status = null)
    {
        $sql = "SELECT se.*,
                    c.nome as curso_nome,
                    COUNT(DISTINCT cand.id) as total_candidatos
                FROM {$this->table} se
                LEFT JOIN curso c ON se.curso_id = c.id
                LEFT JOIN candidatura cand ON se.id = cand.solicitacao_id AND cand.status = 'aceite'
                WHERE se.escola_id = ?";

        $params = [$escola_id];

        if ($status) {
            $sql .= " AND se.status = ?";
            $params[] = $status;
        }

        $sql .= " GROUP BY se.id ORDER BY se.criado_em DESC";
        return $this->db->fetchAll($sql, $params);
    }

    /**
     * Obter solicitações aprovadas por curso
     */
    public function getAprovadosPorCurso($curso_id)
    {
        $sql = "SELECT se.*,
                    e.nome as escola_nome, e.email as escola_email,
                    COUNT(DISTINCT cand.id) as total_candidatos
                FROM {$this->table} se
                INNER JOIN escolas e ON se.escola_id = e.id
                LEFT JOIN candidatura cand ON se.id = cand.solicitacao_id AND cand.status = 'aceite'
                WHERE se.curso_id = ? AND se.status = 'aprovada'
                AND se.periodo_inicio <= CURDATE() AND se.periodo_fim >= CURDATE()
                GROUP BY se.id
                ORDER BY se.criado_em DESC";

        return $this->db->fetchAll($sql, [$curso_id]);
    }

    /**
     * Obter todas as solicitações aprovadas (para alunos)
     */
    public function getAprovadas()
    {
        $sql = "SELECT se.*,
                    e.nome as escola_nome, e.email as escola_email,
                    c.nome as curso_nome,
                    COUNT(DISTINCT cand.id) as total_candidatos
                FROM {$this->table} se
                INNER JOIN escolas e ON se.escola_id = e.id
                INNER JOIN curso c ON se.curso_id = c.id
                LEFT JOIN candidatura cand ON se.id = cand.solicitacao_id AND cand.status = 'aceite'
                WHERE se.status = 'aprovada'
                AND se.periodo_inicio <= CURDATE() AND se.periodo_fim >= CURDATE()
                GROUP BY se.id
                ORDER BY se.criado_em DESC";

        return $this->db->fetchAll($sql);
    }

    /**
     * Obter solicitações pendentes (para admin)
     */
    public function getPendentes()
    {
        $sql = "SELECT se.*,
                    e.nome as escola_nome, e.email as escola_email, e.responsavel,
                    c.nome as curso_nome,
                    u.nome as criado_por_nome
                FROM {$this->table} se
                LEFT JOIN escolas e ON se.escola_id = e.id
                LEFT JOIN curso c ON se.curso_id = c.id
                LEFT JOIN utilizador u ON se.criado_por = u.id
                WHERE se.status = 'pendente'
                ORDER BY se.criado_em ASC";

        return $this->db->fetchAll($sql);
    }

    /**
     * Aprovar solicitação
     */
    public function aprovar($id, $admin_id)
    {
        $data = [
            'status' => 'aprovada',
            'aprovado_por' => $admin_id,
            'data_aprovacao' => date('Y-m-d H:i:s')
        ];

        return $this->update($id, $data);
    }

    /**
     * Rejeitar solicitação
     */
    public function rejeitar($id, $motivo, $admin_id)
    {
        $data = [
            'status' => 'rejeitada',
            'motivo_rejeicao' => $motivo,
            'aprovado_por' => $admin_id,
            'data_aprovacao' => date('Y-m-d H:i:s')
        ];

        return $this->update($id, $data);
    }

    /**
     * Cancelar solicitação
     */
    public function cancelar($id, $motivo = null)
    {
        $data = ['status' => 'cancelada'];
        
        if ($motivo) {
            $data['motivo_rejeicao'] = $motivo;
        }

        return $this->update($id, $data);
    }

    /**
     * Estatísticas das solicitações
     */
    public function getStats()
    {
        $sql = "SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END) as pendentes,
                    SUM(CASE WHEN status = 'aprovada' THEN 1 ELSE 0 END) as aprovadas,
                    SUM(CASE WHEN status = 'rejeitada' THEN 1 ELSE 0 END) as rejeitadas,
                    SUM(vagas_quantidade) as total_vagas
                FROM {$this->table}
                WHERE status = 'aprovada'";

        return $this->db->fetch($sql);
    }
}
