<?php

// Headers de resposta
header('Content-Type: application/json; charset=utf-8');

// Carregar configurações e helpers
require_once 'config/database.php';
require_once 'config/Database.php';
require_once 'helpers/functions.php';
require_once 'helpers/ValidadorAngola.php';
require_once 'middleware/Auth.php';

// Carregar Models
require_once 'models/BaseModel.php';
require_once 'models/Utilizador.php';
require_once 'models/Curso.php';
require_once 'models/Estagio.php';
require_once 'models/Escola.php';
require_once 'models/Candidato.php';
require_once 'models/Candidatura.php';
require_once 'models/Documento.php';
require_once 'models/AlunosCurso.php';
require_once 'models/ListasEspera.php';
require_once 'models/Notificacao.php';
require_once 'models/SolicitacaoEstagio.php';

// Carregar Controllers
require_once 'controllers/UtilizadorController.php';
require_once 'controllers/CursoController.php';
require_once 'controllers/EstagioController.php';
require_once 'controllers/EscolaController.php';
require_once 'controllers/CandidatoController.php';
require_once 'controllers/CandidaturaController.php';
require_once 'controllers/DocumentoController.php';
require_once 'controllers/RelatorioController.php';
require_once 'controllers/AlunoController.php';
require_once 'controllers/AlunosAdminController.php';
require_once 'controllers/SolicitacaoEstagioController.php';

// CORS e segurança
handleCORS();

// Inicializar sessão
session_start();

// Obter rota
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace('/SWPCF/api', '', $path);
$path = trim($path, '/');
// Suportar formato legacy: ?endpoint=rota/subrota
if (isset($_GET['endpoint']) && !empty($_GET['endpoint'])) {
    $path = trim($_GET['endpoint'], '/');
}

// Roteador simples
try {
    // Autenticação
    if ($path === 'auth/register') {
        $controller = new UtilizadorController();
        $controller->register();
    }
    elseif ($path === 'auth/register-candidato') {
        $controller = new UtilizadorController();
        $controller->registerCandidato();
    }
    elseif ($path === 'auth/login') {
        $controller = new UtilizadorController();
        $controller->login();
    }

    // Cursos
    elseif ($path === 'cursos' && $method === 'GET') {
        $controller = new CursoController();
        $controller->index();
    }
    elseif ($path === 'cursos' && $method === 'POST') {
        $controller = new CursoController();
        $controller->store();
    }
    elseif (preg_match('/^cursos\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new CursoController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^cursos\/(\d+)$/', $path, $matches) && $method === 'PUT') {
        $controller = new CursoController();
        $controller->update($matches[1]);
    }
    elseif (preg_match('/^cursos\/(\d+)$/', $path, $matches) && $method === 'DELETE') {
        $controller = new CursoController();
        $controller->destroy($matches[1]);
    }
    elseif ($path === 'cursos/stats') {
        $controller = new CursoController();
        $controller->stats();
    }

    // Estágios (novo - substituindo vagas)
    elseif ($path === 'estagios' && $method === 'GET') {
        $controller = new EstagioController();
        $controller->index();
    }
    elseif ($path === 'estagios' && $method === 'POST') {
        $controller = new EstagioController();
        $controller->store();
    }
    elseif (preg_match('/^estagios\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new EstagioController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^estagios\/(\d+)$/', $path, $matches) && $method === 'PUT') {
        $controller = new EstagioController();
        $controller->update($matches[1]);
    }
    elseif (preg_match('/^estagios\/(\d+)$/', $path, $matches) && $method === 'DELETE') {
        $controller = new EstagioController();
        $controller->delete($matches[1]);
    }
    elseif (preg_match('/^estagios\/(\d+)\/close$/', $path, $matches) && $method === 'PUT') {
        $controller = new EstagioController();
        $controller->close($matches[1]);
    }
    elseif ($path === 'estagios/stats') {
        $controller = new EstagioController();
        $controller->getStats();
    }

    // Escolas Parceiras
    elseif ($path === 'escolas' && $method === 'GET') {
        $controller = new EscolaController();
        $controller->index();
    }
    elseif ($path === 'escolas' && $method === 'POST') {
        $controller = new EscolaController();
        $controller->store();
    }
    elseif (preg_match('/^escolas\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new EscolaController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^escolas\/(\d+)$/', $path, $matches) && $method === 'PUT') {
        $controller = new EscolaController();
        $controller->update($matches[1]);
    }
    elseif (preg_match('/^escolas\/(\d+)\/status$/', $path, $matches) && $method === 'PUT') {
        $controller = new EscolaController();
        $controller->updateStatus($matches[1]);
    }
    elseif ($path === 'escolas/ativas') {
        $controller = new EscolaController();
        $controller->getActive();
    }
    elseif ($path === 'escolas/stats') {
        $controller = new EscolaController();
        $controller->getStats();
    }

    // Candidatos
    elseif ($path === 'candidatos' && $method === 'GET') {
        $controller = new CandidatoController();
        $controller->index();
    }
    elseif (preg_match('/^candidatos\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new CandidatoController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^candidatos\/(\d+)$/', $path, $matches) && $method === 'PUT') {
        $controller = new CandidatoController();
        $controller->updateProfile($matches[1]);
    }
    elseif (preg_match('/^candidatos\/(\d+)\/cv$/', $path, $matches) && $method === 'POST') {
        $controller = new CandidatoController();
        $controller->uploadCV($matches[1]);
    }
    elseif ($path === 'candidatos/stats') {
        $controller = new CandidatoController();
        $controller->stats();
    }

    // Candidaturas
    elseif ($path === 'candidaturas' && $method === 'GET') {
        $controller = new CandidaturaController();
        $controller->index();
    }
    elseif ($path === 'candidaturas' && $method === 'POST') {
        $controller = new CandidaturaController();
        $controller->store();
    }
    elseif (preg_match('/^candidaturas\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new CandidaturaController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^candidaturas\/(\d+)$/', $path, $matches) && $method === 'PUT') {
        $controller = new CandidaturaController();
        $controller->updateStatus($matches[1]);
    }
    elseif (preg_match('/^candidaturas\/(\d+)$/', $path, $matches) && $method === 'DELETE') {
        $controller = new CandidaturaController();
        $controller->destroy($matches[1]);
    }
    elseif ($path === 'candidaturas/minhas' && $method === 'GET') {
        $controller = new CandidaturaController();
        $controller->getMyCandidaturas();
    }
    elseif ($path === 'candidaturas/stats') {
        $controller = new CandidaturaController();
        $controller->stats();
    }

    // Documentos - Upload e Validação
    elseif ($path === 'documentos' && $method === 'GET') {
        $controller = new DocumentoController();
        $controller->index();
    }
    elseif ($path === 'documentos' && $method === 'POST') {
        $controller = new DocumentoController();
        $controller->upload();
    }
    elseif (preg_match('/^documentos\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new DocumentoController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^documentos\/(\d+)\/validate$/', $path, $matches) && $method === 'PUT') {
        $controller = new DocumentoController();
        $controller->validate($matches[1]);
    }
    elseif (preg_match('/^documentos\/(\d+)\/download$/', $path, $matches) && $method === 'GET') {
        $controller = new DocumentoController();
        $controller->download($matches[1]);
    }
    elseif ($path === 'documentos/pendentes' && $method === 'GET') {
        $controller = new DocumentoController();
        $controller->getPendingByCandidate();
    }
    elseif ($path === 'documentos/stats') {
        $controller = new DocumentoController();
        $controller->getStats();
    }

    // Utilizadores
    elseif ($path === 'users' && $method === 'GET') {
        $controller = new UtilizadorController();
        $controller->index();
    }
    elseif (preg_match('/^users\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new UtilizadorController();
        $controller->show($matches[1]);
    }
    elseif (preg_match('/^users\/(\d+)$/', $path, $matches) && $method === 'PUT') {
        $controller = new UtilizadorController();
        $controller->update($matches[1]);
    }
    elseif ($path === 'users/stats') {
        $controller = new UtilizadorController();
        $controller->stats();
    }

    // Relatórios
    elseif ($path === 'relatorio/stats') {
        Auth::verifyToken();
        Auth::verifyRole(['gestor', 'admin']);
        $controller = new RelatorioController();
        echo json_encode($controller->getStats());
    }
    elseif ($path === 'relatorio/periodo') {
        Auth::verifyToken();
        Auth::verifyRole(['gestor', 'admin']);
        $controller = new RelatorioController();
        echo json_encode($controller->getStatsByPeriod());
    }
    elseif ($path === 'relatorio/export/pdf') {
        Auth::verifyToken();
        Auth::verifyRole(['gestor', 'admin']);
        $controller = new RelatorioController();
        echo json_encode($controller->exportPDF());
    }
    elseif ($path === 'relatorio/export/excel') {
        Auth::verifyToken();
        Auth::verifyRole(['gestor', 'admin']);
        $controller = new RelatorioController();
        echo json_encode($controller->exportExcel());
    }

    // Aluno - Perfil e Cursos
    elseif ($path === 'aluno/perfil' && $method === 'GET') {
        $controller = new AlunoController();
        $controller->getPerfil();
    }
    elseif ($path === 'aluno/perfil' && $method === 'PUT') {
        $controller = new AlunoController();
        $controller->actualizarPerfil();
    }
    elseif ($path === 'aluno/meus-cursos' && $method === 'GET') {
        $controller = new AlunoController();
        $controller->getMeusCursos();
    }
    elseif ($path === 'aluno/guardar-curso' && $method === 'POST') {
        $controller = new AlunoController();
        $controller->guardarCurso();
    }
    elseif ($path === 'aluno/inscrever-curso' && $method === 'POST') {
        $controller = new AlunoController();
        $controller->inscreverCurso();
    }
    elseif ($path === 'aluno/remover-curso' && $method === 'POST') {
        $controller = new AlunoController();
        $controller->removerCurso();
    }
    elseif ($path === 'aluno/cursos-em-espera' && $method === 'GET') {
        $controller = new AlunoController();
        $controller->getCursosEmEspera();
    }
    elseif ($path === 'aluno/remover-lista-espera' && $method === 'POST') {
        $controller = new AlunoController();
        $controller->removerDaListaEspera();
    }
    elseif ($path === 'aluno/notificacoes' && $method === 'GET') {
        $controller = new AlunoController();
        $controller->getNotificacoes();
    }
    elseif ($path === 'aluno/notificacao-lida' && $method === 'POST') {
        $controller = new AlunoController();
        $controller->marcarNotificacaoComoLida();
    }
    elseif ($path === 'aluno/notificacoes-lidas' && $method === 'POST') {
        $controller = new AlunoController();
        $controller->marcarTodasAsNotificacoesComoLidas();
    }

    // Admin - Gerenciamento de Alunos/Candidatos
    elseif ($path === 'admin/alunos' && $method === 'GET') {
        $controller = new AlunosAdminController();
        $controller->index();
    }
    elseif ($path === 'admin/alunos' && $method === 'POST') {
        $controller = new AlunosAdminController();
        $controller->store();
    }
    elseif (preg_match('/^admin\/alunos$/', $path) && $method === 'GET' && isset($_GET['id'])) {
        $controller = new AlunosAdminController();
        $controller->show();
    }
    elseif (preg_match('/^admin\/alunos$/', $path) && $method === 'PUT' && isset($_GET['id'])) {
        $controller = new AlunosAdminController();
        $controller->update();
    }
    elseif (preg_match('/^admin\/alunos$/', $path) && $method === 'DELETE' && isset($_GET['id'])) {
        $controller = new AlunosAdminController();
        $controller->delete();
    }
    elseif ($path === 'admin/alunos/stats') {
        $controller = new AlunosAdminController();
        $controller->getStats();
    }
    elseif ($path === 'admin/alunos/export-csv') {
        $controller = new AlunosAdminController();
        $controller->exportCSV();
    }
    elseif ($path === 'admin/alunos/validar' && isset($_GET['id'])) {
        $controller = new AlunosAdminController();
        $controller->validarCandidato();
    }

    // Admin - Administradores (CRUD)
    elseif ($path === 'admin/administradores' && $method === 'GET') {
        $controller = new AdminsController();
        $controller->index();
    }
    elseif ($path === 'admin/administradores' && $method === 'POST') {
        $controller = new AdminsController();
        $controller->store();
    }
    elseif (preg_match('/^admin\/administradores$/', $path) && $method === 'GET' && isset($_GET['id'])) {
        $controller = new AdminsController();
        $controller->show();
    }
    elseif (preg_match('/^admin\/administradores$/', $path) && $method === 'PUT' && isset($_GET['id'])) {
        $controller = new AdminsController();
        $controller->update();
    }
    elseif (preg_match('/^admin\/administradores$/', $path) && $method === 'DELETE' && isset($_GET['id'])) {
        $controller = new AdminsController();
        $controller->delete();
    }
    elseif ($path === 'admin/administradores/alterar-senha' && $method === 'PUT' && isset($_GET['id'])) {
        $controller = new AdminsController();
        $controller->alterarSenha();
    }

    // Solicitações de Estágios (Escolas solicitam alunos para cursos)
    elseif ($path === 'solicitacoes-estagios' && $method === 'GET') {
        $controller = new SolicitacaoEstagioController();
        $controller->listar();
    }
    elseif ($path === 'solicitacoes-estagios' && $method === 'POST') {
        $controller = new SolicitacaoEstagioController();
        $controller->criar();
    }
    elseif (preg_match('/^solicitacoes-estagios\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new SolicitacaoEstagioController();
        $controller->obter($matches[1]);
    }
    elseif (preg_match('/^solicitacoes-estagios\/(\d+)\/aprovar$/', $path, $matches) && $method === 'PUT') {
        $controller = new SolicitacaoEstagioController();
        $controller->aprovar($matches[1]);
    }
    elseif (preg_match('/^solicitacoes-estagios\/(\d+)\/rejeitar$/', $path, $matches) && $method === 'PUT') {
        $controller = new SolicitacaoEstagioController();
        $controller->rejeitar($matches[1]);
    }
    elseif (preg_match('/^solicitacoes-estagios\/(\d+)$/', $path, $matches) && $method === 'DELETE') {
        $controller = new SolicitacaoEstagioController();
        $controller->cancelar($matches[1]);
    }
    elseif (preg_match('/^solicitacoes-estagios\/escola\/(\d+)$/', $path, $matches) && $method === 'GET') {
        $controller = new SolicitacaoEstagioController();
        $controller->porEscola($matches[1]);
    }
    elseif (preg_match('/^solicitacoes-estagios\/curso\/(\d+)\/aprovadas$/', $path, $matches) && $method === 'GET') {
        $controller = new SolicitacaoEstagioController();
        $controller->approvadasPorCurso($matches[1]);
    }
    elseif ($path === 'solicitacoes-estagios/stats' && $method === 'GET') {
        $controller = new SolicitacaoEstagioController();
        $controller->stats();
    }

    // Health check
    elseif ($path === 'health') {
        jsonResponse(['status' => 'ok', 'message' => 'API MUNDO DA TECNOLOGIA operacional']);
    }

    // Rota não encontrada
    else {
        jsonResponse([], 404, 'Rota não encontrada: ' . $path);
    }

} catch (Exception $e) {
    jsonResponse([], 500, 'Erro interno do servidor: ' . $e->getMessage());
}
