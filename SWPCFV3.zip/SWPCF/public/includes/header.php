<?php
/**
 * Header template com navbar
 * Arquivo: public/includes/header.php
 */
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="SWPCF - Plataforma de estágios profissionais">
    <title>SWPCF - Mundo da Tecnologia</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/SWPCF/public/css/public-style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-public sticky-top">
        <div class="container-lg">
            <!-- Logo -->
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>/SWPCF/">
                <i class="fas fa-graduation-cap"></i>
                <span>SWPCF</span>
            </a>
            
            <!-- Toggler Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Menu -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/SWPCF/">
                            <i class="fas fa-home me-1"></i>Início
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/SWPCF/formacoes">
                            <i class="fas fa-graduation-cap me-1"></i>Formações
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/SWPCF/estagios">
                            <i class="fas fa-clipboard-list me-1"></i>Estágios
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/SWPCF/vagas">
                            <i class="fas fa-briefcase me-1"></i>Vagas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/SWPCF/sobre">
                            <i class="fas fa-info-circle me-1"></i>Sobre
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/SWPCF/contactos">
                            <i class="fas fa-envelope me-1"></i>Contactos
                        </a>
                    </li>
                </ul>
                
                <!-- Botões Auth -->
                <div class="d-lg-flex gap-2 ms-lg-3 mt-3 mt-lg-0">
                    <?php if (isset($_SESSION['user'])): ?>
                        <div class="dropdown">
                            <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['user']['nome']); ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/SWPCF/dashboard">Dashboard</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/SWPCF/candidaturas">Candidaturas</a></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/SWPCF/perfil">Perfil</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/api/logout">Sair</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a class="btn btn-outline-primary btn-sm" href="<?php echo BASE_URL; ?>/SWPCF/login">
                            <i class="fas fa-sign-in-alt me-1"></i>Login
                        </a>
                        <a class="btn btn-primary btn-sm" href="<?php echo BASE_URL; ?>/SWPCF/registo">
                            <i class="fas fa-user-plus me-1"></i>Registar
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Conteúdo principal (continuado nas páginas) -->
