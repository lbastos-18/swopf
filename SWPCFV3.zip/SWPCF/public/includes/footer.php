<?php
/**
 * Footer template
 * Arquivo: public/includes/footer.php
 */
?>
    <!-- Footer -->
    <footer class="footer mt-auto py-4 bg-dark text-light">
        <div class="container-lg">
            <div class="row">
                <!-- Sobre -->
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Sobre SWPCF</h5>
                    <p class="small">Plataforma de estágios profissionais para conectar estudantes com empresas.</p>
                </div>
                
                <!-- Links Rápidos -->
                <div class="col-md-4 mb-4 mb-md-0">
                    <h5>Links Rápidos</h5>
                    <ul class="list-unstyled small">
                        <li><a href="<?php echo BASE_URL; ?>/SWPCF/" class="text-light-emphasis">Início</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/SWPCF/estagios" class="text-light-emphasis">Estágios</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/SWPCF/vagas" class="text-light-emphasis">Vagas</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/SWPCF/contactos" class="text-light-emphasis">Contactos</a></li>
                    </ul>
                </div>
                
                <!-- Contacto -->
                <div class="col-md-4">
                    <h5>Contacte-nos</h5>
                    <ul class="list-unstyled small">
                        <li><i class="fas fa-envelope"></i> info@swpcf.pt</li>
                        <li><i class="fas fa-phone"></i> +351 217 123 456</li>
                        <li><i class="fas fa-map-marker-alt"></i> Lisboa, Portugal</li>
                    </ul>
                </div>
            </div>
            
            <!-- Copyright -->
            <hr class="bg-secondary">
            <div class="text-center">
                <p class="small mb-0">&copy; 2024 SWPCF. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    
    <!-- Scripts -->
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo BASE_URL; ?>/SWPCF/public/js/main.js"></script>
</body>
</html>
