/**
 * main.js - Scripts principais da aplicação
 * Navbar e footer agora carregam via PHP (não mais via JavaScript)
 */

// Highlight do link ativo na navbar
document.addEventListener('DOMContentLoaded', function() {
    const currentLocation = location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentLocation.includes(href.replace('/SWPCF/', ''))) {
            link.classList.add('active');
        }
    });
});

// Função para validação básica de formulários
function validarFormulario(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;
    
    return form.checkValidity() === false ? false : true;
}

// Função para mostrar alertas
function mostrarAlerta(mensagem, tipo = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${tipo} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `
        ${mensagem}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    `;
    
    const container = document.querySelector('main') || document.body;
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-fechar após 5 segundos
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Função para fazer requisições AJAX
async function fazerRequisicao(url, opcoes = {}) {
    try {
        const resposta = await fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...opcoes.headers
            },
            ...opcoes
        });
        
        if (!resposta.ok) {
            throw new Error(`HTTP error! status: ${resposta.status}`);
        }
        
        return await resposta.json();
    } catch (erro) {
        console.error('Erro na requisição:', erro);
        mostrarAlerta('Erro ao processar requisição', 'danger');
        throw erro;
    }
}
