/**
 * LOADER - Carrega navbar e footer dinamicamente
 */
document.addEventListener('DOMContentLoaded', function() {
    carregarNavbar();
    carregarFooter();
    verificarAutenticacao();
});

async function carregarNavbar() {
    try {
        const response = await fetch('includes/navbar.html');
        const html = await response.text();
        const container = document.getElementById('navbar-container');
        if (container) {
            container.innerHTML = html;
            ativarLinkAtivo();
        }
    } catch (error) {
        console.error('Erro ao carregar navbar:', error);
    }
}

async function carregarFooter() {
    try {
        const response = await fetch('includes/footer.html');
        const html = await response.text();
        const container = document.getElementById('footer-container');
        if (container) {
            container.innerHTML = html;
        } else {
            const footer = document.createElement('div');
            footer.innerHTML = html;
            document.body.appendChild(footer);
        }
    } catch (error) {
        console.error('Erro ao carregar footer:', error);
    }
}

function ativarLinkAtivo() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage) {
            link.classList.add('active');
        }
    });
}

function verificarAutenticacao() {
    const user = localStorage.getItem('swpcf_user');
    const authButtons = document.getElementById('authButtons');
    
    if (authButtons) {
        if (user) {
            const userData = JSON.parse(user);
            authButtons.innerHTML = `
                <div class="dropdown">
                    <button class="btn btn-primary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user me-1"></i>${userData.nome || 'Utilizador'}
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="dashboard.html"><i class="fas fa-chart-line me-2"></i>Dashboard</a></li>
                        <li><a class="dropdown-item" href="candidaturas.html"><i class="fas fa-clipboard-list me-2"></i>Candidaturas</a></li>
                        <li><a class="dropdown-item" href="perfil.html"><i class="fas fa-user me-2"></i>Perfil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Sair</a></li>
                    </ul>
                </div>
            `;
        }
    }
}

function logout() {
    localStorage.removeItem('swpcf_user');
    localStorage.removeItem('swpcf_token');
    window.location.href = 'login.html';
}
