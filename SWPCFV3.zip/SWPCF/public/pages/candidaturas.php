<?php
/**
 * Página: candidaturas
 * Gerado automaticamente de candidaturas.html
 */
?>
<main class="container py-5">
        <div class="row mb-4">
            <div class="col">
                <h1 class="h3 fw-bold"><i class="fas fa-clipboard-list me-2 text-primary"></i>Minhas Candidaturas</h1>
                <p class="text-muted">Acompanhe o status de todas as suas candidaturas.</p>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary active" data-filter="todas">Todas</button>
                    <button type="button" class="btn btn-outline-warning" data-filter="pendente">Pendentes</button>
                    <button type="button" class="btn btn-outline-success" data-filter="aceite">Aprovadas</button>
                    <button type="button" class="btn btn-outline-danger" data-filter="rejeitado">Rejeitadas</button>
                </div>
            </div>
        </div>
        <div id="listaCandidaturas" class="row g-3">
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Carregando...</span>
                </div>
            </div>
        </div>
    </main>
    <script>
        let candidaturasData = [];
        let filtroAtual = 'todas';
        document.addEventListener('DOMContentLoaded', async () => {
            const user = JSON.parse(localStorage.getItem('swpcf_user') || '{}');
            if (!user.id) {
                window.location.href = 'login.html';
                return;
            }
            document.querySelectorAll('[data-filter]').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
                    e.target.classList.add('active');
                    filtroAtual = e.target.dataset.filter;
                    renderCandidaturas();
                });
            });
            await carregarCandidaturas(user.id);
        });
        async function carregarCandidaturas(userId) {
            try {
                const res = await fetch(`/SWPCF/api/candidaturas.php?candidato_id=${userId}`);
                const data = await res.json();
                candidaturasData = data.success ? data.data : [];
                renderCandidaturas();
            } catch (e) {
                document.getElementById('listaCandidaturas').innerHTML = '<div class="col-12"><div class="alert alert-danger">Erro ao carregar candidaturas</div></div>';
            }
        }
        function renderCandidaturas() {
            const container = document.getElementById('listaCandidaturas');
            const filtradas = filtroAtual === 'todas' ? candidaturasData : candidaturasData.filter(c => c.status === filtroAtual);
            if (filtradas.length === 0) {
                container.innerHTML = '<div class="col-12"><div class="alert alert-info">Nenhuma candidatura encontrada. <a href="vagas.html">Ver vagas disponíveis</a></div></div>';
                return;
            }
            container.innerHTML = filtradas.map(c => `
                <div class="col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title mb-0">${c.vaga_titulo || 'Vaga #' + c.vaga_id}</h5>
                                <span class="badge bg-${c.status === 'aceite' ? 'success' : c.status === 'pendente' ? 'warning' : 'danger'}">
                                    ${c.status === 'aceite' ? 'Aprovada' : c.status === 'pendente' ? 'Pendente' : 'Rejeitada'}
                                </span>
                            </div>
                            <p class="text-muted small mb-2">
                                <i class="fas fa-calendar me-1"></i>Candidatura: ${new Date(c.data_candidatura).toLocaleDateString('pt-PT')}
                            </p>
                            ${c.notas ? `<p class="small mb-0"><strong>Notas:</strong> ${c.notas}</p>` : ''}
                        </div>
                    </div>
                </div>
            `).join('');
        }
    </script>
    <div id="footer-container"></div>
