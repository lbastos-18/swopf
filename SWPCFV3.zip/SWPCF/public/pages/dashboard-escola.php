<?php
/**
 * Página: dashboard-escola
 * Gerado automaticamente de dashboard-escola.html
 */
?>
<!-- NAVBAR (carregada dinamicamente) -->
    <!-- HERO SECTION -->
    <section class="hero py-4">
        <div class="container">
            <h1 class="h3 mb-0">
                <i class="fas fa-school me-2"></i>Dashboard da Escola
            </h1>
        </div>
    </section>
    <!-- MAIN CONTENT -->
    <main class="container py-4">
        <div class="row gap-4">
            <!-- SIDEBAR -->
            <div class="col-lg-3">
                <div class="card shadow-sm sidebar-nav">
                    <div class="list-group list-group-flush">
                        <button class="list-group-item list-group-item-action active" data-tab="cursos">
                            <i class="fas fa-book me-2"></i>Cursos Disponíveis
                            <span class="badge bg-primary float-end" id="cursos-count">0</span>
                        </button>
                        <button class="list-group-item list-group-item-action" data-tab="minhas-solicitacoes">
                            <i class="fas fa-file-alt me-2"></i>Minhas Solicitações
                            <span class="badge bg-warning float-end" id="solicitacoes-count">0</span>
                        </button>
                        <button class="list-group-item list-group-item-action" data-tab="stats">
                            <i class="fas fa-chart-bar me-2"></i>Estatísticas
                        </button>
                    </div>
                </div>
            </div>
            <!-- CONTEÚDO -->
            <div class="col-lg-9">
                <!-- ABAS -->
                <div id="cursos" class="tab-content">
                    <h5 class="mb-4">
                        <i class="fas fa-book text-primary me-2"></i>Cursos Disponíveis
                    </h5>
                    <div class="alert alert-info">
                        <i class="fas fa-lightbulb me-2"></i>
                        <strong>Como funciona:</strong> Selecione um curso e clique em "Solicitar Estágio" para começar o processo.
                    </div>
                    <div id="cursos-list" class="row gap-3">
                        <div class="col-12 text-center py-5">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Carregando...</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- MINHAS SOLICITAÇÕES -->
                <div id="minhas-solicitacoes" class="tab-content d-none">
                    <h5 class="mb-4">
                        <i class="fas fa-file-alt text-primary me-2"></i>Minhas Solicitações
                    </h5>
                    <ul class="nav nav-tabs mb-4" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active" data-status="todas">Todas</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-status="pendente">
                                Pendentes <span class="badge bg-warning ms-1">0</span>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-status="aprovada">
                                Aprovadas <span class="badge bg-success ms-1">0</span>
                            </button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" data-status="rejeitada">
                                Rejeitadas <span class="badge bg-danger ms-1">0</span>
                            </button>
                        </li>
                    </ul>
                    <div id="solicitacoes-list" class="row gap-3">
                        <p class="text-muted col-12">Carregando solicitações...</p>
                    </div>
                </div>
                <!-- ESTATÍSTICAS -->
                <div id="stats" class="tab-content d-none">
                    <h5 class="mb-4">
                        <i class="fas fa-chart-bar text-primary me-2"></i>Estatísticas
                    </h5>
                    <div class="row gap-3">
                        <div class="col-md-6">
                            <div class="card bg-primary text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title text-white-50">Total de Solicitações</h6>
                                    <h2 class="mb-0" id="stat-total">0</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-warning text-dark">
                                <div class="card-body text-center">
                                    <h6 class="card-title">Pendentes</h6>
                                    <h2 class="mb-0" id="stat-pendentes">0</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title text-white-50">Aprovadas</h6>
                                    <h2 class="mb-0" id="stat-aprovadas">0</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-danger text-white">
                                <div class="card-body text-center">
                                    <h6 class="card-title text-white-50">Rejeitadas</h6>
                                    <h2 class="mb-0" id="stat-rejeitadas">0</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-4">
                        <div class="card-body">
                            <h6 class="card-title mb-3">
                                <i class="fas fa-briefcase me-2"></i>Vagas Solicitadas
                            </h6>
                            <p class="display-4 mb-0" id="stat-vagas">0</p>
                            <small class="text-muted">Total de vagas em solicitações aprovadas</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- MODAL: Solicitar Estágio -->
    <div class="modal fade" id="solicitarModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>Solicitar Estágio
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="solicitarForm">
                    <div class="modal-body">
                        <input type="hidden" id="cursoIdSolicitacao">
                        <div class="mb-3">
                            <label for="solicitarTitulo" class="form-label">Título da Solicitação</label>
                            <input type="text" class="form-control" id="solicitarTitulo" 
                                   placeholder="Ex: Precisamos de alunos para estágio em desenvolvimento" required>
                        </div>
                        <div class="mb-3">
                            <label for="solicitarDescricao" class="form-label">Descrição</label>
                            <textarea class="form-control" id="solicitarDescricao" rows="4" 
                                      placeholder="Descreva o que os alunos farão, qual é o ambiente de trabalho, etc."></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="solicitarVagas" class="form-label">Número de Vagas</label>
                                <input type="number" class="form-control" id="solicitarVagas" 
                                       min="1" value="1" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="solicitarDuracao" class="form-label">Duração (meses)</label>
                                <input type="number" class="form-control" id="solicitarDuracao" 
                                       min="1" value="3" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="solicitarInicio" class="form-label">Data de Início</label>
                                <input type="date" class="form-control" id="solicitarInicio" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="solicitarFim" class="form-label">Data de Término</label>
                                <input type="date" class="form-control" id="solicitarFim" required>
                            </div>
                        </div>
                        <div class="alert alert-info small">
                            <i class="fas fa-info-circle me-2"></i>
                            A sua solicitação será enviada para aprovação. Uma vez aprovada, aparecerá na área pública.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i>Enviar Solicitação
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- FOOTER (carregada dinamicamente) -->
    <script>
        const API_BASE = '/SWPCF/api';
        let escolaId = null;
        let todosCursos = [];
        document.addEventListener('DOMContentLoaded', () => {
            loadNavbar();
            loadFooter();
            // Verificar se é escola logada
            const user = JSON.parse(localStorage.getItem('user') || '{}');
            if (!user.id || user.tipo !== 'escola') {
                window.location.href = 'index.html';
                return;
            }
            escolaId = user.id;
            carregarCursos();
            carregarSolicitacoes();
        });
        // Navegação de abas
        document.querySelectorAll('[data-tab]').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                document.querySelectorAll('[data-tab]').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(t => t.classList.add('d-none'));
                btn.classList.add('active');
                document.getElementById(tab).classList.remove('d-none');
                if (tab === 'minhas-solicitacoes') {
                    carregarSolicitacoes();
                }
            });
        });
        async function carregarCursos() {
            try {
                const response = await fetch(`${API_BASE}/cursos`);
                const data = await response.json();
                if (data.success) {
                    todosCursos = data.data || [];
                    document.getElementById('cursos-count').textContent = todosCursos.length;
                    renderizarCursos();
                }
            } catch (error) {
                console.error('Erro:', error);
                document.getElementById('cursos-list').innerHTML = 
                    '<p class="text-danger">Erro ao carregar cursos</p>';
            }
        }
        function renderizarCursos() {
            const container = document.getElementById('cursos-list');
            if (todosCursos.length === 0) {
                container.innerHTML = '<p class="text-muted col-12">Nenhum curso disponível</p>';
                return;
            }
            container.innerHTML = todosCursos.map(curso => `
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h6 class="mb-0">${escapeHtml(curso.nome)}</h6>
                        </div>
                        <div class="card-body">
                            <p class="card-text text-muted small">
                                ${curso.descricao ? escapeHtml(curso.descricao.substring(0, 100)) + '...' : 'Sem descrição'}
                            </p>
                            <p class="small mb-0">
                                <strong>Duração:</strong> ${curso.duracao_meses} meses
                            </p>
                        </div>
                        <div class="card-footer bg-light">
                            <button class="btn btn-sm btn-primary w-100" onclick="mostrarSolicitarModal(${curso.id})">
                                <i class="fas fa-plus me-1"></i>Solicitar Estágio
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
        async function carregarSolicitacoes() {
            try {
                const response = await fetch(`${API_BASE}/solicitacoes-estagios/escola/${escolaId}`);
                const data = await response.json();
                if (data.success) {
                    const solicitacoes = data.data || [];
                    // Contar por status
                    const pendentes = solicitacoes.filter(s => s.status === 'pendente').length;
                    const aprovadas = solicitacoes.filter(s => s.status === 'aprovada').length;
                    const rejeitadas = solicitacoes.filter(s => s.status === 'rejeitada').length;
                    // Atualizar contadores
                    document.getElementById('solicitacoes-count').textContent = solicitacoes.length;
                    document.getElementById('stat-total').textContent = solicitacoes.length;
                    document.getElementById('stat-pendentes').textContent = pendentes;
                    document.getElementById('stat-aprovadas').textContent = aprovadas;
                    document.getElementById('stat-rejeitadas').textContent = rejeitadas;
                    const vagasTotal = solicitacoes
                        .filter(s => s.status === 'aprovada')
                        .reduce((sum, s) => sum + (s.vagas_quantidade || 0), 0);
                    document.getElementById('stat-vagas').textContent = vagasTotal;
                    renderizarSolicitacoes(solicitacoes);
                }
            } catch (error) {
                console.error('Erro:', error);
            }
        }
        function renderizarSolicitacoes(solicitacoes) {
            const container = document.getElementById('solicitacoes-list');
            if (solicitacoes.length === 0) {
                container.innerHTML = '<p class="text-muted col-12">Você não fez nenhuma solicitação ainda</p>';
                return;
            }
            container.innerHTML = solicitacoes.map(sol => `
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100">
                        <div class="card-header bg-${getStatusColor(sol.status)} text-white">
                            <div class="d-flex justify-content-between align-items-start">
                                <h6 class="mb-0">${escapeHtml(sol.titulo)}</h6>
                                <span class="badge bg-dark">${getStatusLabel(sol.status)}</span>
                            </div>
                        </div>
                        <div class="card-body small">
                            <p class="text-muted mb-2">${escapeHtml(sol.curso_nome)}</p>
                            <ul class="list-unstyled">
                                <li class="mb-1"><strong>${sol.vagas_quantidade}</strong> vagas</li>
                                <li class="mb-1">${formatarData(sol.periodo_inicio)} a ${formatarData(sol.periodo_fim)}</li>
                                <li>${sol.total_candidatos || 0} candidatos</li>
                            </ul>
                        </div>
                        ${sol.status === 'rejeitada' ? `
                            <div class="card-footer bg-light small text-danger">
                                <strong>Motivo:</strong> ${escapeHtml(sol.motivo_rejeicao)}
                            </div>
                        ` : ''}
                    </div>
                </div>
            `).join('');
        }
        function mostrarSolicitarModal(cursoId) {
            document.getElementById('cursoIdSolicitacao').value = cursoId;
            document.getElementById('solicitarTitulo').value = '';
            document.getElementById('solicitarDescricao').value = '';
            document.getElementById('solicitarVagas').value = '1';
            // Definir datas padrão
            const hoje = new Date().toISOString().split('T')[0];
            const fim = new Date();
            fim.setMonth(fim.getMonth() + 3);
            document.getElementById('solicitarInicio').value = hoje;
            document.getElementById('solicitarFim').value = fim.toISOString().split('T')[0];
            new bootstrap.Modal('#solicitarModal').show();
        }
        document.getElementById('solicitarForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const cursoId = document.getElementById('cursoIdSolicitacao').value;
            const inicio = document.getElementById('solicitarInicio').value;
            const fim = document.getElementById('solicitarFim').value;
            if (new Date(inicio) > new Date(fim)) {
                alert('A data de término deve ser após a data de início');
                return;
            }
            try {
                const response = await fetch(`${API_BASE}/solicitacoes-estagios`, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        escola_id: escolaId,
                        curso_id: parseInt(cursoId),
                        titulo: document.getElementById('solicitarTitulo').value,
                        descricao: document.getElementById('solicitarDescricao').value,
                        vagas_quantidade: parseInt(document.getElementById('solicitarVagas').value),
                        periodo_inicio: inicio,
                        periodo_fim: fim
                    })
                });
                const data = await response.json();
                if (data.success) {
                    alert('Solicitação enviada com sucesso! Aguarde aprovação.');
                    bootstrap.Modal.getInstance('#solicitarModal').hide();
                    carregarSolicitacoes();
                } else {
                    alert('Erro: ' + data.error);
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao enviar solicitação');
            }
        });
        function getStatusColor(status) {
            const colors = {'pendente': 'warning', 'aprovada': 'success', 'rejeitada': 'danger'};
            return colors[status] || 'secondary';
        }
        function getStatusLabel(status) {
            const labels = {'pendente': 'Pendente', 'aprovada': 'Aprovada', 'rejeitada': 'Rejeitada'};
            return labels[status] || status;
        }
        function formatarData(data) {
            return new Date(data).toLocaleDateString('pt-PT');
        }
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
    <div id="footer-container"></div>
