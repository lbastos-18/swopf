<?php
/**
 * Página: estagios
 * Gerado automaticamente de estagios.html
 */
?>
<section class="bg-light py-5 border-bottom">
        <div class="container">
            <h1 class="fw-bold mb-2">
                <i class="fas fa-briefcase me-2 text-primary"></i>Oportunidades de Estágio
            </h1>
            <p class="text-muted mb-0">Desenvolva suas competências com nossas oportunidades de estágio profissional</p>
        </div>
    </section>
    <!-- Main Content -->
    <main class="container py-5">
        <div class="row">
            <!-- Sidebar Filtros -->
            <div class="col-lg-3 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-filter me-2"></i>Filtros
                        </h5>
                    </div>
                    <div class="card-body">
                        <!-- Tipo de Estágio -->
                        <div class="mb-3">
                            <label class="form-label fw-600 text-dark">Tipo de Estágio</label>
                            <div class="form-check">
                                <input class="form-check-input filter-checkbox" type="checkbox" value="remunerado" id="filterRemunerado">
                                <label class="form-check-label" for="filterRemunerado">Remunerado</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input filter-checkbox" type="checkbox" value="nao_remunerado" id="filterNaoRemunerado">
                                <label class="form-check-label" for="filterNaoRemunerado">Não Remunerado</label>
                            </div>
                        </div>
                        <!-- Área -->
                        <div class="mb-3">
                            <label for="filterArea" class="form-label fw-600 text-dark">Área</label>
                            <input type="text" class="form-control" id="filterArea" placeholder="Ex: Programação">
                        </div>
                        <!-- Duração -->
                        <div class="mb-3">
                            <label class="form-label fw-600 text-dark">Duração</label>
                            <div class="form-check">
                                <input class="form-check-input filter-duration" type="radio" name="duracao" value="" id="durAny" checked>
                                <label class="form-check-label" for="durAny">Qualquer duração</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input filter-duration" type="radio" name="duracao" value="8">
                                <label class="form-check-label" for="dur8">Até 8 semanas</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input filter-duration" type="radio" name="duracao" value="12">
                                <label class="form-check-label" for="dur12">12 semanas ou mais</label>
                            </div>
                        </div>
                        <button class="btn btn-primary w-100" onclick="aplicarFiltros()">
                            <i class="fas fa-search me-2"></i>Pesquisar
                        </button>
                    </div>
                </div>
            </div>
            <!-- Listagem de Estágios -->
            <div class="col-lg-9">
                <div class="row" id="estagiosContainer">
                    <!-- Cards de estágios serão carregados aqui -->
                </div>
                <!-- Paginação -->
                <nav aria-label="Paginação" class="mt-4">
                    <ul class="pagination justify-content-center" id="pagination"></ul>
                </nav>
            </div>
        </div>
    </main>
    <!-- Scripts -->
    <script>
        const estagios = [
            {
                id: 1,
                titulo: 'Desenvolvedor Full-Stack',
                empresa: 'Tech Innovations',
                area: 'Desenvolvimento',
                tipo: 'remunerado',
                remuneracao: '1000 Kz - 1400 Kz',
                duracao: '12',
                descricao: 'Estágio com React, Node.js e MongoDB'
            },
            {
                id: 2,
                titulo: 'Analista de Dados',
                empresa: 'Data Solutions',
                area: 'Dados',
                tipo: 'remunerado',
                remuneracao: '800 Kz - 1200 Kz',
                duracao: '8',
                descricao: 'Python, SQL e Power BI'
            },
            {
                id: 3,
                titulo: 'Engenheiro DevOps',
                empresa: 'Cloud Systems',
                area: 'DevOps',
                tipo: 'remunerado',
                remuneracao: '900 Kz - 1300 Kz',
                duracao: '12',
                descricao: 'Docker, Kubernetes e AWS'
            }
        ];
        // Renderizar estágios
        function renderizarEstagios(filtrados = estagios) {
            const container = document.getElementById('estagiosContainer');
            container.innerHTML = '';
            if (filtrados.length === 0) {
                container.innerHTML = '<div class="col-12 text-center py-5"><p class="text-muted">Nenhum estágio encontrado</p></div>';
                return;
            }
            filtrados.forEach(estagio => {
                const card = document.createElement('div');
                card.className = 'col-md-6 col-lg-4 mb-4';
                card.innerHTML = `
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-header bg-primary text-white">
                            <span class="badge bg-light text-dark">${estagio.area}</span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${estagio.titulo}</h5>
                            <p class="text-muted small mb-3">
                                <i class="fas fa-building me-1"></i>${estagio.empresa}
                            </p>
                            <p class="card-text">${estagio.descricao}</p>
                            <div class="mt-3 d-flex justify-content-between align-items-center">
                                <span class="badge bg-primary text-white">${estagio.remuneracao}</span>
                                <button class="btn btn-sm btn-primary" onclick="candidatar(${estagio.id})">
                                    Candidatar
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        }
        function aplicarFiltros() {
            const tipo = document.querySelector('input[type="checkbox"]:checked')?.value || '';
            const area = document.getElementById('filterArea').value.toLowerCase();
            const duracao = document.querySelector('input[name="duracao"]:checked').value;
            const filtrados = estagios.filter(e => {
                if (tipo && e.tipo !== tipo) return false;
                if (area && !e.area.toLowerCase().includes(area)) return false;
                if (duracao && e.duracao !== duracao) return false;
                return true;
            });
            renderizarEstagios(filtrados);
        }
        function candidatar(id) {
            if (window.Auth && window.Auth.isAuthenticated()) {
                alert('Candidatura realizada com sucesso!');
            } else {
                window.location.href = 'login.html';
            }
        }
        // Renderizar estágios ao carregar
        document.addEventListener('DOMContentLoaded', () => {
            renderizarEstagios();
        });
    </script>
    <!-- Loader de Navbar e Footer -->
    <div id="footer-container"></div>
