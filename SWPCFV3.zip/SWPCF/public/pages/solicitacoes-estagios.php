<?php
/**
 * Página: solicitacoes-estagios
 * Gerado automaticamente de solicitacoes-estagios.html
 */
?>
<!-- NAVBAR (carregada dinamicamente) -->
    <!-- HERO SECTION -->
    <section class="hero py-5">
        <div class="container py-4">
            <h1 class="display-4 fw-bold mb-3">
                <i class="fas fa-building me-3"></i>Solicitações de Estágios
            </h1>
            <p class="lead mb-0">
                As instituições estão procurando alunos como você! Veja aqui quem está solicitando alunos para estágios.
            </p>
        </div>
    </section>
    <!-- MAIN CONTENT -->
    <main class="container py-5">
        <!-- FILTROS -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-white">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" class="form-control" id="searchInput" placeholder="Pesquisar por instituição...">
                </div>
            </div>
            <div class="col-md-6">
                <select class="form-select" id="cursoFilter">
                    <option value="">Filtrar por Curso...</option>
                </select>
            </div>
        </div>
        <!-- ALERTA DE LOGIN -->
        <div id="loginAlert" class="alert alert-info alert-dismissible fade show d-none">
            <i class="fas fa-info-circle me-2"></i>
            <strong>Faça login</strong> para se candidatar a um estágio.
            <a href="login.html" class="alert-link">Entrar aqui</a>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <!-- SOLICITAÇÕES -->
        <div id="solicitacoesList" class="row gap-3">
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Carregando...</span>
                </div>
                <p class="text-muted mt-2">Carregando solicitações...</p>
            </div>
        </div>
        <!-- NENHUM RESULTADO -->
        <div id="naoEncontrado" class="col-12 text-center py-5 d-none">
            <i class="fas fa-inbox text-muted" style="font-size: 3rem;"></i>
            <p class="text-muted mt-3">Nenhuma solicitação encontrada</p>
        </div>
    </main>
    <!-- MODAL: Detalhes e Candidatura -->
    <div class="modal fade" id="detalhesModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">
                        <i class="fas fa-briefcase me-2"></i>Detalhes da Solicitação
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="detalhesConteudo">
                    <!-- Preenchido dinamicamente -->
                </div>
                <div class="modal-footer" id="detalhesFooter">
                    <!-- Botão de ação -->
                </div>
            </div>
        </div>
    </div>
    <!-- FOOTER (carregada dinamicamente) -->
    <script>
        const API_BASE = '/SWPCF/api';
        let todasSolicitacoes = [];
        // Carregar ao iniciar
        document.addEventListener('DOMContentLoaded', () => {
            loadNavbar();
            loadFooter();
            carregarSolicitacoes();
            carregarCursos();
            verificarLogin();
        });
        // Verificar login e mostrar alerta
        function verificarLogin() {
            const user = localStorage.getItem('user');
            if (!user) {
                document.getElementById('loginAlert').classList.remove('d-none');
            }
        }
        async function carregarSolicitacoes() {
            try {
                const response = await fetch(`${API_BASE}/solicitacoes-estagios?tipo=aprovadas`);
                const data = await response.json();
                if (!response.ok) {
                    mostrarErro('Erro ao carregar solicitações');
                    return;
                }
                todasSolicitacoes = data.data || [];
                renderizarSolicitacoes(todasSolicitacoes);
            } catch (error) {
                console.error('Erro:', error);
                mostrarErro('Erro ao carregar solicitações');
            }
        }
        async function carregarCursos() {
            try {
                const response = await fetch(`${API_BASE}/cursos`);
                const data = await response.json();
                if (data.success) {
                    const cursos = data.data || [];
                    const select = document.getElementById('cursoFilter');
                    cursos.forEach(curso => {
                        const option = document.createElement('option');
                        option.value = curso.id;
                        option.textContent = curso.nome;
                        select.appendChild(option);
                    });
                }
            } catch (error) {
                console.error('Erro ao carregar cursos:', error);
            }
        }
        function renderizarSolicitacoes(solicitacoes) {
            const container = document.getElementById('solicitacoesList');
            const semResultado = document.getElementById('naoEncontrado');
            if (solicitacoes.length === 0) {
                container.innerHTML = '';
                semResultado.classList.remove('d-none');
                return;
            }
            semResultado.classList.add('d-none');
            container.innerHTML = solicitacoes.map(sol => `
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm border-0">
                        <!-- Header Card -->
                        <div class="card-header bg-primary text-white">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h6 class="mb-1" style="font-weight: 600;">
                                        <i class="fas fa-building me-1"></i>${escapeHtml(sol.escola_nome)}
                                    </h6>
                                    <small class="opacity-75">
                                        <i class="fas fa-graduation-cap me-1"></i>${escapeHtml(sol.curso_nome)}
                                    </small>
                                </div>
                            </div>
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <h6 class="card-title mb-2">${escapeHtml(sol.titulo)}</h6>
                            <p class="card-text text-muted small mb-3">
                                ${sol.descricao ? escapeHtml(sol.descricao.substring(0, 80)) + '...' : 'Sem descrição'}
                            </p>
                            <!-- Info Grid -->
                            <div class="row text-center small mb-3">
                                <div class="col-6 border-end">
                                    <div class="text-muted">Vagas</div>
                                    <strong class="text-primary">${sol.vagas_quantidade}</strong>
                                </div>
                                <div class="col-6">
                                    <div class="text-muted">Período</div>
                                    <strong class="text-primary">${formatarData(sol.periodo_inicio)}</strong>
                                </div>
                            </div>
                            <!-- Candidatos -->
                            <div class="text-center small">
                                <span class="badge bg-light text-dark">
                                    <i class="fas fa-user me-1"></i>${sol.total_candidatos || 0} candidatos
                                </span>
                            </div>
                        </div>
                        <!-- Footer Card -->
                        <div class="card-footer bg-light">
                            <button class="btn btn-sm btn-primary w-100" onclick="mostrarDetalhes(${sol.id})">
                                <i class="fas fa-eye me-1"></i>Ver Detalhes
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');
        }
        function mostrarDetalhes(id) {
            const sol = todasSolicitacoes.find(s => s.id === id);
            if (!sol) return;
            const html = `
                <div class="row">
                    <!-- Esquerda -->
                    <div class="col-md-6 mb-4 mb-md-0">
                        <h6 class="text-muted mb-3">
                            <i class="fas fa-building me-2"></i>INSTITUIÇÃO
                        </h6>
                        <h5>${escapeHtml(sol.escola_nome)}</h5>
                        <p class="text-muted mb-2">
                            <i class="fas fa-envelope me-2"></i>${escapeHtml(sol.escola_email)}
                        </p>
                        <p class="text-muted mb-3">
                            <i class="fas fa-user me-2"></i>${escapeHtml(sol.escola_responsavel || 'Não informado')}
                        </p>
                        <div class="mt-4">
                            <h6 class="text-muted mb-3">
                                <i class="fas fa-graduation-cap me-2"></i>CURSO
                            </h6>
                            <p class="mb-0">
                                <strong>${escapeHtml(sol.curso_nome)}</strong>
                            </p>
                        </div>
                    </div>
                    <!-- Direita -->
                    <div class="col-md-6">
                        <h6 class="text-muted mb-3">
                            <i class="fas fa-info-circle me-2"></i>INFORMAÇÕES
                        </h6>
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <strong>Vagas:</strong>
                                <span class="badge bg-primary">${sol.vagas_quantidade}</span>
                            </li>
                            <li class="mb-2">
                                <strong>Início:</strong> ${formatarData(sol.periodo_inicio)}
                            </li>
                            <li class="mb-2">
                                <strong>Término:</strong> ${formatarData(sol.periodo_fim)}
                            </li>
                            <li class="mb-2">
                                <strong>Candidatos:</strong> ${sol.total_candidatos || 0}
                            </li>
                            <li>
                                <strong>Solicitado em:</strong> ${formatarData(sol.criado_em)}
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Descrição Completa -->
                <hr class="my-4">
                <div>
                    <h6 class="text-muted mb-3">
                        <i class="fas fa-file-alt me-2"></i>DESCRIÇÃO
                    </h6>
                    <p>${escapeHtml(sol.descricao || 'Sem descrição adicional')}</p>
                </div>
            `;
            document.getElementById('detalhesConteudo').innerHTML = html;
            // Botão de ação
            const user = localStorage.getItem('user');
            const footer = document.getElementById('detalhesFooter');
            if (user) {
                footer.innerHTML = `
                    <button class="btn btn-primary btn-lg w-100" onclick="candidatar(${id})">
                        <i class="fas fa-check me-2"></i>Candidatar-me a este Estágio
                    </button>
                `;
            } else {
                footer.innerHTML = `
                    <a href="login.html" class="btn btn-primary btn-lg w-100">
                        <i class="fas fa-sign-in-alt me-2"></i>Faça login para candidatar
                    </a>
                `;
            }
            new bootstrap.Modal('#detalhesModal').show();
        }
        function candidatar(id) {
            const user = JSON.parse(localStorage.getItem('user') || '{}');
            if (!user.id) {
                alert('Por favor, faça login para candidatar');
                window.location.href = 'login.html';
                return;
            }
            if (!confirm('Deseja candidatar-se a este estágio?')) return;
            // Criar candidatura
            fetch(`${API_BASE}/candidaturas`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    solicitacao_id: id,
                    candidato_id: user.id,
                    status: 'aceite'
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('Você se candidatou com sucesso! Verifique seu perfil para acompanhar.');
                    bootstrap.Modal.getInstance('#detalhesModal').hide();
                    carregarSolicitacoes(); // Recarregar para atualizar contadores
                } else {
                    alert('Erro: ' + (data.error || 'Falha ao candidatar'));
                }
            })
            .catch(e => {
                console.error('Erro:', e);
                alert('Erro ao candidatar. Por favor, tente novamente.');
            });
        }
        // Filtros
        document.getElementById('searchInput').addEventListener('input', (e) => {
            const termo = e.target.value.toLowerCase();
            const filtrados = todasSolicitacoes.filter(s => 
                s.escola_nome.toLowerCase().includes(termo) ||
                s.titulo.toLowerCase().includes(termo) ||
                s.descricao.toLowerCase().includes(termo)
            );
            renderizarSolicitacoes(filtrados);
        });
        document.getElementById('cursoFilter').addEventListener('change', (e) => {
            const cursoId = e.target.value;
            const filtrados = cursoId 
                ? todasSolicitacoes.filter(s => s.curso_id == cursoId)
                : todasSolicitacoes;
            renderizarSolicitacoes(filtrados);
        });
        function formatarData(data) {
            if (!data) return '-';
            return new Date(data).toLocaleDateString('pt-PT', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        }
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        function mostrarErro(mensagem) {
            const container = document.getElementById('solicitacoesList');
            container.innerHTML = `
                <div class="col-12">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>${escapeHtml(mensagem)}
                    </div>
                </div>
            `;
        }
    </script>
    <div id="footer-container"></div>
