<?php
/**
 * Página: registo
 * Gerado automaticamente de registo.html
 */
?>
<main class="auth-page auth-register py-5">
<div class="register-container">
        <div class="register-header">
            <h1><i class="fas fa-user-plus me-2"></i>Criar Conta</h1>
            <p class="mb-0 small">Preencha os dados abaixo</p>
        </div>
        <div class="register-body">
            <div class="alert alert-message" id="alertMessage" role="alert" style="display:none;"></div>
            <form id="formRegister">
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-user me-2 text-success"></i>Nome Completo</label>
                    <input type="text" class="form-control" name="nome" required>
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-envelope me-2 text-success"></i>Email</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-phone me-2 text-success"></i>Telefone</label>
                    <input type="tel" class="form-control" name="telefone">
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-lock me-2 text-success"></i>Senha</label>
                    <input type="password" class="form-control" name="password" required minlength="6">
                    <small class="text-muted">Mínimo 6 caracteres</small>
                </div>
                <div class="mb-3">
                    <label class="form-label"><i class="fas fa-lock me-2 text-success"></i>Confirmar Senha</label>
                    <input type="password" class="form-control" name="password_confirm" required>
                </div>
                <button type="submit" class="btn btn-register">
                    <i class="fas fa-check-circle me-2"></i>Registar
                </button>
            </form>
            <div class="text-center mt-3">
                <small class="text-muted">
                    Já tem conta? 
                    <a href="<?php echo BASE_URL; ?>/SWPCF/login" class="text-success text-decoration-none fw-bold">Fazer login</a>
                </small>
            </div>
        </div>
    </div>
    <script>
        const form = document.getElementById('formRegister');
        const alertMessage = document.getElementById('alertMessage');
        const REGISTER_ENDPOINTS = [
            '/SWPCF/api/register.php',
            '/api/register.php',
            '../api/register.php'
        ];

        async function postRegister(payload) {
            let lastError = null;

            for (const endpoint of REGISTER_ENDPOINTS) {
                try {
                    const response = await fetch(endpoint, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(payload)
                    });

                    const raw = await response.text();
                    const contentType = response.headers.get('content-type') || '';
                    if (!contentType.includes('application/json')) {
                        lastError = new Error(`Endpoint inválido: ${endpoint}`);
                        continue;
                    }

                    let data;
                    try {
                        data = JSON.parse(raw);
                    } catch (parseError) {
                        lastError = new Error(`JSON inválido recebido de ${endpoint}`);
                        continue;
                    }

                    return data;
                } catch (networkError) {
                    lastError = networkError;
                }
            }

            throw lastError || new Error('Nenhum endpoint de registo respondeu corretamente');
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const nome = form.nome.value.trim();
            const email = form.email.value.trim();
            const telefone = form.telefone.value.trim();
            const password = form.password.value;
            const password_confirm = form.password_confirm.value;
            if (password !== password_confirm) {
                showAlert('danger', 'As senhas não coincidem');
                return;
            }
            if (password.length < 6) {
                showAlert('danger', 'A senha deve ter pelo menos 6 caracteres');
                return;
            }
            try {
                const data = await postRegister({ nome, email, telefone, password });
                if (data.success) {
                    showAlert('success', 'Conta criada com sucesso! Redirecionando...');
                    setTimeout(() => {
                        window.location.href = '/SWPCF/login';
                    }, 2000);
                } else {
                    showAlert('danger', data.message || 'Erro ao criar conta');
                }
            } catch (error) {
                showAlert('danger', 'Resposta inválida do servidor. Verifique o router/API.');
            }
        });
        function showAlert(type, message) {
            alertMessage.className = `alert alert-${type}`;
            alertMessage.textContent = message;
            alertMessage.style.display = 'block';
        }
    </script>
    </main>
