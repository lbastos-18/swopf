<?php
/**
 * Página: login
 * Gerado automaticamente de login.html
 */
?>
<main class="auth-page auth-login py-5">
<div class="login-container">
        <!-- Header -->
        <div class="login-header">
            <h1>
                <i class="fas fa-code"></i>SWPCF
            </h1>
            <p>Mundo da Tecnologia</p>
        </div>
        <!-- Login Form -->
        <div class="login-body">
            <div class="alert alert-message" id="alertMessage" role="alert"></div>
            <form id="formLogin">
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-envelope me-2 text-primary"></i>Email
                    </label>
                    <input 
                        type="email" 
                        class="form-control" 
                        name="email" 
                        placeholder="seu@email.com"
                        required>
                </div>
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-lock me-2 text-primary"></i>Senha
                    </label>
                    <input 
                        type="password" 
                        class="form-control" 
                        name="password" 
                        placeholder="••••••••"
                        required>
                </div>
                <div class="remember-me">
                    <label>
                        <input type="checkbox" name="rememberMe" class="form-check-input">
                        <span>Manter-me conectado</span>
                    </label>
                    <a href="#">Esqueceu a senha?</a>
                </div>
                <button type="submit" class="btn btn-login">
                    <span id="btnText">
                        <i class="fas fa-sign-in-alt me-2"></i>Entrar
                    </span>
                    <span id="btnLoading" class="loading">
                        <i class="fas fa-spinner fa-spin me-2"></i>A entrar...
                    </span>
                </button>
            </form>
            <div class="divider">
                <span>ou</span>
            </div>
            <p class="text-center text-muted small mb-0">
                Não tem conta?
                <a href="<?php echo BASE_URL; ?>/SWPCF/registo" class="text-primary text-decoration-none fw-semibold">
                    Registar-se agora <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </p>
        </div>
        <!-- Footer Info -->
        <div class="register-section">
            <p>
                <i class="fas fa-shield-alt me-2 text-secondary"></i>
                <span class="small text-muted">
                    Seus dados estão 100% seguros e protegidos.
                </span>
            </p>
        </div>
    </div>
    <!-- Scripts -->
    <script>
        const form = document.getElementById('formLogin');
        const alertMessage = document.getElementById('alertMessage');
        const btnText = document.getElementById('btnText');
        const btnLoading = document.getElementById('btnLoading');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = form.email.value.trim();
            const password = form.password.value;
            const rememberMe = form.rememberMe.checked;
            // Validação básica
            if (!email || !password) {
                showAlert('danger', '<i class="fas fa-exclamation-circle me-2"></i>Por favor, preencha todos os campos');
                return;
            }
            // Mostrar loading
            btnText.classList.add('d-none');
            btnLoading.classList.add('show');
            alertMessage.classList.remove('show');
            try {
                const response = await fetch('/SWPCF/api/login.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password, rememberMe })
                });
                const data = await response.json();
                if (data.success) {
                    localStorage.setItem('swpcf_user', JSON.stringify(data.user));
                    localStorage.setItem('swpcf_token', data.token);
                    showAlert('success', '<i class="fas fa-check-circle me-2"></i>Login realizado com sucesso!');
                    setTimeout(() => {
                        if (data.user.role === 'admin') {
                            window.location.href = '/SWPCF/admin/dashboard.html';
                        } else {
                            window.location.href = '/SWPCF/dashboard';
                        }
                    }, 1000);
                } else {
                    showAlert('danger', '<i class="fas fa-times-circle me-2"></i>' + (data.message || 'Email ou senha incorretos'));
                    btnText.classList.remove('d-none');
                    btnLoading.classList.remove('show');
                }
            } catch (error) {
                console.error('Erro no login:', error);
                showAlert('danger', '<i class="fas fa-exclamation-circle me-2"></i>Erro ao fazer login. Tente novamente.');
                btnText.classList.remove('d-none');
                btnLoading.classList.remove('show');
            }
        });
        function showAlert(type, message) {
            alertMessage.className = `alert alert-${type} alert-message show`;
            alertMessage.innerHTML = message;
        }
        // Limpar alerta quando o utilizador começa a escrever
        form.addEventListener('input', () => {
            alertMessage.classList.remove('show');
        });
    </script>
    </main>
