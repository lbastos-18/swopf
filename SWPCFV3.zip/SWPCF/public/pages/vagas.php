<?php
/**
 * Página: vagas
 * Gerado automaticamente de vagas.html
 */
?>
<!-- NAVBAR -->
<!-- Header -->
<div class="bg-light py-4 border-bottom">
    <div class="container-xl">
        <h1 class="fw-bold mb-2">
            <i class="bi bi-briefcase me-2"></i>Vagas de Emprego
        </h1>
        <p class="text-muted mb-0">Encontre a oportunidade perfeita para sua carreira</p>
    </div>
</div>
<!-- Filtros e Vagas -->
<div class="container-xl my-5">
    <div class="row g-4">
        <!-- Sidebar Filtros -->
        <div class="col-lg-3">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">
                        <i class="bi bi-funnel me-2"></i>Filtros
                    </h6>
                    <!-- Tipo de Contrato -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">Tipo de Contrato</label>
                        <div class="form-check">
                            <input class="form-check-input filter-checkbox" type="checkbox" value="permanente" id="tipo_permanente">
                            <label class="form-check-label" for="tipo_permanente">Permanente</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input filter-checkbox" type="checkbox" value="termo_certo" id="tipo_termo">
                            <label class="form-check-label" for="tipo_termo">Termo Certo</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input filter-checkbox" type="checkbox" value="estagio" id="tipo_estagio">
                            <label class="form-check-label" for="tipo_estagio">Estágio</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input filter-checkbox" type="checkbox" value="freelance" id="tipo_freelance">
                            <label class="form-check-label" for="tipo_freelance">Freelance</label>
                        </div>
                    </div>
                    <hr>
                    <!-- Localização -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">Localização</label>
                        <input type="text" class="form-control form-control-sm" id="filterLocalizacao" placeholder="Cidade">
                    </div>
                    <hr>
                    <!-- Range Salarial -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">Salário (Kz)</label>
                        <input type="range" class="form-range" min="0" max="5000" id="filterSalario">
                        <small class="text-muted">Até <span id="salarioValue">5000</span> Kz</small>
                    </div>
                    <hr>
                    <!-- Botões -->
                    <button class="btn btn-primary w-100 btn-sm mb-2" id="btnAplicarFiltros">
                        Aplicar Filtros
                    </button>
                    <button class="btn btn-outline-secondary w-100 btn-sm" id="btnLimparFiltros">
                        Limpar Filtros
                    </button>
                </div>
            </div>
        </div>
        <!-- Lista de Vagas -->
        <div class="col-lg-9">
            <!-- Barra de Busca -->
            <div class="mb-4">
                <input type="text" class="form-control form-control-lg" id="buscaVaga" placeholder="Pesquise por título, empresa...">
            </div>
            <!-- Cards de Vagas -->
            <div id="vagasContainer" class="row g-3">
                <!-- Vagas serão carregadas aqui -->
                <div class="col-12 text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                </div>
            </div>
            <!-- Paginação -->
            <nav aria-label="Paginação" id="paginacao" class="mt-4">
                <ul class="pagination justify-content-center">
                    <!-- Botões de página serão inseridos aqui -->
                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- Modal de Detalhe da Vaga -->
<div class="modal fade" id="modalVaga" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalVagaTitle">Detalhes da Vaga</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalVagaBody">
                <!-- Conteúdo será inserido aqui -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                <button type="button" class="btn btn-primary" id="btnCandidatar">
                    <i class="bi bi-check-circle me-2"></i>Candidatar-se
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap JS -->
<!-- Footer Container -->
<div id="footer-container"></div>
