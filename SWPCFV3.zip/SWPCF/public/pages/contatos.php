<?php
/**
 * Página: contatos
 * Gerado automaticamente de contatos.html
 */
?>
<!-- Navbar Container -->
    <!-- Hero Section -->
    <section class="bg-light py-5 border-bottom">
        <div class="container">
            <h1 class="fw-bold mb-2">
                <i class="fas fa-phone me-2 text-primary"></i>Contacte-nos
            </h1>
            <p class="lead text-muted mb-0">Estamos aqui para ajudar com qualquer dúvida ou sugestão</p>
        </div>
    </section>
    <!-- Main Content -->
    <main class="container py-5">
        <div class="row">
            <!-- Contact Info -->
            <div class="col-lg-4 mb-5">
                <!-- Email -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <div class="icon-3x text-primary">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h5 class="fw-bold mt-3 mb-2">Email</h5>
                        <p class="text-muted mb-0">
                            <a href="mailto:info@swpcf.pt" class="text-decoration-none text-muted">info@swpcf.pt</a>
                        </p>
                        <p class="text-muted small">
                            <a href="mailto:contato@swpcf.pt" class="text-decoration-none text-muted">contato@swpcf.pt</a>
                        </p>
                    </div>
                </div>
                <!-- Telefone -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <div class="icon-3x text-secondary">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h5 class="fw-bold mt-3 mb-2">Telefone</h5>
                        <p class="text-muted mb-0">
                            <a href="tel:+351912345678" class="text-decoration-none text-muted">+351 91 234 56 78</a>
                        </p>
                        <p class="text-muted small">
                            Seg-Sex: 9h-18h
                        </p>
                    </div>
                </div>
                <!-- Endereço -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <div class="icon-3x text-warning">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h5 class="fw-bold mt-3 mb-2">Localização</h5>
                        <p class="text-muted mb-0">
                            Lisboa, Portugal<br>
                            <small>Mundo da Tecnologia</small>
                        </p>
                    </div>
                </div>
                <!-- Social -->
                <div class="card bg-primary text-white border-0">
                    <div class="card-body text-center">
                        <h5 class="fw-bold mb-3">Siga-nos</h5>
                        <div class="d-flex justify-content-center gap-3">
                            <a href="#" class="text-white text-decoration-none" title="Facebook">
                                <i class="fab fa-facebook fs-5"></i>
                            </a>
                            <a href="#" class="text-white text-decoration-none" title="Twitter">
                                <i class="fab fa-twitter fs-5"></i>
                            </a>
                            <a href="#" class="text-white text-decoration-none" title="LinkedIn">
                                <i class="fab fa-linkedin fs-5"></i>
                            </a>
                            <a href="#" class="text-white text-decoration-none" title="Instagram">
                                <i class="fab fa-instagram fs-5"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contact Form -->
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-5">
                        <h3 class="fw-bold mb-4">Envie-nos uma Mensagem</h3>
                        <form id="contactForm">
                            <!-- Alert -->
                            <div id="alertMessage" class="alert alert-message mb-4 d-none"></div>
                            <!-- Nome -->
                            <div class="mb-3">
                                <label for="contact-name" class="form-label fw-600">Nome Completo *</label>
                                <input 
                                    type="text" 
                                    id="contact-name"
                                    class="form-control" 
                                    name="nome" 
                                    placeholder="João Silva"
                                    minlength="3"
                                    required>
                            </div>
                            <!-- Email -->
                            <div class="mb-3">
                                <label for="contact-email" class="form-label fw-600">Email *</label>
                                <input 
                                    type="email" 
                                    id="contact-email"
                                    class="form-control" 
                                    name="email" 
                                    placeholder="seu@email.com"
                                    inputmode="email"
                                    required>
                            </div>
                            <!-- Telefone -->
                            <div class="mb-3">
                                <label for="contact-phone" class="form-label fw-600">Telefone</label>
                                <input 
                                    type="tel" 
                                    id="contact-phone"
                                    class="form-control" 
                                    name="telefone" 
                                    placeholder="+351 91 234 56 78"
                                    inputmode="tel" pattern="\+351[0-9\s]+">
                            </div>
                            <!-- Assunto -->
                            <div class="mb-3">
                                <label for="contact-subject" class="form-label fw-600">Assunto *</label>
                                <select id="contact-subject" class="form-control" name="assunto" required>
                                    <option value="">Selecionar...</option>
                                    <option value="informacoes">Pedido de Informações</option>
                                    <option value="estagio">Oportunidade de Estágio</option>
                                    <option value="parceria">Parceria Empresarial</option>
                                    <option value="suporte">Suporte Técnico</option>
                                    <option value="outro">Outro</option>
                                </select>
                            </div>
                            <!-- Mensagem -->
                            <div class="mb-4">
                                <label for="contact-message" class="form-label fw-600">Mensagem *</label>
                                <textarea 
                                    class="form-control" 
                                    id="contact-message"
                                    name="mensagem" 
                                    rows="5" 
                                    placeholder="Escreva sua mensagem..."
                                    minlength="10"
                                    required></textarea>
                            </div>
                            <!-- Botão -->
                            <button type="submit" class="btn btn-primary btn-lg fw-bold">
                                <i class="fas fa-paper-plane me-2"></i>
                                <span id="btnText">Enviar Mensagem</span>
                                <span id="btnLoading" class="d-none">
                                    <i class="fas fa-spinner fa-spin me-2"></i>Enviando...
                                </span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Footer Container -->
    <script>
        const form = document.getElementById('contactForm');
        const alertMessage = document.getElementById('alertMessage');
        const btnText = document.getElementById('btnText');
        const btnLoading = document.getElementById('btnLoading');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const nome = form.nome.value.trim();
            const email = form.email.value.trim();
            const telefone = form.telefone.value.trim();
            const assunto = form.assunto.value;
            const mensagem = form.mensagem.value.trim();
            if (!nome || !email || !assunto || !mensagem) {
                showAlert('danger', '<i class="fas fa-exclamation-circle me-2"></i>Por favor, preencha todos os campos obrigatórios');
                return;
            }
            // Mostrar loading
            btnText.style.display = 'none';
            btnLoading.style.display = 'inline';
            alertMessage.style.display = 'none';
            try {
                // Simular envio
                await new Promise(resolve => setTimeout(resolve, 1500));
                showAlert('success', '<i class="fas fa-check-circle me-2"></i>Mensagem enviada com sucesso! Entraremos em contacto em breve.');
                form.reset();
                btnText.style.display = 'inline';
                btnLoading.style.display = 'none';
            } catch (error) {
                console.error('Erro ao enviar:', error);
                showAlert('danger', '<i class="fas fa-times-circle me-2"></i>Erro ao enviar mensagem. Tente novamente.');
                btnText.style.display = 'inline';
                btnLoading.style.display = 'none';
            }
        });
        function showAlert(type, message) {
            alertMessage.className = `alert alert-${type} alert-message`;
            alertMessage.innerHTML = message;
            alertMessage.style.display = 'block';
        }
        // Limpar alerta
        form.addEventListener('input', () => {
            alertMessage.style.display = 'none';
        });
    </script>
    <div id="footer-container"></div>
