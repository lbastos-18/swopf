<?php
/**
 * Página: sobre
 * Gerado automaticamente de sobre.html
 */
?>
<!-- Navbar Container -->
    <!-- Hero Section -->
    <section class="bg-light py-5 border-bottom">
        <div class="container">
            <h1 class="fw-bold mb-2">Sobre SWPCF</h1>
            <p class="lead text-muted mb-0">Conectando Talentos em Tecnologia com Oportunidades Profissionais</p>
        </div>
    </section>
    <!-- Main Content -->
    <main class="container py-5">
        <div class="row">
            <div class="col-lg-8">
                <!-- Missão -->
                <section class="mb-5">
                    <h2 class="fw-bold mb-3">
                        <i class="fas fa-target me-2 text-primary"></i>Nossa Missão
                    </h2>
                    <p class="lead">
                        SWPCF - Mundo da Tecnologia é uma plataforma dedicada a conectar estudantes e profissionais 
                        em desenvolvimento com as melhores oportunidades de estágio em empresas de tecnologia.
                    </p>
                    <p>
                        Nossa missão é facilitar o primeiro passo de talentos para o mercado profissional, 
                        proporcionando experiência prática, desenvolvimento de competências e contato direto com 
                        empresas líderes em tecnologia.
                    </p>
                </section>
                <!-- Visão -->
                <section class="mb-5">
                    <h2 class="fw-bold mb-3">
                        <i class="fas fa-eye me-2 text-primary"></i>Nossa Visão
                    </h2>
                    <p>
                        Ser a plataforma de referência para estágios profissionais em tecnologia, conhecida pela 
                        qualidade das oportunidades, suporte aos candidatos e satisfação das empresas parceiras.
                    </p>
                </section>
                <!-- Valores -->
                <section class="mb-5">
                    <h2 class="fw-bold mb-3">
                        <i class="fas fa-heart me-2 text-primary"></i>Nossos Valores
                    </h2>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="p-3 border-start border-primary border-4">
                                <h5 class="fw-bold">Integridade</h5>
                                <p class="text-muted">Transparência em todas nossas operações e compromisso com valores éticos.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 border-start border-primary border-4">
                                <h5 class="fw-bold">Excelência</h5>
                                <p class="text-muted">Busca contínua pela melhor qualidade em oportunidades e serviços.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 border-start border-primary border-4">
                                <h5 class="fw-bold">Inovação</h5>
                                <p class="text-muted">Ferramentas e processos modernos para otimizar a experiência.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 border-start border-primary border-4">
                                <h5 class="fw-bold">Comunidade</h5>
                                <p class="text-muted">Construir relacionamentos duradouros entre candidatos e empresas.</p>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Por que escolher SWPCF -->
                <section class="mb-5">
                    <h2 class="fw-bold mb-3">
                        <i class="fas fa-check-circle me-2 text-primary"></i>Por que Escolher SWPCF?
                    </h2>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-check me-2 text-primary"></i>Acesso exclusivo a estágios em empresas de tecnologia</li>
                        <li class="mb-2"><i class="fas fa-check me-2 text-primary"></i>Plataforma segura e confiável 100% gratuita</li>
                        <li class="mb-2"><i class="fas fa-check me-2 text-primary"></i>Suporte personalizado durante todo o processo</li>
                        <li class="mb-2"><i class="fas fa-check me-2 text-primary"></i>Oportunidades remuneradas e não remuneradas</li>
                        <li class="mb-2"><i class="fas fa-check me-2 text-primary"></i>Comunidade ativa de profissionais</li>
                        <li class="mb-2"><i class="fas fa-check me-2 text-primary"></i>Certificados e reconhecimento profissional</li>
                    </ul>
                </section>
            </div>
            <!-- Sidebar Stats -->
            <div class="col-lg-4">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <h3 class="text-primary display-6 fw-bold">150+</h3>
                        <p class="text-muted mb-0">Estágios Ativos</p>
                    </div>
                </div>
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <h3 class="text-primary display-6 fw-bold">50+</h3>
                        <p class="text-muted mb-0">Empresas Parceiras</p>
                    </div>
                </div>
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <h3 class="text-primary display-6 fw-bold">3000+</h3>
                        <p class="text-muted mb-0">Candidatos Ativos</p>
                    </div>
                </div>
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body text-center">
                        <h3 class="text-primary display-6 fw-bold">1000+</h3>
                        <p class="text-muted mb-0">Estágios Completados</p>
                    </div>
                </div>
                <!-- CTA Card -->
                <div class="card bg-primary text-white border-0">
                    <div class="card-body text-center">
                        <h5 class="fw-bold mb-3">Comece Hoje</h5>
                        <p class="small mb-3">Procure a sua oportunidade de estágio</p>
                        <a href="estagios.html" class="btn btn-light fw-bold w-100">
                            <i class="fas fa-search me-2"></i>Ver Estágios
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Footer Container -->
    <!-- Scripts -->
</body>
</html>
    <!-- Programas -->
    <div class="my-5 pb-5 border-bottom">
        <h2 class="fw-bold mb-4 text-center">Nossos Programas</h2>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card border-2 border-primary h-100">
                    <div class="card-body">
                        <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 icon-circle">
                            <i class="bi bi-book-fill fs-5"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Cursos de Formação</h5>
                        <p class="text-muted mb-3">Programas intensivos para profissionais que desejam estagiar conosco e adquirir habilidades práticas na área de tecnologia e finanças.</p>
                        <ul class="small mb-0">
                            <li>Desenvolvimento Web e Mobile</li>
                            <li>Análise de Dados e BI</li>
                            <li>Gestão Financeira</li>
                            <li>Informatica e Sistemas</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-2 border-primary h-100">
                    <div class="card-body">
                        <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 icon-circle">
                            <i class="bi bi-briefcase-fill fs-5"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Programas de Estágio</h5>
                        <p class="text-muted mb-3">Oportunidades exclusivas para alunos de instituições parceiras vivenciar a experiência profissional em ambiente real.</p>
                        <ul class="small mb-0">
                            <li>Estógio em Tecnologia da Informação</li>
                            <li>Estágio em Consultoria Financeira</li>
                            <li>Estágio em Gestão de Projetos</li>
                            <li>Estágio em Análise de Negócios</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Valores -->
    <div class="my-5 pb-5">
        <h2 class="fw-bold mb-4 text-center">Nossos Valores</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card border-0 p-4 text-center shadow-sm">
                    <i class="bi bi-star-fill text-primary display-4 mb-3"></i>
                    <h6 class="fw-bold">Excelência</h6>
                    <p class="text-muted small">Qualidade superior em todos os serviços</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 p-4 text-center shadow-sm">
                    <i class="bi bi-handshake text-primary display-4 mb-3"></i>
                    <h6 class="fw-bold">Parceria</h6>
                    <p class="text-muted small">Colaboração com instituições e empresas</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 p-4 text-center shadow-sm">
                    <i class="bi bi-rocket-takeoff text-primary display-4 mb-3"></i>
                    <h6 class="fw-bold">Inovação</h6>
                    <p class="text-muted small">Soluções criativas e modernas</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 p-4 text-center shadow-sm">
                    <i class="bi bi-people-fill text-primary display-4 mb-3"></i>
                    <h6 class="fw-bold">Inclusão</h6>
                    <p class="text-muted small">Oportunidades para todos</p>
                </div>
            </div>
        </div>
    </div>
</div>
                    <a href="#" class="text-muted text-decoration-none me-3"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-muted text-decoration-none me-3"><i class="bi bi-linkedin"></i></a>
                    <a href="#" class="text-muted text-decoration-none me-3"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="text-muted text-decoration-none"><i class="bi bi-instagram"></i></a>
                </div>
            </div>
        </div>
        <hr class="border-secondary">
        <div class="row align-items-center">
            <div class="col-md-6">
                <p>&copy; 2026 MUNDO DA TECNOLOGIA. Todos os direitos reservados.</p>
            </div>
            <div class="col-md-6 text-end">
                <small class="text-muted">Projeto de Direito Angolano | Fundada em 2018</small>
            </div>
        </div>
    </div>
</footer>
<div id="footer-container"></div>
