<?php
/**
 * Página: perfil
 * Gerado automaticamente de perfil.html
 */
?>
<main class="container py-5">
        <h1 class="section-title">Meu Perfil</h1>
        <p class="section-subtitle">Em breve você poderá ver e atualizar seus dados.</p>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="fw-bold">Dados Pessoais</h5>
                        <p id="perfilNome" class="mb-1">—</p>
                        <p id="perfilEmail" class="mb-1 text-muted">—</p>
                        <p id="perfilDocumento" class="mb-1 text-muted">—</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="fw-bold">Cursos Inscritos / Concluídos</h5>
                        <ul id="listaCursos" class="list-group list-group-flush">
                            <!-- preenchido via JS -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const user = localStorage.getItem('user');
            if (user) {
                try {
                    const u = JSON.parse(user);
                    document.getElementById('perfilNome').textContent = u.nome || '—';
                    document.getElementById('perfilEmail').textContent = u.email || '—';
                    document.getElementById('perfilDocumento').textContent = u.documento || '—';
                } catch (e) { console.error(e); }
            }
            const inscricoes = JSON.parse(localStorage.getItem('inscricoes') || '[]');
            const lista = document.getElementById('listaCursos');
            if (inscricoes.length === 0) {
                lista.innerHTML = '<li class="list-group-item text-muted">Nenhuma inscrição encontrada</li>';
            } else {
                lista.innerHTML = inscricoes.map(i => `<li class="list-group-item">Curso ID: ${i.curso_id} — ${i.nome} — ${new Date(i.date).toLocaleDateString('pt-PT')}</li>`).join('');
            }
        });
    </script>
    <div id="footer-container"></div>
