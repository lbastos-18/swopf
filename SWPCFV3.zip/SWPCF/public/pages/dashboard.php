<?php
/**
 * Página: dashboard
 * Gerado automaticamente de dashboard.html
 */
?>
<main class="container py-5">
        <div class="row mb-4">
            <div class="col">
                <h1 class="h3 fw-bold"><i class="fas fa-chart-line me-2 text-primary"></i>Meu Dashboard</h1>
                <p class="text-muted">Bem-vindo de volta! Aqui está o resumo da sua atividade.</p>
            </div>
        </div>
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted small mb-1">Candidaturas</p>
                                <h3 class="fw-bold mb-0" id="totalCandidaturas">0</h3>
                            </div>
                            <div class="fs-2 text-primary opacity-25">
                                <i class="fas fa-file-alt"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted small mb-1">Aprovadas</p>
                                <h3 class="fw-bold mb-0 text-success" id="totalAprovadas">0</h3>
                            </div>
                            <div class="fs-2 text-success opacity-25">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted small mb-1">Pendentes</p>
                                <h3 class="fw-bold mb-0 text-warning" id="totalPendentes">0</h3>
                            </div>
                            <div class="fs-2 text-warning opacity-25">
                                <i class="fas fa-clock"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="text-muted small mb-1">Perfil</p>
                                <h3 class="fw-bold mb-0 text-info" id="perfilStatus">80%</h3>
                            </div>
                            <div class="fs-2 text-info opacity-25">
                                <i class="fas fa-user"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-bottom">
                        <h5 class="fw-bold mb-0">Candidaturas Recentes</h5>
                    </div>
                    <div class="card-body">
                        <div id="listaCandidaturas">
                            <p class="text-muted text-center py-4">Nenhuma candidatura ainda. <a href="vagas.html">Ver vagas disponíveis</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-header bg-white border-bottom">
                        <h5 class="fw-bold mb-0">Ações Rápidas</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="vagas.html" class="btn btn-primary">
                                <i class="fas fa-briefcase me-2"></i>Ver Vagas
                            </a>
                            <a href="candidaturas.html" class="btn btn-outline-primary">
                                <i class="fas fa-list me-2"></i>Minhas Candidaturas
                            </a>
                            <a href="perfil.html" class="btn btn-outline-secondary">
                                <i class="fas fa-user me-2"></i>Editar Perfil
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', async () => {
            const user = JSON.parse(localStorage.getItem('swpcf_user') || '{}');
            if (!user.id) {
                window.location.href = 'login.html';
                return;
            }
            try {
                const res = await fetch(`/SWPCF/api/candidaturas.php?candidato_id=${user.id}`);
                const data = await res.json();
                if (data.success && data.data) {
                    const candidaturas = data.data;
                    document.getElementById('totalCandidaturas').textContent = candidaturas.length;
                    document.getElementById('totalAprovadas').textContent = candidaturas.filter(c => c.status === 'aceite').length;
                    document.getElementById('totalPendentes').textContent = candidaturas.filter(c => c.status === 'pendente').length;
                }
            } catch (e) {
                console.error(e);
            }
        });
    </script>
    <div id="footer-container"></div>
