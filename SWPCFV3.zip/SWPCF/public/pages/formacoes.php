<?php
/**
 * Página: formacoes
 * Gerado automaticamente de formacoes.html
 */
?>
<section class="bg-light py-5 border-bottom">
        <div class="container">
            <h1 class="fw-bold mb-2"><i class="fas fa-graduation-cap me-2 text-primary"></i>Formações e Cursos</h1>
            <p class="text-muted mb-0">Cursos dirigidos a estudantes e recém-formados. Inscreva-se e envie documentos.</p>
        </div>
    </section>
    <main class="container py-5">
        <div class="row">
            <div class="col-lg-4">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h5 class="fw-bold">Filtros</h5>
                        <div class="mb-3">
                            <label class="form-label">Área</label>
                            <input id="filterArea" class="form-control form-control-sm" placeholder="Ex: Programação">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tipo</label>
                            <select id="filterTipo" class="form-select form-select-sm">
                                <option value="">Qualquer</option>
                                <option value="tecnico">Técnico</option>
                                <option value="online">Online</option>
                            </select>
                        </div>
                        <button class="btn btn-primary w-100 btn-sm" id="btnAplicarFiltros">Aplicar</button>
                    </div>
                </div>
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="fw-bold">Inscrever-se</h5>
                        <p class="text-muted small">Para se inscrever, faça login ou registe-se. O formulário permitirá enviar cópia do documento e comprovativo de pagamento.</p>
                        <a href="registo.html" class="btn btn-primary w-100 btn-sm mb-2">Registar</a>
                        <a href="login.html" class="btn btn-outline-secondary w-100 btn-sm">Entrar</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div id="cursosContainer" class="row g-4">
                    <!-- Cursos carregados via JS -->
                </div>
            </div>
        </div>
    </main>
    <!-- Modal de Inscrição -->
    <div class="modal fade" id="modalInscricao" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Inscrição no Curso</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="formInscricao">
                        <div class="mb-3">
                            <label class="form-label">Nome Completo</label>
                            <input type="text" name="nome" id="insNome" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Número do BI / Documento</label>
                            <input type="text" name="documento" id="insDocumento" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" id="insEmail" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Cópia do Documento (PDF/JPG)</label>
                            <input type="file" name="docCopy" id="insDocCopy" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Comprovativo de Pagamento (se aplicável)</label>
                            <input type="file" name="paymentProof" id="insPaymentProof" class="form-control">
                        </div>
                        <input type="hidden" id="insCursoId" name="curso_id" value="">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="btnEnviarInscricao">Enviar Inscrição</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        const cursosExemplo = [
            { id: 1, titulo: 'Curso de Programação Web', area: 'Programação', tipo: 'tecnico', preco: '5000 Kz', duracao: '8 semanas' },
            { id: 2, titulo: 'Introdução a Data Science', area: 'Dados', tipo: 'online', preco: '3000 Kz', duracao: '6 semanas' },
            { id: 3, titulo: 'DevOps Básico', area: 'DevOps', tipo: 'tecnico', preco: '4000 Kz', duracao: '10 semanas' }
        ];
        function renderCursos(list = cursosExemplo) {
            const container = document.getElementById('cursosContainer');
            container.innerHTML = '';
            list.forEach(c => {
                const card = document.createElement('div');
                card.className = 'col-md-6';
                card.innerHTML = `
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body">
                            <h5 class="card-title">${c.titulo}</h5>
                            <p class="text-muted small mb-2">${c.area} • ${c.duracao}</p>
                            <p class="card-text">Preço: <strong>${c.preco}</strong></p>
                            <div class="d-flex justify-content-end">
                                <button class="btn btn-sm btn-primary me-2" onclick="openInscricao(${c.id})">Inscrever-se</button>
                                <button class="btn btn-sm btn-outline-secondary" onclick="verDetalhes(${c.id})">Detalhes</button>
                            </div>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        }
        function openInscricao(cursoId) {
            const curso = cursosExemplo.find(c => c.id === cursoId);
            if (!curso) return;
            document.getElementById('insCursoId').value = cursoId;
            const modal = new bootstrap.Modal(document.getElementById('modalInscricao'));
            // tentar preencher dados do perfil se existir
            const user = localStorage.getItem('user');
            if (user) {
                try {
                    const u = JSON.parse(user);
                    document.getElementById('insNome').value = u.nome || '';
                    document.getElementById('insEmail').value = u.email || '';
                    document.getElementById('insDocumento').value = u.documento || '';
                } catch (e) { console.error(e); }
            }
            modal.show();
        }
        function verDetalhes(id) {
            const curso = cursosExemplo.find(c => c.id === id);
            if (!curso) return alert('Curso não encontrado');
            alert(`${curso.titulo}\n\nÁrea: ${curso.area}\nDuração: ${curso.duracao}\nPreço: ${curso.preco}`);
        }
        document.getElementById('btnEnviarInscricao').addEventListener('click', async function() {
            const form = document.getElementById('formInscricao');
            const cursoId = document.getElementById('insCursoId').value;
            const nome = document.getElementById('insNome').value.trim();
            const documento = document.getElementById('insDocumento').value.trim();
            const email = document.getElementById('insEmail').value.trim();
            const docFile = document.getElementById('insDocCopy').files[0];
            const payFile = document.getElementById('insPaymentProof').files[0];
            if (!nome || !documento || !email) {
                alert('Preencha os campos obrigatórios');
                return;
            }
            const fd = new FormData();
            fd.append('curso_id', cursoId);
            fd.append('nome', nome);
            fd.append('documento', documento);
            fd.append('email', email);
            if (docFile) fd.append('docCopy', docFile);
            if (payFile) fd.append('paymentProof', payFile);
            try {
                const resp = await fetch('/SWPCF/api/inscricoes.php', {
                    method: 'POST',
                    body: fd
                });
                const data = await resp.json();
                if (resp.ok && data.success) {
                    alert('Inscrição enviada com sucesso. ID: ' + data.id);
                    const modal = bootstrap.Modal.getInstance(document.getElementById('modalInscricao'));
                    modal.hide();
                } else {
                    alert('Erro: ' + (data.message || resp.statusText));
                }
            } catch (err) {
                console.error(err);
                alert('Erro ao enviar inscrição. Veja console para detalhes.');
            }
        });
        document.addEventListener('DOMContentLoaded', function() {
            renderCursos();
            // filtros
            document.getElementById('btnAplicarFiltros').addEventListener('click', function() {
                const area = document.getElementById('filterArea').value.toLowerCase();
                const tipo = document.getElementById('filterTipo').value;
                const filtered = cursosExemplo.filter(c => {
                    if (area && !c.area.toLowerCase().includes(area)) return false;
                    if (tipo && c.tipo !== tipo) return false;
                    return true;
                });
                renderCursos(filtered);
            });
        });
    </script>
    <div id="footer-container"></div>
