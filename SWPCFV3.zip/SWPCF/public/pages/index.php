<?php
/**
 * Página: index
 * Gerado automaticamente de index.html
 */
?>
<!-- NAVBAR (carregada dinamicamente) -->
    <!-- HERO SECTION -->
    <section class="hero py-5" role="region" aria-label="Hero">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-3">Encontre a Sua Oportunidade de Estágio em Tecnologia</h1>
                    <p class="lead mb-4">Conecte-se com as melhores empresas de tecnologia. Desenvolva suas competências em estágios profissionais remunerados.</p>
                    <div class="d-flex gap-2 flex-wrap">
                        <a href="estagios.html" class="btn btn-light btn-lg fw-bold">
                            <i class="fas fa-search me-2"></i>Procurar Estágios
                        </a>
                        <button class="btn btn-outline-light btn-lg fw-bold" id="btnRegisterHero">
                            <i class="fas fa-user-plus me-2"></i>Registar Grátis
                        </button>
                    </div>
                </div>
                <div class="col-lg-6 text-center d-none d-lg-block">
                    <div class="fs-1 opacity-75">
                        <i class="fas fa-code"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ESTATÍSTICAS -->
    <section class="py-5 bg-light" role="region" aria-label="Estatísticas">
        <div class="container">
            <div class="row text-center g-4">
                <div class="col-md-3 col-sm-6">
                    <h3 class="text-primary display-6 fw-bold">150+</h3>
                    <p class="text-muted mb-0">Estágios Ativos</p>
                </div>
                <div class="col-md-3 col-sm-6">
                    <!-- usar cor da marca em vez de sucess ou info para consistência -->
                    <h3 class="text-primary display-6 fw-bold">50+</h3>
                    <p class="text-muted mb-0">Empresas Parceiras</p>
                </div>
                <div class="col-md-3 col-sm-6">
                    <h3 class="text-primary display-6 fw-bold">3000+</h3>
                    <p class="text-muted mb-0">Candidatos Ativos</p>
                </div>
                <div class="col-md-3 col-sm-6">
                    <h3 class="text-primary display-6 fw-bold">1000+</h3>
                    <p class="text-muted mb-0">Estágios Completados</p>
                </div>
            </div>
        </div>
    </section>
    <!-- ESTÁGIOS EM DESTAQUE -->
    <section class="py-5" role="region" aria-label="Estágios em Destaque">
        <div class="container">
            <h2 class="text-center mb-5 fw-bold">Estágios em Destaque</h2>
            <div class="row g-4" id="estagiosDestaque">
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-header bg-primary text-white">
                            <!-- use bootstrap 5 utility class for light background, badge-light is deprecated -->
                            <span class="badge bg-light text-dark">Desenvolvimento</span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Desenvolvedor Full-Stack</h5>
                            <p class="text-muted small mb-3"><i class="fas fa-building me-1"></i>Tech Innovations Lda</p>
                            <p class="card-text">Procuramos desenvolvedor para trabalhar com React, Node.js e MongoDB.</p>
                            <div class="mt-3 d-flex justify-content-between align-items-center">
                                <span class="badge bg-primary text-white">1000 Kz - 1400 Kz</span>
                                <a href="estagios.html" class="btn btn-sm btn-primary">Ver</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm border-0">
                        <!-- uniformizar todas as cabeças de cartão com cor da marca -->
                        <div class="card-header bg-primary text-white">
                            <span class="badge bg-light text-dark">Data</span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Analista de Dados Junior</h5>
                            <p class="text-muted small mb-3"><i class="fas fa-building me-1"></i>Data Solutions Portugal</p>
                            <p class="card-text">Estágio em análise de dados com Python, SQL e Power BI.</p>
                            <div class="mt-3 d-flex justify-content-between align-items-center">
                                <span class="badge bg-primary text-white">800 Kz - 1200 Kz</span>
                                <a href="estagios.html" class="btn btn-sm btn-primary">Ver</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-header bg-primary text-white">
                            <!-- category badge uses light background for contrast -->
                            <span class="badge bg-light text-dark">DevOps</span>
                        </div>
                        <!-- badge color fixed to light for readability -->
                        <div class="card-body">
                            <h5 class="card-title">Engenheiro DevOps Junior</h5>
                            <p class="text-muted small mb-3"><i class="fas fa-building me-1"></i>Cloud Systems</p>
                            <p class="card-text">Estágio em DevOps com Docker, Kubernetes e AWS.</p>
                            <div class="mt-3 d-flex justify-content-between align-items-center">
                                <span class="badge bg-primary text-white">900 Kz - 1300 Kz</span>
                                <a href="estagios.html" class="btn btn-sm btn-primary">Ver</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-5">
                <a href="estagios.html" class="btn btn-primary btn-lg fw-bold">
                    Ver Todos os Estágios <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </section>
    <!-- BENEFÍCIOS -->
    <section class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5 fw-bold">Por que SWPCF?</h2>
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="text-center p-4">
                        <!-- usar cor principal para todos os ícones para um visual unificado -->
                        <div class="text-primary icon-3x">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <h5 class="mt-3 fw-bold">Oportunidades Reais</h5>
                        <p class="text-muted">Estágios com empresas de tecnologia líderes</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="text-center p-4">
                        <div class="text-primary icon-3x">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h5 class="mt-3 fw-bold">Seguro e Confiável</h5>
                        <p class="text-muted">Seus dados protegidos com máxima segurança</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="text-center p-4">
                        <div class="text-primary icon-3x">
                            <i class="fas fa-users"></i>
                        </div>
                        <h5 class="mt-3 fw-bold">Comunidade Ativa</h5>
                        <p class="text-muted">Conecte com profissionais e empresas</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="text-center p-4">
                        <div class="text-primary icon-3x">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h5 class="mt-3 fw-bold">Crescimento Profissional</h5>
                        <p class="text-muted">Desenvolva competências em tecnologia</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA SECTION -->
    <section class="py-5 bg-primary text-white">
        <div class="container text-center">
            <h2 class="mb-3 fw-bold">Comece o Seu Percurso em Tecnologia</h2>
            <p class="lead mb-4">Crie sua conta gratuitamente e acesse centenas de oportunidades de estágio</p>
            <button class="btn btn-light btn-lg fw-bold" id="btnRegisterCTA">
                <i class="fas fa-user-plus me-2"></i>Registar Agora
            </button>
        </div>
    </section>
    <!-- Scripts -->
    <!-- Event handlers para botões de registro/login -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const btnRegisterHero = document.getElementById('btnRegisterHero');
            const btnRegisterCTA = document.getElementById('btnRegisterCTA');
            if (btnRegisterHero) {
                btnRegisterHero.addEventListener('click', () => {
                    window.location.href = 'registo.html';
                });
            }
            if (btnRegisterCTA) {
                btnRegisterCTA.addEventListener('click', () => {
                    window.location.href = 'registo.html';
                });
            }
        });
    </script>
    <div id="footer-container"></div>
