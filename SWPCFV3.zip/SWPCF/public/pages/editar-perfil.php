<?php
/**
 * Página: editar-perfil
 * Gerado automaticamente de editar-perfil.html
 */
?>
<main class="container py-5">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <h1 class="h3 fw-bold mb-4"><i class="fas fa-user-edit me-2 text-primary"></i>Editar Perfil</h1>
                <div class="alert alert-message" id="alertMessage" style="display:none;"></div>
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <form id="formEditarPerfil">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nome Completo</label>
                                <input type="text" class="form-control" name="nome" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Email</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Telefone</label>
                                <input type="tel" class="form-control" name="telefone">
                            </div>
                            <hr>
                            <h6 class="fw-bold mb-3">Alterar Senha (Opcional)</h6>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Senha Atual</label>
                                <input type="password" class="form-control" name="senha_atual">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nova Senha</label>
                                <input type="password" class="form-control" name="senha_nova">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Confirmar Nova Senha</label>
                                <input type="password" class="form-control" name="senha_confirmar">
                            </div>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Salvar Alterações
                                </button>
                                <a href="<?php echo BASE_URL; ?>/SWPCF/perfil" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const user = JSON.parse(localStorage.getItem('swpcf_user') || '{}');
            if (!user.id) {
                window.location.href = '/SWPCF/login';
                return;
            }
            const form = document.getElementById('formEditarPerfil');
            form.nome.value = user.nome || '';
            form.email.value = user.email || '';
            form.telefone.value = user.telefone || '';
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                const alertMsg = document.getElementById('alertMessage');
                const senha_nova = form.senha_nova.value;
                const senha_confirmar = form.senha_confirmar.value;
                if (senha_nova && senha_nova !== senha_confirmar) {
                    alertMsg.className = 'alert alert-danger';
                    alertMsg.textContent = 'As senhas não coincidem';
                    alertMsg.style.display = 'block';
                    return;
                }
                const dados = {
                    id: user.id,
                    nome: form.nome.value,
                    email: form.email.value,
                    telefone: form.telefone.value
                };
                if (senha_nova) {
                    dados.senha = senha_nova;
                }
                try {
                    const res = await fetch('/SWPCF/api/utilizadores.php', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(dados)
                    });
                    const data = await res.json();
                    if (data.success) {
                        user.nome = dados.nome;
                        user.email = dados.email;
                        user.telefone = dados.telefone;
                        localStorage.setItem('swpcf_user', JSON.stringify(user));
                        alertMsg.className = 'alert alert-success';
                        alertMsg.textContent = 'Perfil atualizado com sucesso!';
                        alertMsg.style.display = 'block';
                        setTimeout(() => window.location.href = '/SWPCF/perfil', 1500);
                    } else {
                        alertMsg.className = 'alert alert-danger';
                        alertMsg.textContent = data.message || 'Erro ao atualizar';
                        alertMsg.style.display = 'block';
                    }
                } catch (e) {
                    alertMsg.className = 'alert alert-danger';
                    alertMsg.textContent = 'Erro ao atualizar perfil';
                    alertMsg.style.display = 'block';
                }
            });
        });
    </script>
    <div id="footer-container"></div>
